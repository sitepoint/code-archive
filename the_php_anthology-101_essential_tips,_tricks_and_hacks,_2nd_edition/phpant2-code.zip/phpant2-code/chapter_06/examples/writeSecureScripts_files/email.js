function emailwindow (thePage)
{
	emailWin=window.open(thePage,'email','width=340,height=450')
}
function feedbackwindow(thePage)
{
	feedbackWin=window.open(thePage,'feedback','width=400,height=530,scrollbars')
}

