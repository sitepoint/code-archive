<?php
// Read file and display it directly
readfile('writeSecureScripts.html');
?>
