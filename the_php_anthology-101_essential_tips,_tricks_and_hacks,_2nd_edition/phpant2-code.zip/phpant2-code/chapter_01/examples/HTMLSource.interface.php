<?php
interface HTMLSource
{
  public function getSource();
}
?>