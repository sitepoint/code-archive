<?php
$db_host = 'localhost';
$db_name = 'phpant2_chap5';
$dsn = "mysql:host=$db_host;dbname=$db_name;";
$user = 'user';
$password = 'secret';
?>