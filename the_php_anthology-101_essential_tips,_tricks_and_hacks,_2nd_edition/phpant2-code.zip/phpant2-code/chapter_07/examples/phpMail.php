<?php
mail('you@yourdomain.com', 'Howdy', 'Glad to meet you.', 'From: me@mydomain.com'); 
?>
