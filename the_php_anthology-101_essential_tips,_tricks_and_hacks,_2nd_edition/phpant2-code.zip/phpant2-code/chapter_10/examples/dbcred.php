<?php
$dsn = 'mysql:host=localhost;dbname=access_control;';
$user = 'user';
$password = 'secret';
?>