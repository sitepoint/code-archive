class StoriesController < ApplicationController

  def index
  end
end