class Story < ActiveRecord::Base
end