# Example of Integer class's upto method
5.upto(7) { |i| puts i }