"What does Ruby syntax look like?".reverse
8 * 5
3.times { puts "cheer!" }
%w(one two three).each { |word| puts word.upcase }