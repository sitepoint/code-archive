class SpecialPost < Post
end
