class Magazine < ActiveRecord::Base
  acts_as_taggable
end
