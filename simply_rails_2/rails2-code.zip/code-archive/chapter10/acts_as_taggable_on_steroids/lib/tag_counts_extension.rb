# Deprecated
module TagCountsExtension #:nodoc:
end
