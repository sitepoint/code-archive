Use these theme files to start your Thematic Child Theme development. 
Rename and move this entire folder to the root level of wp-content/themes 
alongside Thematic and activate your new Thematic Child Theme like any 
other WordPress theme.

Good luck!

--
Ian Stewart
ian@themeshaper.com
http://themeshaper.com/