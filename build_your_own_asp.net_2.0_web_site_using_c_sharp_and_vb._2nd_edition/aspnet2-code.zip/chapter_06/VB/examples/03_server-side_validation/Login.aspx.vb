
Partial Class Login
    Inherits System.Web.UI.Page

    Protected Sub submitButton_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        If Page.IsValid Then
            submitButton.Text = "Valid"
        Else
            submitButton.Text = "Invalid!"
        End If
    End Sub
End Class
