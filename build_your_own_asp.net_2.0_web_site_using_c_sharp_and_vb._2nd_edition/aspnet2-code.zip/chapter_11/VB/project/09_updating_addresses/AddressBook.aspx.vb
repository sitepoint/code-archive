Imports System.Data.SqlClient

Partial Class AddressBook
    Inherits System.Web.UI.Page
    Protected Sub employeeDetails_ItemUpdated( _
            ByVal sender As Object, _
            ByVal e As System.Web.UI.WebControls.DetailsViewUpdatedEventArgs) _
            Handles employeeDetails.ItemUpdated
        grid.DataBind()
    End Sub
    Protected Sub employeeDetails_ItemDeleted( _
            ByVal sender As Object, _
            ByVal e As System.Web.UI.WebControls.DetailsViewDeletedEventArgs) _
            Handles employeeDetails.ItemDeleted
        grid.DataBind()
    End Sub
    Protected Sub employeeDetails_ItemInserted( _
            ByVal sender As Object, _
            ByVal e As System.Web.UI.WebControls.DetailsViewInsertedEventArgs) _
            Handles employeeDetails.ItemInserted
        grid.DataBind()
    End Sub
    Protected Sub addEmployeeButton_Click(ByVal sender As Object, _
            ByVal e As System.EventArgs) Handles addEmployeeButton.Click
        employeeDetails.ChangeMode(DetailsViewMode.Insert)
    End Sub
End Class
