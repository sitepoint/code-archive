
Partial Class Dorknozzle
    Inherits System.Web.UI.MasterPage
End Class

