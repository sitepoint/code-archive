
Partial Class HelpDesk
    Inherits System.Web.UI.Page

End Class
