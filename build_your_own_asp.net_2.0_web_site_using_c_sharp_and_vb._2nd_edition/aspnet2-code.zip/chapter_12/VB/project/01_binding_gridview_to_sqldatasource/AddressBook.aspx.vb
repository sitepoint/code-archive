Imports System.Data.SqlClient

Partial Class AddressBook
    Inherits System.Web.UI.Page

End Class
