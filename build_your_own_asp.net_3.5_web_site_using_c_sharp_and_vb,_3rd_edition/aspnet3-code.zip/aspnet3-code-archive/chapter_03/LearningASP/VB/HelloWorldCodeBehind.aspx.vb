﻿Imports System
Imports System.Web.UI
Imports System.Web.UI.WebControls
Partial Class HelloWorldCodeBehind
  Inherits System.Web.UI.Page
  Sub Click(ByVal s As Object, ByVal e As EventArgs)
    messageLabel.Text = "Hello World!"
  End Sub
End Class
