﻿
Partial Class HelpDesk
    Inherits System.Web.UI.Page

Protected Sub submitButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles submitButton.Click
  If Page.IsValid Then
    ' Code that uses the data entered by the user
  End If
End Sub
End Class
