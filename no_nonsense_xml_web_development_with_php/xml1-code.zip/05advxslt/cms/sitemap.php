<?php
include_once 'common.inc.php';
$timestamp = date('YmdHis');

$xmlstring = '<?xml version="1.0"?>';
$xmlstring .= '<sitemap created="' . $timestamp . '">';
$handle = opendir($fileDir);
while (($file = readdir($handle)) !== FALSE) {
	if (is_dir($fileDir . $file)) continue;
	if (!eregi("^(news|article|webcopy).*\.xml$", $file)) continue;

	$xmlItem = simplexml_load_file($fileDir . $file);
	if ((string)$xmlItem->status == 'live') {
		$id = (string)$xmlItem['id'];
		$type = ereg_replace('[0-9]', '', $id);
		$created = ereg_replace('[^0-9]', '', $id);
		$xmlstring .= '<content id="' . $id . '">';
		$xmlstring .= '<headline>' . htmlspecialchars($xmlItem->headline) . '</headline>';
		$xmlstring .= '<type>' . $type . '</type>';
		$xmlstring .= '<created>' . $created . '</created>';
		$xmlstring .= '</content>';
	}
}
$xmlstring .= '</sitemap>';

if (isset($_GET['sortby'])) {
	$sortby = $_GET['sortby'];
} else {
	$sortby = 'headline';
}

$xml = simplexml_load_string($xmlstring);
$xsl = new DOMDocument;
$xsl->load('xslt/sitemap.xsl');
$proc = new XSLTProcessor;
$proc->importStyleSheet($xsl);
$proc->setParameter('', 'SORTBY', $sortby);
echo $proc->transformToXML($xml);
?>