<?php
include_once 'common.inc.php';
$term = $_POST['term'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Search Results</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="xmlcms.css" type="text/css" />
</head>
<body>
<?php
include 'navtop.inc.php';
?>
<div id="navSide">
	<?php
	include 'search.inc.php';
	include 'news.inc.php';
	?>
</div>
<div id="mainContent">
	<?php
	$handle = opendir($fileDir);
	$items = array();
	while (($file = readdir($handle)) !== FALSE) {
		if (is_dir($fileDir . $file)) continue;  
		if (!eregi("^(news|article|webcopy).*\.xml$", $file)) continue;

		$xmlItem = simplexml_load_file($fileDir . $file);
		if ((stripos($xmlItem->keywords, $term) !== FALSE or
			stripos($xmlItem->headline, $term) !== FALSE or
			stripos($xmlItem->description, $term) !== FALSE) and
			(string)$xmlItem->status == 'live') {
			$item = array();
			$item['id'] = (string)$xmlItem['id'];
			$item['headline'] = (string)$xmlItem->headline;
			$items[] = $item;
		}
	}
	
	if (count($items) > 0) {
		echo '<h1>Search Results for ' . htmlentities($term) . '</h1>';
		echo '<table border="1" cellspacing="0" cellpadding="3" width="85%">';
		echo '<tr valign="top"><th>Content Item</th><th>Content Type</th></tr>';
		foreach ($items as $item) {
			echo '<tr valign="top"><td><a href="innerpage.php?id=' . $item['id'] . '">';
			echo htmlentities($item['headline']) . '</a></td>';
			echo '<td>';
			echo ereg_replace('[0-9]', '', $item['id']);
			echo '</td></tr>';
		}
		echo '</table>';
	} else {
		echo '<h1>Sorry!</h1>';
		echo '<p>No files found with the search term ' . htmlentities($term) . '</p>';
	}
	?>
</div>
</body>
</html>