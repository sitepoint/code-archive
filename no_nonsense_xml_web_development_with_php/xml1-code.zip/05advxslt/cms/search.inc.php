<form id="searchWidget" method="post" action="doSearch.php">
	Search Site:
	<input name="term" type="text" id="term" />
	<input name="search" type="submit" id="search" value="Search" />
</form>
<p><a href="sitemap.php">Site Map</a></p>