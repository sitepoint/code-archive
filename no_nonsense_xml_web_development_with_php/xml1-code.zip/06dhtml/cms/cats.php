<?php
include_once 'common.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Browse by Category</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="xmlcms.css" type="text/css" />
<script type="text/javascript" src="sarissa/sarissa.js"></script>
<script type="text/javascript">
function initMenu(xmlFile) {
	var xml = Sarissa.getDomDocument();
	xml.async = false;
	xml.load(xmlFile);
	
	var nodes = xml.documentElement.childNodes;
	var output = '';
	for (var i = 0; i <= nodes.length - 1; i++) {
		if (nodes.item(i).nodeType != Node.ELEMENT_NODE) continue;
		if (nodes.item(i).getAttribute('status') == 'live') {
			output += '<a href="cats.php?catid=' + nodes.item(i).getAttribute('id') + '">' +
				nodes.item(i).getAttribute('label') + '</a><br />';
		}
	}
	document.getElementById('menudiv').innerHTML = output;
}

window.onload = function() {
	initMenu('xml/categories.xml');
};
</script>
</head>
<body>
<?php
include 'navtop.inc.php';
?>
<div id="navSide">
	<?php
	include 'search.inc.php';
	include 'news.inc.php';
	?>
</div>
<div id="mainContent">
	<h1>Browse By Category</h1>
	<div id="menudiv"></div>
  <ul>
	<?php
	if (isset($_GET['catid'])) {
		$handle = opendir($fileDir);
		while (($file = readdir($handle)) !== FALSE) {
			if (is_dir($fileDir . $file)) continue;  
			if (!eregi("^(news|article|webcopy).*\.xml$", $file)) continue;
		
			$xml = simplexml_load_file($fileDir . $file);
			if ((string)$xml->categoryid == $_GET['catid'] &&
				  (string)$xml->status == "live") {
				$id = htmlentities($xml['id']);
				$label = htmlentities($xml->headline);
				echo "<li><a href=\"innerpage.php?id={$id}\">{$label}</a></li>";
			}
		}
	}
	?>
  </ul>
</div>
</body>
</html>