<div id="navTop">
<a href="index.php"><img src="images/logo.gif" border="0" width="160" height="170" alt="Triple Dog Dare Media" /></a>
<?php
include_once 'common.inc.php';

$handle = opendir($fileDir);
while (($file = readdir($handle)) !== FALSE) {
	if (is_dir($fileDir . $file)) continue;  
	if (!eregi("^webcopy.*\.xml$", $file)) continue;

	$webcopy = simplexml_load_file($fileDir . $file);
	if (count($webcopy->xpath('/webcopy[status="live"]'))) {
		$id = htmlentities($webcopy['id']);
		$label = htmlentities($webcopy->navigationlabel);
		echo "<a href=\"innerpage.php?id={$id}\">{$label}</a> ";
	}
}

?>
</div>