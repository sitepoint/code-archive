<?php
include_once 'common.inc.php';
$file = $fileDir . 'homepage.xml';
$homePage = simplexml_load_file($file);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo htmlentities($homePage->headline); ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="xmlcms.css" type="text/css" />
</head>
<body>
<?php
include 'navtop.inc.php';
?>
<div id="navSide">
	<?php
	include 'search.inc.php';
	include 'news.inc.php';
	?>
</div>
<div id="mainContent">
	<?php
	echo '<h1>' . htmlentities($homePage->headline) . '</h1>';
	echo '<p><small>' . htmlentities($homePage->description) . '</small></p>';
	echo $homePage->body;
	?>
</div>
</body>
</html>