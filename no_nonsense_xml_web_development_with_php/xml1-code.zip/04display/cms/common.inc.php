<?php
session_start();

$fileDir = $_SERVER['DOCUMENT_ROOT'] . '/xml/';
?>