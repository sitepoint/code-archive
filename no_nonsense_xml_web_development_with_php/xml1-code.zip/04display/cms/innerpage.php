<?php
include_once 'common.inc.php';
if (!isset($_GET['id']) or !eregi('^[a-z0-9]+$', $_GET['id'])) return;
$file = $fileDir . $_GET['id'] . '.xml';
$inner = simplexml_load_file($file);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>
<?php
if (count($inner->xpath('navigationlabel'))) {
	echo htmlentities($inner->navigationlabel);
} elseif (count($inner->xpath('headline'))) {
	echo htmlentities($inner->headline);
}
?>
</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="xmlcms.css" type="text/css" />
</head>
<body>
<?php
include 'navtop.inc.php';
?>
<div id="navSide">
	<?php
	include 'search.inc.php';
	include 'news.inc.php';
	?>
</div>
<div id="mainContent">
	<?php
	echo '<h1>' . htmlentities($inner->headline) . '</h1>';
	echo '<p><small>' . htmlentities($inner->description) . '</small></p>';
	if (count($inner->xpath('body'))) {
		echo $inner->body;
	}
	?>
</div>
</body>
</html>