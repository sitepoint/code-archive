<?php
include_once 'common.inc.php';

$handle = opendir($fileDir);
echo '<p>';
while (($file = readdir($handle)) !== FALSE) {
	if (is_dir($fileDir . $file)) continue;  
	if (!eregi('^news.*\.xml$', $file)) continue;

	$news = simplexml_load_file($fileDir . $file);
	if (count($news->xpath('/news[status="live"]'))) {
		$id = htmlentities($news['id']);
		$label = htmlentities($news->headline);
		echo "<a href=\"innerpage.php?id={$id}\">{$label}</a><br />";
	}
}
echo '</p>';

?>