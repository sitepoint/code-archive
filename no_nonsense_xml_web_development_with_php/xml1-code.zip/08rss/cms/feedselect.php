<?php
include_once 'common.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Feed Designer</title>
</head>
<body>
<h1>Feed Designer</h1>
<p>Create your own customized RSS feed to be notified of the latest
	articles published in your areas of interest.</p>
<p>Which categories would you like to monitor?</p>
<form action="feed.php" method="get">
<?php
$cats = simplexml_load_file($fileDir . 'categories.xml');
foreach ($cats->category as $cat) {
	if ((string)$cat['status'] == 'live') {
		echo '<p><label>';
		echo '<input type="checkbox" name="cat[]" value="' .
			htmlentities($cat['id']) . '" checked="checked" />';
		echo htmlentities($cat['label']) . '</label></p>';
	}
}
?>
<input type="submit" value="Generate Feed" />
</form>
</body>
</html>
