<?php
include_once 'common.inc.php';

$doc = new DOMDocument();
$root = $doc->createElement('rss');
$doc->appendChild($root);
$root->setAttribute('version', '0.91');

$channel = $doc->createElement('channel');
$root->appendChild($channel);

$title = $doc->createElement('title');
$channel->appendChild($title);
$text = $doc->createTextNode('Example.com Articles');
$title->appendChild($text);

$desc = $doc->createElement('description');
$channel->appendChild($desc);
$text = $doc->createTextNode('Articles from example.com');
$desc->appendChild($text);

$link = $doc->createElement('link');
$channel->appendChild($link);
$text = $doc->createTextNode('http://www.example.com/');
$link->appendChild($text);

$handle = opendir($fileDir);
$articles = array();
while (($file = readdir($handle)) !== FALSE) {
  if (is_dir($fileDir . $file)) continue;
  if (!eregi("^article.*\.xml$", $file)) continue;
  $articles[] = $file;
}
rsort($articles);

$cats = @$_GET['cat'];
if (!is_array($cats)) $cats = array();
$itemsToGo = 10;
foreach ($articles as $file) {
	$article = simplexml_load_file($fileDir . $file);
	if ((count($cats) == 0 or in_array((string)$article->categoryid, $cats)) and
		(string)$article->status == 'live') {
		
		$item = $doc->createElement('item');
		$channel->appendChild($item);
		
		$iTitle = $doc->createElement('title');
		$item->appendChild($iTitle);
		$text = $doc->createTextNode($article->headline);
		$iTitle->appendChild($text);
		
		$iDesc = $doc->createElement('description');
		$item->appendChild($iDesc);
		$text = $doc->createTextNode($article->description);
		$iDesc->appendChild($text);
		
		$iLink = $doc->createElement('link');
		$item->appendChild($iLink);
		$text = $doc->createTextNode('http://www.example.com/innerpage.php?id=' . $article['id']);
		$iLink->appendChild($text);
		
		if (--$itemsToGo < 1) break;
	}
}

header('content-type: application/xml');
echo $doc->saveXML();
?>