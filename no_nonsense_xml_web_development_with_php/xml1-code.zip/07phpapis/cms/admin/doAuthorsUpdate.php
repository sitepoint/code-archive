<?php
include 'security.inc.php';
include_once '../common.inc.php';

$doc = DOMDocument::load($fileDir . 'authors.xml');
$root = $doc->documentElement;
$maxId = 0;
$deleteFailures = array();

foreach ($root->getElementsByTagName('author') as $xAuthor) {
  $id = $xAuthor->getAttribute('id');
  if ($maxId < (int)$id) $maxId = (int)$id;
  if (isset($_POST['author']) and
      isset($_POST['author'][$id])) {
    $author = $_POST['author'][$id];
    if (isset($author['delete']) and $author['delete'] == 'true') {
      $okToDelete = TRUE;
      $handle = opendir($fileDir);
      while (($file = readdir($handle)) !== FALSE) {
        if (is_dir($fileDir . $file)) continue;  
        if (!eregi("^(article|news).*\.xml$", $file)) continue;
        $contentItem = simplexml_load_file($fileDir . $file);
        if ((string)$contentitem->authorid == (string)$id) {
          $okToDelete = FALSE;
          break;
        }
      }
      if ($okToDelete) $root->removeChild($xAuthor);
      else $deleteFailures[] = $id;
    } else {
      $name = $xAuthor->getElementsByTagName('name');
      $name = $name->item(0);
      $name->nodeValue = $author['name'];
      
      $byline = $xAuthor->getElementsByTagName('byline');
      $byline = $byline->item(0);
      $byline->nodeValue = $author['byline'];
      
      $email = $xAuthor->getElementsByTagName('email');
      $email = $email->item(0);
      $email->nodeValue = $author['email'];
    }
  }
}

if (isset($_POST['newauthor'])) {
  foreach ($_POST['newauthor'] as $author) {
    if (isset($author['name']) and trim($author['name']) != '') {
      $xAuthor = $root->appendChild($doc->createElement('author'));
      $xAuthor->setAttribute('id', ++$maxId);
      $xAuthor->appendChild($doc->createElement('name', $author['name']));
      $xAuthor->appendChild($doc->createElement('byline', $author['byline']));
      $xAuthor->appendChild($doc->createElement('email', $author['email']));
    }
  }
}

unlink($fileDir . 'authors.xml');
$doc->save($fileDir . 'authors.xml');

if (count($deleteFailures) > 0) {
  $qs = '?';
  foreach ($deleteFailures as $id) {
    $qs .= "id[]=$id&";
  }
  header('location: authortool_deletefail.php' . $qs);
} else {
  header('location: authortool.php');
}
?>