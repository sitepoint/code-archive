<?php
include 'security.inc.php';
include_once '../common.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Admin Index</title>
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
</head>
<body>
<h1>Admin Index</h1>
<p><a href="admintool_edit.php">Edit Admin Listing</a></p>
<p><a href="index.php">Cancel</a></p>
<ul>
<?php
$admins = simplexml_load_file($fileDir . 'admin.xml');
foreach ($admins->admin as $admin) {
  echo '<li>' . htmlentities($admin->name) .
      ' (' . htmlentities($admin->email) . ')</li>';
}
?>
</ul>
</body>
</html>