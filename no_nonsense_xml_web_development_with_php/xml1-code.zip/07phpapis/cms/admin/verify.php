<?php
include_once '../common.inc.php';

$admins = simplexml_load_file($fileDir . 'admin.xml');
foreach ($admins->admin as $admin) {
	if ($_POST['username'] == (string)$admin->username and
		crypt($_POST['password'], (string)$admin->password) == (string)$admin->password) {
		$_SESSION['login'] = true;
		header('location: index.php');
		exit;
	}
}
$_SESSION['error'] = 'Wrong user name or password. Try again.';
header('location: login.php');
?>