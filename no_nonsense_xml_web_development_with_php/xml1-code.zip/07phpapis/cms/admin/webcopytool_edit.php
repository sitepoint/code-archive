<?php
include 'security.inc.php';
include_once '../common.inc.php';

if (!isset($_GET['id']) || $_GET['id'] == '' || !file_exists($fileDir . $_GET['id'] . '.xml')) {
	header('location: webcopytool.php');
	exit;
}
$file = simplexml_load_file($fileDir . $_GET['id'] . '.xml');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Edit Web Copy</title>
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
<link rel="stylesheet" type="text/css" href="forms.css" />
</head>
<body>
<h1>Edit Web Copy</h1>
<p><a href="webcopytool.php">Cancel</a></p>
<form action="doWebcopyUpdate.php" method="post">
<input type="hidden" name="id" value="<?php echo htmlentities($_GET['id']); ?>" />
<div class="fields">
	<p>
		<label for="headline">Headline</label>
		<input type="text" id="headline" name="headline" class="text" value="<?php echo htmlentities($file->headline); ?>" />
	</p>
	<p>
		<label for="headline">Navigation Label</label>
		<input type="text" id="navlabel" name="navlabel" class="text"  value="<?php echo htmlentities($file->navigationlabel); ?>" />
	</p>
	<p>
		<label for="status">Status</label>
		<select id="status" name="status">
			<option value="in progress" <?php if ((string)$file->status == 'in progress') echo 'selected="selected"'?>>In Progress</option>
			<option value="live" <?php if ((string)$file->status == 'live') echo 'selected="selected"'?>>Live</option>
		</select>
	</p>
	<p>
		<label for="description">Description</label>
		<textarea id="description" name="description">
<?php echo htmlentities($file->description); ?></textarea>
	</p>
	<p>
		<label for="body">Web Copy Body (HTML)</label>
		<textarea id="body" name="body">
<?php echo htmlentities($file->body); ?></textarea>
	</p>
</div>
<div class="actions">
	<input type="submit" value="Update Web Copy" />
	<input type="reset" value="Reset" />
</div>
</form>
</body>
</html>