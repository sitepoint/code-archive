<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Please Log In</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
<link rel="stylesheet" type="text/css" href="login.css" />
</head>
<body>
<form class="login" action="verify.php" method="post">
<h1>Please log in</h1>
<div class="fields">
	<label for="username">User name</label>
	<input type="text" id="username" name="username" class="text" />
	<label for="password">Password</label>
	<input type="password" id="password" name="password" class="password" />
</div>
<div class="actions">
	<input type="submit" value="Submit" />
	<input type="reset" value="Reset" />
</div>
<p class="error"><?php echo $_SESSION['error']; ?></p>
</form>
</body>
</html>