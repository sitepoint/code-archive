<?php
include 'security.inc.php';
include_once '../common.inc.php';

$doc = new DOMDocument();
$root = $doc->createElement('article');
$root = $doc->appendChild($root);

$timestamp = date('YmdHis');
do {
	$id = 'article' . $timestamp++;
} while (file_exists($fileDir . $id . '.xml'));
$root->setAttribute('id', $id);

$author = $doc->createElement('authorid');
$root->appendChild($author);
$atext = $doc->createTextNode($_POST['authorid']);
$author->appendChild($atext);

$cat = $doc->createElement('categoryid');
$root->appendChild($cat);
$ctext = $doc->createTextNode($_POST['categoryid']);
$cat->appendChild($ctext); 

$head = $doc->createElement('headline');
$root->appendChild($head);
$htext = $doc->createTextNode($_POST['headline']);
$head->appendChild($htext);

$desc = $doc->createElement('description');
$root->appendChild($desc);
$dtext = $doc->createTextNode($_POST['description']);
$desc->appendChild($dtext);

$pub = $doc->createElement('pubdate');
$root->appendChild($pub);
$pubtext = $doc->createTextNode(date('Y-m-d'));
$pub->appendChild($pubtext);

$stat = $doc->createElement('status');
$root->appendChild($stat);
$stext = $doc->createTextNode($_POST['status']);
$stat->appendChild($stext);

$key = $doc->createElement('keywords');
$root->appendChild($key);
$ktext = $doc->createTextNode($_POST['keywords']);
$key->appendChild($ktext);

$body = $doc->createElement('body');
$root->appendChild($body);
$cdata = $doc->createCDATASection($_POST['body']);
$body->appendChild($cdata);

$filename = $fileDir . $id . '.xml';
$doc->save($filename);

header('location: articletool.php');
?>