<?php
include 'security.inc.php';
include_once '../common.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Edit Authors</title>
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
</head>
<body>
<h1>Edit Authors</h1>
<p><a href="authortool.php">Cancel</a></p>
<form method="post" action="doAuthorsUpdate.php">
<table border="1" cellspacing="0" cellpadding="3">
  <tr>
    <th>Delete?</th>
    <th>Name</th>
    <th>Byline</th>
    <th>Email</th>
  </tr>
  <?php
  $authors = simplexml_load_file($fileDir . 'authors.xml');
  foreach ($authors->author as $author) {
    echo "\t<tr valign=\"top\">\n";
    echo "\t\t<td><input type=\"checkbox\" name=\"author[" .
        htmlentities($author['id']) . "][delete]\" " .
        "value=\"true\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"author[" .
        htmlentities($author['id']) . "][name]\" value=\"" .
        htmlentities($author->name) . "\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"author[" .
        htmlentities($author['id']) . "][byline]\" value=\"" .
        htmlentities($author->byline) . "\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"author[" .
        htmlentities($author['id']) . "][email]\" value=\"" .
        htmlentities($author->email) . "\" /></td>\n";
    echo "\t</tr>\n";
  }
  for ($i = 0; $i < 3; $i++) {
    echo "\t<tr valign=\"top\">\n";
    echo "\t\t<td></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"newauthor[$i][name]\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"newauthor[$i][byline]\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"newauthor[$i][email]\" /></td>\n";
    echo "\t</tr>\n";
  }
  ?>
  <tr><td colspan="4">
    <input type="submit" value="Update" />
    <input type="reset" value="Reset" />
  </td></tr>
</table>
</form>
</body>
</html>