<?php
include_once '../common.inc.php';

if (@$_SESSION['login'] !== true) {
	header('location: login.php');
	$_SESSION['error'] = 'You must log in before you can access administration pages.';
	exit;
}
?>