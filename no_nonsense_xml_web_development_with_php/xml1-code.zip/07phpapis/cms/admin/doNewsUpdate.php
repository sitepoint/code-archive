<?php
include 'security.inc.php';
include_once '../common.inc.php';

$doc = new DOMDocument();
$root = $doc->createElement('news');
$root = $doc->appendChild($root);

$id = $_POST['id'];
$root->setAttribute('id', $id);

$author = $doc->createElement('authorid');
$root->appendChild($author);
$atext = $doc->createTextNode($_POST['authorid']);
$author->appendChild($atext);

$cat = $doc->createElement('categoryid');
$root->appendChild($cat);
$ctext = $doc->createTextNode($_POST['categoryid']);
$cat->appendChild($ctext); 

$head = $doc->createElement('headline');
$root->appendChild($head);
$htext = $doc->createTextNode($_POST['headline']);
$head->appendChild($htext);

$url = $doc->createElement('url');
$root->appendChild($url);
$utext = $doc->createTextNode($_POST['url']);
$url->appendChild($utext);

$desc = $doc->createElement('description');
$root->appendChild($desc);
$dtext = $doc->createTextNode($_POST['description']);
$desc->appendChild($dtext);

$pub = $doc->createElement('pubdate');
$root->appendChild($pub);
$pubtext = $doc->createTextNode(date('Y-m-d'));
$pub->appendChild($pubtext);

$stat = $doc->createElement('status');
$root->appendChild($stat);
$stext = $doc->createTextNode($_POST['status']);
$stat->appendChild($stext);

$key = $doc->createElement('keywords');
$root->appendChild($key);
$ktext = $doc->createTextNode($_POST['keywords']);
$key->appendChild($ktext);

$filename = $fileDir . $id . '.xml';
unlink($filename);
$doc->save($filename);

header('location: newstool.php');
?>