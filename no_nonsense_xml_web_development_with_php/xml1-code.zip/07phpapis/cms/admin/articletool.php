<?php
include 'security.inc.php';
include_once '../common.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Article Index</title>
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
</head>
<body>
<h1>Article Index</h1>
<p><a href="articletool_create.php">Create New Article</a></p>
<p><a href="index.php">Cancel</a></p>
<ul>
<?php
$handle = opendir($fileDir);
while (($file = readdir($handle)) !== FALSE) {
	if (is_dir($fileDir . $file)) continue;  
	if (!eregi("^article.*\.xml$", $file)) continue;
	
	$articleFile = simplexml_load_file($fileDir . $file);
	echo '<li>' . htmlentities($articleFile->headline);
	echo ' <a href="articletool_edit.php?id=' . $articleFile['id'] . '">edit</a>';
	echo ' <a href="doArticleDelete.php?id=' . $articleFile['id'] . '">delete</a></li>';
}
?>
</ul>
</body>
</html>