<?php
include 'security.inc.php';
include_once '../common.inc.php';

$doc = DOMDocument::load($fileDir . 'admin.xml');
$root = $doc->documentElement;
$maxId = 0;

foreach ($root->getElementsByTagName('admin') as $xAdmin) {
  $id = $xAdmin->getAttribute('id');
  if ($maxId < (int)$id) $maxId = (int)$id;
  if (isset($_POST['admin']) and
      isset($_POST['admin'][$id])) {
    $admin = $_POST['admin'][$id];
    if (isset($admin['delete']) and $admin['delete'] == 'true') {
      $root->removeChild($xAdmin);
    } else {
      $name = $xAdmin->getElementsByTagName('name');
      $name = $name->item(0);
      $name->nodeValue = $admin['name'];
      
      $uname = $xAdmin->getElementsByTagName('username');
      $uname = $uname->item(0);
      $uname->nodeValue = $admin['username'];
      
      if (isset($admin['password']) and trim($admin['password']) != '') {
        $pass = $xAdmin->getElementsByTagName('password');
        $pass = $pass->item(0);
        $pass->nodeValue = crypt($admin['password']);
      }
      
      $email = $xAdmin->getElementsByTagName('email');
      $email = $email->item(0);
      $email->nodeValue = $admin['email'];
    }
  }
}

if (isset($_POST['newadmin'])) {
  foreach ($_POST['newadmin'] as $admin) {
    if (isset($admin['name']) and trim($admin['name']) != '' and
        isset($admin['username']) and trim($admin['username']) != '' and
        isset($admin['password']) and trim($admin['password']) != '') {
      $xAdmin = $root->appendChild($doc->createElement('admin'));
      $xAdmin->setAttribute('id', ++$maxId);
      $xAdmin->appendChild($doc->createElement('name', $admin['name']));
      $xAdmin->appendChild($doc->createElement('username', $admin['username']));
      $xAdmin->appendChild($doc->createElement('password', crypt($admin['password'])));
      $xAdmin->appendChild($doc->createElement('email', $admin['email']));
    }
  }
}

unlink($fileDir . 'admin.xml');
$doc->save($fileDir . 'admin.xml');

header('location: admintool.php');
?>