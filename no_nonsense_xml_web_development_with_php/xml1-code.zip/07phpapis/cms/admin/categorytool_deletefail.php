<?php
include 'security.inc.php';
include_once '../common.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Delete(s) Failed</title>
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
</head>
<body>
<h1>Delete(s) Failed</h1>
<p>Failed to delete the following categories, which still contain content.
Remove or reassign their content items first, then try again.</p>
<ul>
<?php
$cats = simplexml_load_file($fileDir . 'categories.xml');
foreach ($id as $catId) {
  echo '<li>' . $cats->xpath("category[@id='$catId']/@label") . '</li>';
}
?>
</ul>
<p>Any other requested changes have been made.</p>
<p><a href="categorytool.php">Back to Category Listing</a></p>
</body>
</html>