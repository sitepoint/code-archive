<?php
include 'security.inc.php';
include_once '../common.inc.php';

$filename = $fileDir . $_GET['id'] . '.xml';
unlink($filename);

header('location: webcopytool.php');
?>