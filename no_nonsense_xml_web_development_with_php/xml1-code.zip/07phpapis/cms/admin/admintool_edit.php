<?php
include 'security.inc.php';
include_once '../common.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Edit Admins</title>
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
</head>
<body>
<h1>Edit Admins</h1>
<p><a href="admintool.php">Cancel</a></p>
<form method="post" action="doAdminsUpdate.php">
<table border="1" cellspacing="0" cellpadding="3">
  <tr>
    <th>Delete?</th>
    <th>Name</th>
    <th>Username</th>
    <th>New Password</th>
    <th>Email</th>
  </tr>
  <?php
  $admins = simplexml_load_file($fileDir . 'admin.xml');
  foreach ($admins->admin as $admin) {
    echo "\t<tr valign=\"top\">\n";
    echo "\t\t<td><input type=\"checkbox\" name=\"admin[" .
        htmlentities($admin['id']) . "][delete]\" " .
        "value=\"true\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"admin[" .
        htmlentities($admin['id']) . "][name]\" value=\"" .
        htmlentities($admin->name) . "\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"admin[" .
        htmlentities($admin['id']) . "][username]\" value=\"" .
        htmlentities($admin->username) . "\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"admin[" .
        htmlentities($admin['id']) . "][password]\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"admin[" .
        htmlentities($admin['id']) . "][email]\" value=\"" .
        htmlentities($admin->email) . "\" /></td>\n";
    echo "\t</tr>\n";
  }
  for ($i = 0; $i < 3; $i++) {
    echo "\t<tr valign=\"top\">\n";
    echo "\t\t<td></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"newadmin[$i][name]\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"newadmin[$i][username]\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"newadmin[$i][password]\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"newadmin[$i][email]\" /></td>\n";
    echo "\t</tr>\n";
  }
  ?>
  <tr><td colspan="5">
    <input type="submit" value="Update" />
    <input type="reset" value="Reset" />
  </td></tr>
</table>
</form>
</body>
</html>