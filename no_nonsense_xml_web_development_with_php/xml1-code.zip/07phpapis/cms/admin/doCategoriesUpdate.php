<?php
include 'security.inc.php';
include_once '../common.inc.php';

$doc = DOMDocument::load($fileDir . 'categories.xml');
$root = $doc->documentElement;
$maxId = 0;
$deleteFailures = array();

foreach ($root->getElementsByTagName('category') as $xCat) {
  $id = $xCat->getAttribute('id');
  if ($maxId < (int)$id) $maxId = (int)$id;
  if (isset($_POST['cat']) and
      isset($_POST['cat'][$id])) {
    $cat = $_POST['cat'][$id];
    if (isset($cat['delete']) and $cat['delete'] == 'true') {
      $okToDelete = TRUE;
      $handle = opendir($fileDir);
      while (($file = readdir($handle)) !== FALSE) {
        if (is_dir($fileDir . $file)) continue;  
        if (!eregi("^(article|news).*\.xml$", $file)) continue;
        $contentItem = simplexml_load_file($fileDir . $file);
        if ((string)$contentItem->categoryid == (string)$id) {
          $okToDelete = FALSE;
          break;
        }
      }
      if ($okToDelete) $root->removeChild($xCat);
      else $deleteFailures[] = $id;
    } else {
      $xCat->setAttribute('label', $cat['label']);
      $xCat->setAttribute('status', $cat['status']);
    }
  }
}

if (isset($_POST['newcat'])) {
  foreach ($_POST['newcat'] as $cat) {
    if (isset($cat['label']) and trim($cat['label']) != '') {
      $xCat = $root->appendChild($doc->createElement('category'));
      $xCat->setAttribute('id', ++$maxId);
      $xCat->setAttribute('label', $cat['label']);
      $xCat->setAttribute('status', $cat['status']);
    }
  }
}

unlink($fileDir . 'categories.xml');
$doc->save($fileDir . 'categories.xml');

if (count($deleteFailures) > 0) {
  $qs = '?';
  foreach ($deleteFailures as $id) {
    $qs .= "id[]=$id&";
  }
  header('location: categorytool_deletefail.php' . $qs);
} else {
  header('location: categorytool.php');
}
?>