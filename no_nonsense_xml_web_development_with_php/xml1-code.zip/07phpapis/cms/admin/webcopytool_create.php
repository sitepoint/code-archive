<?php
include 'security.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Create New Web Copy</title>
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
<link rel="stylesheet" type="text/css" href="forms.css" />
</head>
<body>
<h1>Create New Web Copy</h1>
<p><a href="webcopytool.php">Cancel</a></p>
<form action="doWebcopyCreate.php" method="post">
<div class="fields">
	<p>
		<label for="headline">Headline</label>
		<input type="text" id="headline" name="headline" class="text" />
	</p>
	<p>
		<label for="headline">Navigation Label</label>
		<input type="text" id="navlabel" name="navlabel" class="text" />
	</p>
	<p>
		<label for="status">Status</label>
		<select id="status" name="status">
			<option value="in progress">In Progress</option>
			<option value="live">Live</option>
		</select>
	</p>
	<p>
		<label for="description">Description</label>
		<textarea id="description" name="description"></textarea>
	</p>
	<p>
		<label for="body">Web Copy Body (HTML)</label>
		<textarea id="body" name="body"></textarea>
	</p>
</div>
<div class="actions">
	<input type="submit" value="Add Web Copy" />
	<input type="reset" value="Reset" />
</div>
</form>
</body>
</html>