<?php
include 'security.inc.php';
include_once '../common.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Create New News Item</title>
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
<link rel="stylesheet" type="text/css" href="forms.css" />
</head>
<body>
<h1>Create New News Item</h1>
<p><a href="newstool.php">Cancel</a></p>
<form action="doNewsCreate.php" method="post">
<div class="fields">
	<p>
		<label for="headline">Headline</label>
		<input type="text" id="headline" name="headline" class="text" />
	</p>
	<p>
		<label for="author">Author</label>
		<select id="authorid" name="authorid">
			<?php
			$authors = simplexml_load_file($fileDir . 'authors.xml');
			foreach ($authors->author as $author) {
				echo '<option value="' . htmlentities($author['id']) . '">' .
					htmlentities($author->name) . '</option>';
			}
			?>
		</select>
	</p>
	<p>
		<label for="category">Category</label>
		<select id="categoryid" name="categoryid">
			<?php
			$cats = simplexml_load_file($fileDir . 'categories.xml');
			foreach ($cats->category as $cat) {
				echo '<option value="' . htmlentities($cat['id']) . '">' .
					htmlentities($cat['label']) . '</option>';
			}
			?>
		</select>
	</p>
	<p>
		<label for="status">Status</label>
		<select id="status" name="status">
			<option value="in progress">In Progress</option>
			<option value="live">Live</option>
		</select>
	</p>
	<p>
		<label for="keywords">Keywords</label>
		<input type="text" id="keywords" name="keywords" class="text" />
	</p>
	<p>
		<label for="description">Description</label>
		<textarea id="description" name="description"></textarea>
	</p>
	<p>
		<label for="url">URL</label>
		<input type="text" id="url" name="url" class="text" />
	</p>
</div>
<div class="actions">
	<input type="submit" value="Add News Item" />
	<input type="reset" value="Reset" />
</div>
</form>
</body>
</html>