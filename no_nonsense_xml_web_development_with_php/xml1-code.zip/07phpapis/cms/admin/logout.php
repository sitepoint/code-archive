<?php
include_once '../common.inc.php';

$_SESSION['login'] = false;
header('location: index.php');
?>