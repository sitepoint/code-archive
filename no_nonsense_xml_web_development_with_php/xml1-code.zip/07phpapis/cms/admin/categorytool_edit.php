<?php
include 'security.inc.php';
include_once '../common.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1" />
<title>Edit Categories</title>
<link rel="stylesheet" type="text/css" href="../xmlcms.css" />
</head>
<body>
<h1>Edit Categories</h1>
<p><a href="categorytool.php">Cancel</a></p>
<form method="post" action="doCategoriesUpdate.php">
<table border="1" cellspacing="0" cellpadding="3">
  <tr>
    <th>Delete?</th>
    <th>Label</th>
    <th>Status</th>
  </tr>
  <?php
  $cats = simplexml_load_file($fileDir . 'categories.xml');
  foreach ($cats->category as $cat) {
    echo "\t<tr valign=\"top\">\n";
    echo "\t\t<td><input type=\"checkbox\" name=\"cat[" .
        htmlentities($cat['id']) . "][delete]\" " .
        "value=\"true\" /></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"cat[" .
        htmlentities($cat['id']) . "][label]\" value=\"" .
        htmlentities($cat['label']) . "\" /></td>\n";
    echo "\t\t<td><select name=\"cat[" . htmlentities($cat['id']) .
        "][status]\">\n";
    echo "\t\t\t<option value=\"live\"" .
        ((string)$cat['status'] == 'live' ? ' selected="selected"' : '') .
        ">live</option>\n";
    echo "\t\t\t<option value=\"in progress\"" .
        ((string)$cat['status'] == 'in progress' ? ' selected="selected"' : '') .
        ">in progress</option>\n";
    echo "\t\t</select></td>\n";
    echo "\t</tr>\n";
  }
  for ($i = 0; $i < 3; $i++) {
    echo "\t<tr valign=\"top\">\n";
    echo "\t\t<td></td>\n";
    echo "\t\t<td><input type=\"text\" name=\"newcat[$i][label]\" /></td>\n";
    echo "\t\t<td><select name=\"newcat[$i][status]\">\n";
    echo "\t\t\t<option value=\"live\">live</option>\n";
    echo "\t\t\t<option value=\"in progress\">in progress</option>\n";
    echo "\t\t</select></td>\n";
    echo "\t</tr>\n";
  }
  ?>
  <tr><td colspan="3">
    <input type="submit" value="Update" />
    <input type="reset" value="Reset" />
  </td></tr>
</table>
</form>
</body>
</html>