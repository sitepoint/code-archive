var cookieName = "login";
var cookieValue = "choc_chip";
var theCookie = cookieName + "=" + cookieValue;

document.cookie = theCookie;

alert("document.cookie is: " + document.cookie);