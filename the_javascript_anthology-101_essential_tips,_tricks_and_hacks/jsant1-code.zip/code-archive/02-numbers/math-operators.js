// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such

var s = 7, t = 2;

alert(s + t);    // 9
alert(s * t);    // 14
alert(s - t);    // 5
alert(s / t);    // 3.5
alert(s % t);    // 1
