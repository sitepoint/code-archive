//Please note: this file contains snippets for comparison
//it is not self-contained or ready-to-use code as such


var a = 10;
alert(typeof a);
a = String(a);
alert(typeof a);

var a = 10;
a = a.toString();
alert(typeof a);

var a = 2468;
var s = a + ' motorway';

var a = 2000;
var b = 468;
var s = a + b + ' motorway';

var s = 'and its ' + a + b + ' motorway';

var s = 'and its ' + (a + b) + ' motorway';
