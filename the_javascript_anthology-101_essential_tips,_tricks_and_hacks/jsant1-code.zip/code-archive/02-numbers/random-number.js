// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such


function randomBetween(min, max)
{
  return min + Math.floor(Math.random() * (max - min + 1));
}
