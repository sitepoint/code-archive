// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such


var a = '10';
alert(typeof a);
a = Number(a);
alert(typeof a);

var a = '24.68motorway';

var i = parseInt(a);
alert(i);

var f = parseFloat(a);
alert(f);

var s = 'route66';
var n = parseInt(s);
alert(n);
