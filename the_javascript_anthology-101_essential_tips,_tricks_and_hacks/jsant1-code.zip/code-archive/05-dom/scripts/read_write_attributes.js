addLoadListener(init);

function init()
{
  var anchor = document.getElementById("antares");
  var anchorId = anchor.getAttribute("id");
  var anchorTitle = anchor.getAttribute("title");

  alert("The anchor ID is: " + anchorId + "\nThe anchor title is: " + anchorTitle);

  return true;
}

function addLoadListener(fn)
{
  if (typeof window.addEventListener != 'undefined')
  {
    window.addEventListener('load', fn, false);
  }
  else if (typeof document.addEventListener != 'undefined')
  {
    document.addEventListener('load', fn, false);
  }
  else if (typeof window.attachEvent != 'undefined')
  {
    window.attachEvent('onload', fn);
  }
  else
  {
    var oldfn = window.onload;
    if (typeof window.onload != 'function')
    {
      window.onload = fn;
    }
    else
    {
      window.onload = function()
      {
        oldfn();
        fn();
      };
    }
  }
}