function uniteFlashJS()
{
  alert("This JavaScript function was called from within a Flash file");
}