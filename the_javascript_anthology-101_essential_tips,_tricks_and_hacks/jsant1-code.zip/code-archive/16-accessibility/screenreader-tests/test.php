<?php
echo "And here's the response - " . $_GET['msg'];
?>