//Please note: this file contains snippets for comparison
//it is not self-contained or ready-to-use code as such

window.scrollBy(0, 200);

window.scrollBy(200, 0);

window.scrollTo(300, 100);

window.scrollTo(0, 0);


