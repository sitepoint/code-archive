var navframe = top.frames['navigationFrame'];
navframe.callMyFunction();

var navdoc = navframe.document;
var menu = navdoc.getElementById('menulist');
