function callMyFunction()
{
  alert('Called the navigation frame!');
}
