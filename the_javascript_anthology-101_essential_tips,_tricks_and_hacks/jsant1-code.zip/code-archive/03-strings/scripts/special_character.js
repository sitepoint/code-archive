var a = "First line.\nSecond line.";

alert("String with a newline special character: " + a);