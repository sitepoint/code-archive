var a = "This sentence contains a substring.";
var b = a.indexOf("sentence");

alert("String: " + a + "\nThe substring \"sentence\" starts at: " + b);