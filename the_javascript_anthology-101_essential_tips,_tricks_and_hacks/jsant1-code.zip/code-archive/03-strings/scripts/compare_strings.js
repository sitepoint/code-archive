var a = "Cameron";
var b = "James";

if (a == b)
{
    var identity = "same";
}
else
{
    var identity = "different";
}

alert("String 1: " + a + "\nString 2: " + b + "\nComparison: " + identity);