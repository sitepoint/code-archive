var a = "very big letters";
var b = a.toUpperCase();

alert("Original string: " + a + "\nTransformed string: " + b);

var c = "VERY SMALL LETTERS";
var d = c.toLowerCase();

alert("Original string: " + c + "\nTransformed string: " + d);