// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such

function compare(a, b)
{
  if (Math.random() * 2 > 1) { return 1; }
  else { return -1; }
}
