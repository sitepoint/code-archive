// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such

var planets = ['mercury', 'venus', 'earth'];

var word = planets.join('');
alert(word);

var list = planets.join();
alert(list);

var sentence = planets.join(' then ');
alert(sentence);
