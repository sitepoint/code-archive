// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such

var planets = [];

planets['inner'] = ['mercury', 'venus', 'earth'];
planets['outer'] = ['uranus', 'neptune', 'pluto'];


for (var i in planets)
{
  alert(planets[i]);
}

var myData = { 'name1' : 'value1', 'name2' : 'value2' };
