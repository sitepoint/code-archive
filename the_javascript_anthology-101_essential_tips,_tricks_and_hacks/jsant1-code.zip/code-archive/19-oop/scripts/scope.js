var global = "available";

function availability()
{
  return global;
}

var isAvailable = availability();

alert("The global variable is: " + isAvailable);