// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such

var ele = eval('document.getElementById("link" + n)');

var mod = 'shiftKey';
if(eval('e.' + mod))
{
  //shift key is pressed
}

var ele = document.getElementById('link' + n);

var mod = 'shiftKey';
if(e[mod])
{
  //shift key is pressed
}


