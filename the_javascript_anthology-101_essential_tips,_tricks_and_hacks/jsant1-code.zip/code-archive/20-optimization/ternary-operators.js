// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such

var grade = score >= 40 ? 'pass' : 'fail';

var grade = score >= 70 ? 'merit' : score >= 40 ? 'pass' : 'fail';

var grade = score >= 90 ? 'distinction' :
    score >= 70 ? 'merit' :
    score >= 40 ? 'pass' :
    'fail';
