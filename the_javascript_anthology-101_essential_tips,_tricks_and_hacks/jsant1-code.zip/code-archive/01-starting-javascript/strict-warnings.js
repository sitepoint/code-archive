// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such

var fruit = 'mango';

if (basket.indexOf('apple') != -1)
{
  var fruit = 'apple';
}

function getBasket()
{
  var fruit = 'pomegranate';
  fruit;
}
