// Please note: this file contains snippets for comparison
// it is not self-contained or ready-to-use code as such

function checkAge(years)
{
  if (years < 13)
  {
    alert('less than 13');

    //other scripting
  }
  else if (years >= 13 && years <= 21)
  {
    alert('13 to 21');

    //other scripting
  }
  else
  {
    alert('older');

    //other scripting
  }
}
