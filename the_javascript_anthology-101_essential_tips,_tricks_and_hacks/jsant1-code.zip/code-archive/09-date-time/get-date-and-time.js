var today = new Date();
var sentence = today.toString();

alert(sentence);
