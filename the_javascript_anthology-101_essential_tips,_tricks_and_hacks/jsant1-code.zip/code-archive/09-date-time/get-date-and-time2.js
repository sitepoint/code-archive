var today = new Date();
var gmt = today.toGMTString();
var locale = today.toLocaleString();

alert(gmt);
alert(locale);
