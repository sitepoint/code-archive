$(document).ready(function(){
  $('#info').tabs();
});
