$(document).ready(function(){
  $(':radio[name=sex]').change(function(){
    alert($(this).val());
  });
});

