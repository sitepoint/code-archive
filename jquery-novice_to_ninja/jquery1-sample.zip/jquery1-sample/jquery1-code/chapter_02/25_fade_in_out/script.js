$(document).ready(function(){
  $('#hideButton').click(function(){
    $('#disclaimer').fadeOut();
  });
});