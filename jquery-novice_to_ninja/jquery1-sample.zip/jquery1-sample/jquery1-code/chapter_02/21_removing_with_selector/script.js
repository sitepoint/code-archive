$(document).ready(function(){
  $('#celebs tr').remove(':contains("Singer")');
});