$(document).ready(function(){
  $('p').html('<strong>Warning!</strong> Text has been replaced for your safety.');
  $('h2').text('<strong>Warning!</strong> Title elements can be hazardous to your health.');
});