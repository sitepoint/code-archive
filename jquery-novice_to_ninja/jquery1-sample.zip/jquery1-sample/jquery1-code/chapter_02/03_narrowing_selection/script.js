$(document).ready(function(){
	alert($('#celebs tbody tr').length + ' elements!');
});