$(document).ready(function(){
alert($('h2:first').text());
});