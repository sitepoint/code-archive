$(document).ready(function(){
  $('#toggleButton').click(function(){
    $('#disclaimer').toggle('slow');
  });
});