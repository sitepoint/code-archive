$(document).ready(function(){
  $('#celebs tbody tr:even').css('background-color','#dddddd');
});