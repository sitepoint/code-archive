$(document).ready(function(){
  $('#fine_print').jScrollPane({
    scrollbarWidth: 10,
    scrollbarMargin: 10,
    showArrows: false
  });
});
