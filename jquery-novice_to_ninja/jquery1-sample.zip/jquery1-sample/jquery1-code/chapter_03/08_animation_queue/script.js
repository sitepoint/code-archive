$(document).ready(function(){
  $('p:first').animate(
    {
      height: '+=100px',
      backgroundColor: 'green'
    },
    {
      duration: 'slow',
      easing: 'swing',
      complete: function() {alert('done!');},
      queue: false
    }
  );
});
