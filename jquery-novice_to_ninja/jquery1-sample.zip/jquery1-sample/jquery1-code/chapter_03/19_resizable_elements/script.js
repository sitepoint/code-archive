$(document).ready(function(){
  $('p').resizable();
});
