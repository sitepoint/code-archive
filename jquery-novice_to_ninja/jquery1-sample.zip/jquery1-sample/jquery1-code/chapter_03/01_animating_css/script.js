$(document).ready(function(){
  $('p').animate({ 
    padding: '20px',
    borderBottom: '3px solid #8f8f8f',
    borderRight: '3px solid #bfbfbf' 
  }, 2000);
});
