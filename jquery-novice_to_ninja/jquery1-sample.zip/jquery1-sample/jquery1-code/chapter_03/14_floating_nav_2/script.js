$(document).ready(function(){
  $(window).scroll(function() {
  $('#navigation')
      .stop()
      .animate({top: $(document).scrollTop()},'slow','easeOutBack');
  }); 
});
