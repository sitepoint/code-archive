$(document).ready(function() {
	$('p')
		.hide()
		.highlightOnce({color: '#C0FFEE', duration: 2000})
		.slideDown();
});
