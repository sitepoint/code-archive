$(document).ready(function() {
  $('p')
    .hide()
    .highlightOnce('#C0FFEE')
    .slideDown();
});
