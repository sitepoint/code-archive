$(document).ready(function() { 
  $('p:first').click(function firstClick() { 
    // first click handler
  }) 
  .click(function secondClick() {
    // second click handler 
  })
  .mouseover(function firstMouse() { 
    // first mouseover click handler
  });
  
  var events = $('p:first').data('events');
  console.log(events);
});
