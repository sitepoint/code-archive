$(document).ready(function() {
  $('p')
    .hide()
    .highlightOnce()
    .slideDown();
});
