<?php
if (!isset($_COOKIE['visits'])) {
	$_COOKIE['visits'] = 0;
}
$visits = $_COOKIE['visits'] + 1;
setcookie('visits', $visits, time() + 3600 * 24 * 365);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Cookie counter</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php
if ($visits > 1) {
	echo "This is visit number $visits.";
} else { // First visit
	echo 'Welcome to my Web site! Click here for a tour!';
}
?>
</body>
</html>