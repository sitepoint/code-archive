<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Joke CMS: Delete Category</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php

$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('ijdb')) {
  exit('<p>Unable to locate the joke ' .
      'database at this time.</p>');
}

// Delete all joke lookup entries for the
// category along with the entry for the category.
$id = $_GET['id'];
$ok1 = @mysql_query("DELETE FROM jokecategory WHERE categoryid='$id'"); 
$ok2 = @mysql_query("DELETE FROM category WHERE id='$id'");
if ($ok1 and $ok2) {
  echo '<p>Category deleted successfully!</p>';
} else {
  echo '<p>Error deleting category from database!<br />'.
       'Error: ' . mysql_error() . '</p>';
}

?>
<p><a href="cats.php">Return to category list</a></p>
</body>
</html>