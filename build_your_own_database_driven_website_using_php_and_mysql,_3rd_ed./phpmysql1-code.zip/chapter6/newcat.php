<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Joke CMS: Add New Category</title>
</head>
<body>
<?php if (isset($_POST['name'])):

  // A new category has been entered
  // using the form below.

  $dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
  if (!$dbcnx) {
    exit('<p>Unable to connect to the ' .
        'database server at this time.</p>');
  }
  
  if (!@mysql_select_db('ijdb')) {
    exit('<p>Unable to locate the joke ' .
        'database at this time.</p>');
  }

  $name = $_POST['name'];
  $sql = "INSERT INTO category SET name='$name'";
  if (@mysql_query($sql)) {
    echo '<p>New category added</p>';
  } else {
    echo '<p>Error adding new category: ' .
         mysql_error() . '</p>';
  }

?>

<p><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Add another category</a></p>
<p><a href="cats.php">Return to category list</a></p>

<?php else: // Allow the user to enter a new category ?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p>Enter the new category:</p>
<label>Name: <input type="text" name="name" /></label><br />
<input type="submit" value="SUBMIT" />
</form>

<?php endif; ?>

</body>
</html>