<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Joke CMS: Edit Category</title>
</head>
<body>
<?php

$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('ijdb')) {
  exit('<p>Unable to locate the joke ' .
      'database at this time.</p>');
}

if (isset($_POST['name'])):
  // The category's details have
  // been updated.

  $name = $_POST['name'];
  $id = $_POST['id'];
  $sql = "UPDATE category SET
          name='$name'
          WHERE id='$id'";
  if (@mysql_query($sql)) {
    echo '<p>Category details updated.</p>';
  } else {
    echo '<p>Error updating category details: ' .
        mysql_error() . '</p>';
  }

?>

<p><a href="cats.php">Return to category list</a></p>

<?php else: // Allow the user to edit the category

  $id = $_GET['id'];
  $cat = @mysql_query("SELECT name FROM category WHERE id='$id'");
  if (!$cat) {
    exit('<p>Error fetching category details: ' .
        mysql_error() . '</p>');
  }

  $cat = mysql_fetch_array($cat);

  $name = $cat["name"];

  // Convert special characters for safe use
  // as an HTML attribute.
  $name = htmlspecialchars($name);

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p>Edit the category:</p>
<label>Name: <input type="text" name="name" value="<?php echo $name; ?>" /></label><br />
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<input type="submit" value="SUBMIT" /></p>
</form>

<?php endif; ?>

</body>
</html>