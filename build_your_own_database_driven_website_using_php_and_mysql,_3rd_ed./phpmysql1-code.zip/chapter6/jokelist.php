<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Joke CMS: Manage Jokes</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Manage Jokes</h1>
<?php

$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('ijdb')) {
  exit('<p>Unable to locate the joke ' .
      'database at this time.</p>');
}

// The basic SELECT statement
$select = 'SELECT DISTINCT id, joketext';
$from   = ' FROM joke';
$where  = ' WHERE 1=1';

$aid = $_POST['aid'];
if ($aid != '') { // An author is selected
  $where .= " AND authorid='$aid'";
}

$cid = $_POST['cid'];
if ($cid != '') { // A category is selected
  $from  .= ', jokecategory';
  $where .= " AND id=jokeid AND categoryid='$cid'";
}

$searchtext = $_POST['searchtext'];
if ($searchtext != '') { // Some search text was specified
  $where .= " AND joketext LIKE '%$searchtext%'";
}
?>

<table>
<tr><th>Joke Text</th><th>Options</th></tr>

<?php
$jokes = @mysql_query($select . $from . $where);
if (!$jokes) {
  echo '</table>';
  exit('<p>Error retrieving jokes from database!<br />'.
      'Error: ' . mysql_error() . '</p>');
}

while ($joke = mysql_fetch_array($jokes)) {
  echo "<tr valign='top'>\n";
  $id = $joke['id'];
  $joketext = htmlspecialchars($joke['joketext']);
  echo "<td>$joketext</td>\n";
  echo "<td><a href='editjoke.php?id=$id'>Edit</a> | " .
      "<a href='deletejoke.php?id=$id'>Delete</a></td>\n";
  echo "</tr>\n";
}
?>

</table>

<p><a href="jokes.php">New search</a></p>
</body>
</html>