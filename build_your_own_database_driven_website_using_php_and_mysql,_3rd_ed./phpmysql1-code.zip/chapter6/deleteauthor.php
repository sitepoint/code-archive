<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Joke CMS: Delete Author</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php

$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('ijdb')) {
  exit('<p>Unable to locate the joke ' .
      'database at this time.</p>');
}

// Delete all jokes belonging to the author
// along with the entry for the author.
$id = $_GET['id'];
$ok1 = @mysql_query("DELETE FROM joke WHERE authorid='$id'");
$ok2 = @mysql_query("DELETE FROM author WHERE id='$id'");
if ($ok1 and $ok2) {
  echo '<p>Author deleted successfully!</p>';
} else {
  echo '<p>Error deleting author from database!<br />'.
      'Error: ' . mysql_error() . '</p>';
}

?>
<p><a href="authors.php">Return to authors list</a></p>
</body>
</html>