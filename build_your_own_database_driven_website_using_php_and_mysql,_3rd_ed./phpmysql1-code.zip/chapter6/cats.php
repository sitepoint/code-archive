<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Joke CMS: Manage Categories</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Manage Categories</h1>
<ul>
<?php

$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('ijdb')) {
  exit('<p>Unable to locate the joke ' .
      'database at this time.</p>');
}

$cats = @mysql_query('SELECT id, name FROM category');
if (!$cats) {
  exit('<p>Error retrieving categories from database!<br />'.
      'Error: ' . mysql_error(). '</p>');
}

while ($cat = mysql_fetch_array($cats)) {
  $id = $cat['id'];
  $name = htmlspecialchars($cat['name']);
  echo "<li>$name ".
       "<a href='editcat.php?id=$id'>Edit</a> | ".
       "<a href='deletecat.php?id=$id'>Delete</a>";
}

?>
</ul>
<p><a href="newcat.php">Add a new category</a></p>
<p><a href="index.html">Return to front page</a></p>
</body>
</html>