<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Joke CMS: Edit Author</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php

$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('ijdb')) {
  exit('<p>Unable to locate the joke ' .
      'database at this time.</p>');
}

if (isset($_POST['name'])):
  // The author's details have been updated.

  $name = $_POST['name'];
  $email = $_POST['email'];
  $id = $_POST['id'];
  $sql = "UPDATE author SET
          name='$name',
          email='$email'
          WHERE id='$id'";
  if (@mysql_query($sql)) {
    echo '<p>Author details updated.</p>';
  } else {
    echo '<p>Error updating author details: ' .
        mysql_error() . '</p>';
  }

?>

<p><a href="authors.php">Return to authors list</a></p>

<?php
else: // Allow the user to edit the author

  $id = $_GET['id'];
  $author = @mysql_query(
      "SELECT name, email FROM author WHERE id='$id'");
  if (!$author) {
    exit('<p>Error fetching author details: ' .
        mysql_error() . '</p>');
  }

  $author = mysql_fetch_array($author);

  $name = $author['name'];
  $email = $author['email'];

  // Convert special characters for safe use
  // as HTML attributes.
  $name = htmlspecialchars($name);
  $email = htmlspecialchars($email);

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p>Edit the author:</p>
<label>Name: <input type="text" name="name" value="<?php echo $name; ?>" /></label><br />
<label>Email: <input type="text" name="email" value="<?php echo $email; ?>" /></label><br />
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<input type="submit" value="SUBMIT" /></p>
</form>

<?php endif; ?>

</body>
</html>