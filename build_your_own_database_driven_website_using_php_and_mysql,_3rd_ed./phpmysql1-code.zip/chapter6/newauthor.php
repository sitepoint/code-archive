<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Joke CMS: Add New Author</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php if (isset($_POST['name'])):

  // A new author has been entered
  // using the form below.

  $dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
  if (!$dbcnx) {
    exit('<p>Unable to connect to the ' .
        'database server at this time.</p>');
  }

  if (!@mysql_select_db('ijdb')) {
    exit('<p>Unable to locate the joke ' .
        'database at this time.</p>');
  }

  $name = $_POST['name'];
  $email = $_POST['email'];
  $sql = "INSERT INTO author SET
      name='$name',
      email='$email'";
  if (@mysql_query($sql)) {
    echo '<p>New author added</p>';
  } else {
    echo '<p>Error adding new author: ' .
        mysql_error() . '</p>';
  }

?>

<p><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Add another author</a></p>
<p><a href="authors.php">Return to authors list</a></p>

<?php else: // Allow the user to enter a new author ?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p>Enter the new author:</p>
<label>Name: <input type="text" name="name" /></label><br />
<label>Email: <input type="text" name="email" /></label><br />
<input type="submit" value="SUBMIT" />
</form>

<?php endif; ?>

</body>
</html>