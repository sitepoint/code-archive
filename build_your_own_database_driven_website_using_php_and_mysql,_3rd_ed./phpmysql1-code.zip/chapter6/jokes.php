<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Joke CMS: Manage Jokes</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Manage Jokes</h1>
<p><a href="newjoke.php">Create New Joke</a></p>
<?php
  
$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('ijdb')) {
  exit('<p>Unable to locate the joke ' .
      'database at this time.</p>');
}

$authors = @mysql_query('SELECT id, name FROM author');
if (!$authors) {
  exit('<p>Unable to obtain author list from the database.</p>');
}

$cats = @mysql_query('SELECT id, name FROM category');
if (!$cats) {
  exit('<p>Unable to obtain category list from the database.</p>');
}
?>

<form action="jokelist.php" method="post">
<p>View jokes satisfying the following criteria:</p>
<label>By author:
<select name="aid" size="1">
  <option selected value="">Any Author</option>
<?php
while ($author = mysql_fetch_array($authors)) {
  $aid = $author['id'];
  $aname = htmlspecialchars($author['name']);
  echo "<option value='$aid'>$aname</option>\n"; 
}
?>
</select></label><br />
<label>By category:
<select name="cid" size="1">
  <option selected value="">Any Category</option>
<?php
while ($cat = mysql_fetch_array($cats)) {
  $cid = $cat['id'];
  $cname = htmlspecialchars($cat['name']);
  echo "<option value='$cid'>$cname</option>\n"; 
}
?>
</select></label><br />
<label>Containing text: <input type="text" name="searchtext" /></label><br />
<input type="submit" value="Search" />
</form>

<p><a href="index.html">Return to front page</a></p>
</body>
</html>