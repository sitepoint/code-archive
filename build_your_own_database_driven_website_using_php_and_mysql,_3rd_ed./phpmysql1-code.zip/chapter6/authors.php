<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
<head>
<title>Joke CMS: Manage Authors</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Manage Authors</h1>
<ul>
<?php

$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('ijdb')) {
  exit('<p>Unable to locate the joke ' .
      'database at this time.</p>');
}

$authors = @mysql_query('SELECT id, name FROM author');
if (!$authors) {
  exit('<p>Error retrieving authors from database!<br />'.
      'Error: ' . mysql_error() . '</p>');
}

while ($author = mysql_fetch_array($authors)) {
  $id = $author['id'];
  $name = htmlspecialchars($author['name']);
  echo "<li>$name ".
      "<a href='editauthor.php?id=$id'>Edit</a> ".
      "<a href='deleteauthor.php?id=$id'>Delete</a></li>";
}

?>
</ul>
<p><a href="newauthor.php">Add new author</a></p>
<p><a href="index.html">Return to front page</a></p>
</body>
</html>