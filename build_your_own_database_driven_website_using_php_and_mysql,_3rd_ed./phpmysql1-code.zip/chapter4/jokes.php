<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>The Internet Joke Database</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php if (isset($_GET['addjoke'])): // If the user wants to add a joke
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<label>Type your joke here:<br />
<textarea name="joketext" rows="10" cols="40">
</textarea></label><br />
<input type="submit" value="SUBMIT" />
</form>

<?php else: // Default page display

  // Connect to the database server
  $dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
  if (!$dbcnx) {
    exit('<p>Unable to connect to the ' .
        'database server at this time.</p>');
  }

  // Select the jokes database
  if (!@mysql_select_db('ijdb')) {
    exit('<p>Unable to locate the joke ' .
        'database at this time.</p>');
  }

  // If a joke has been submitted,
  // add it to the database.
  if (isset($_POST['joketext'])) {
    $joketext = $_POST['joketext'];
    $sql = "INSERT INTO joke SET
        joketext='$joketext',
        jokedate=CURDATE()";
    if (@mysql_query($sql)) {
      echo '<p>Your joke has been added.</p>';
    } else {
      echo '<p>Error adding submitted joke: ' .
          mysql_error() . '</p>';
    }
  }

  echo '<p>Here are all the jokes in our database:</p>';

  // Request the text of all the jokes
  $result = @mysql_query('SELECT joketext FROM joke');
  if (!$result) {
    exit('<p>Error performing query: ' .
        mysql_error() . '</p>');
  }

  // Display the text of each joke in a paragraph
  while ($row = mysql_fetch_array($result)) {
    echo '<p>' . $row['joketext'] . '</p>';
  }

  // When clicked, this link will load this page
  // with the joke submission form displayed.
  echo '<p><a href="' . $_SERVER['PHP_SELF'] .
      '?addjoke=1">Add a Joke!</a></p>';

endif;
?>
</body>
</html>