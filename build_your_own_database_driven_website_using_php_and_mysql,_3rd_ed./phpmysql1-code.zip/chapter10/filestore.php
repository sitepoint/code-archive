<?php

$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('ijdb')) {
  exit('<p>Unable to locate the joke ' .
      'database at this time.</p>');
}

if (isset($_GET['action'])) {
  $action = $_GET['action'];
} else {
  $action = '';
}

if (($action == 'view' or $action == 'dnld') and isset($_GET['id'])) {
  $id = $_GET['id'];

  // User is retrieving a file
  $sql = "SELECT filename, mimetype, filedata
      FROM filestore WHERE id = '$id'";
  $result = @mysql_query($sql);
  if (!$result) {
    exit('Database error: ' . mysql_error());
  }
  
  $file = mysql_fetch_array($result);
  if (!$file) {
    exit('File with given ID not found in database!');
  }
    
  $filename = $file['filename'];
  $mimetype = $file['mimetype'];
  $filedata = $file['filedata'];
  $disposition = 'inline';
  
  if ($action == 'dnld') {
    $disposition = 'attachment';
    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 5') or
        strpos($_SERVER['HTTP_USER_AGENT'], 'Opera 7')) {
      $mimetype = 'application/x-download';
    }
  }
  
  header("content-disposition: $disposition; filename=$filename");
  header("content-type: $mimetype");
  header('content-length: ' . strlen($filedata));
    
  echo($filedata);
  exit();
  
} elseif ($action == 'del' and isset($_GET['id'])) {
  $id = $_GET['id'];
    
  // User is deleting a file
  $sql = "DELETE FROM filestore WHERE id = '$id'";
  $ok = @mysql_query($sql);
  if (!$ok) {
    exit('Database error: ' . mysql_error());
  }

  header('location: ' . $_SERVER['PHP_SELF']);
  exit();

} elseif (isset($_FILES['upload'])) {

  // Bail out if the file isn�t really an upload.
  if (!is_uploaded_file($_FILES['upload']['tmp_name'])) {
    exit('There was no file uploaded!');
  }
  $uploadfile = $_FILES['upload']['tmp_name'];
  $uploadname = $_FILES['upload']['name'];
  $uploadtype = $_FILES['upload']['type'];
  $uploaddesc = $_POST['desc'];
      
  // Open file for binary reading ('rb')
  $tempfile = fopen($uploadfile, 'rb');

  // Read the entire file into memory using PHP's
  // filesize function to get the file size.
  $filedata = fread($tempfile, filesize($uploadfile));

  // Prepare for database insert by adding backslashes
  // before special characters.
  $filedata = addslashes($filedata);

  // Create the SQL query.
  $sql = "INSERT INTO filestore SET
      filename = '$uploadname',
      mimetype = '$uploadtype',
      description = '$uploaddesc',
      filedata = '$filedata'";

  // Perform the insert.
  $ok = @mysql_query($sql);
  if (!$ok) {
    exit('Database error storing file: ' . mysql_error());
  }

  header('location: ' . $_SERVER['PHP_SELF']);
  exit();

}

// Default page view: lists stored files

$sql = 'SELECT id, filename, mimetype, description FROM filestore';
$filelist = @mysql_query($sql);
if (!$filelist) {
  exit('Database error: ' . mysql_error());
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>PHP/MySQL File Repository</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>

<h1>PHP/MySQL File Repository</h1>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>"
    method="post" enctype="multipart/form-data">
  <p><label>Upload File:<br />
    <input type="file" name="upload" /></label></p>
  <p><label>File Description:<br />
    <input type="text" name="desc" maxlength="255" /></label></p>
  <p><input type="submit" value="Upload" /></p>
</form>

<p>The following files are stored in the database:</p>
<table>
<tr>
  <th>Filename</th>
  <th>Type</th>
  <th>Description</th>
</tr>
<?php

if (mysql_num_rows($filelist) > 0) {
  while ($f = mysql_fetch_array($filelist)) {
    ?>

<tr valign="top">
  <td>
    <a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=view&id=<?php echo $f['id']; ?>">
      <?php echo $f['filename']; ?></a>
  </td>
  <td><?php echo $f['mimetype']; ?></td>
  <td><?php echo $f['description']; ?></td>
  <td>
    [<a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=dnld&id=<?php echo $f['id']; ?>"
      >Download</a> |
    <a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=del&id=<?php echo $f['id']; ?>"
      onclick="return confirm('Delete this file?');"
      >Delete</a>]
  </td>
</tr>

    <?php
  }
} else {
  ?>
  <tr><td colspan="3">No Files!</td></tr>
  <?php
}
?>
</table>
</body>
</html>