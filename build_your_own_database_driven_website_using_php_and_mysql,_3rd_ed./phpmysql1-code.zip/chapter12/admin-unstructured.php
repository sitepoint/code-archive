<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Site Administration Area</title>
<meta http-equiv="Content-Type"
  content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php
// Process login
if (isset($_POST['username'])) {
  // Check credentials
  if ($_POST['username'] == 'foxmulder' and
      $_POST['password'] == 'trustno1') {
    $_SESSION['authorized'] = TRUE;
  }
}

// Process logout
if (isset($_REQUEST['logout'])) {
  unset($_SESSION['authorized']);
}

// Check login
if (isset($_SESSION['authorized'])) {
  // Display secure information
?>
<h1>Administration Options</h1>
<ul>
  <li><a href="news.php">News items</a></li>
  <li><a href="jobs.php">Job advertisements</a></li>
  <li><a href="comps.php">Competitions</a></li>
  <li><a href="events.php">Special events</a></li>
</ul>
<p><a href="<?php echo $_SERVER['PHP_SELF']; ?>?logout=1">Log
  Out</a></p>
<?php
} else {
  // Display login form
?>
<h1>Please log in for access</h1>
<div>
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    <label>User name:
      <input type="text" name="username" /></label><br />
    <label>Password:
      <input type="password" name="password" /></label>
    <input type="submit" value="Log In" />
  </form>
</div>
<?php
}
?>
</body>
</html>