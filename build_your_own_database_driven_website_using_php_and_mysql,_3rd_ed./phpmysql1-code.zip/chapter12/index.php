<?php include_once 'access.inc.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>An Unprotected Page</title>
<meta http-equiv="Content-Type"
  content="text/html; charset=iso-8859-1" />
</head>
<body>
<p>This is an unprotected page. Anyone can view it.</p>
<?php if (loggedIn()): ?>
  <p>You are currently logged in!
    <a href="<?php echo $_SERVER['PHP_SELF']; ?>?logout=1"
    >Logout</a></p>
<?php endif; ?>
</body>
</html>