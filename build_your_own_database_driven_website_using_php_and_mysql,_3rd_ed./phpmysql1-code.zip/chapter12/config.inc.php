<?php
define('ADMIN_USER', 'foxmulder');
define('ADMIN_PASS', 'trustno1');
?>