<?php
$dbcnx = @mysql_connect('localhost', 'root', 'mypasswd');
if (!$dbcnx) {
  exit('Error connecting to the site database.');
}

if (!@mysql_select_db('ijdb', $dbcnx)) {
  exit('Error opening the site database.');
}
?>