<?php
function area($x, $y) {
  return $x * $y;
}

function perimeter($x, $y) {
  return ($x + $y) * 2;
}
?>