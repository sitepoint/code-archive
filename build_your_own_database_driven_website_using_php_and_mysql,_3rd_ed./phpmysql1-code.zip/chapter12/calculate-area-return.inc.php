<?php
return $x * $y;
?>