<?php
  define('TOP_JOKES_COUNT', 10);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Top <?php echo TOP_JOKES_COUNT; ?> Jokes</title>
<meta http-equiv="Content-Type"
  content="text/html; charset=iso-8859-1" />
</head>
<body>
<p>The top <?php echo TOP_JOKES_COUNT; ?> jokes on our site are:</p>
<?php
include 'db.inc.php';

$result = @mysql_query("SELECT * FROM joke ORDER BY timesviewed DESC LIMIT " . TOP_JOKES_COUNT);
if (!$result) {
  exit('Error fetching jokes from the site database.');
}
while ($joke = mysql_fetch_array($result)) {
  echo '<p>' . $joke['joketext'] . '</p>';
}
?>
</body>
</html>