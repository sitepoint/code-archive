<h2>User Options</h2>
<ul class="menu">
  <li>Subscribe</li>
  <li>Unsubscribe</li>
  <li>View Archives</li>
</ul>
<?php
if (!$administrator) {
  return;
}
?>
<h2>Administrator Options</h2>
<ul class="menu">
  <li>Manage List</li>
  <li>Create an Issue</li>
  <li>Send an Issue</li>
  <li>Edit Template</li>
</ul>