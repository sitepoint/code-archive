<?php
$area = $x * $y;
?>