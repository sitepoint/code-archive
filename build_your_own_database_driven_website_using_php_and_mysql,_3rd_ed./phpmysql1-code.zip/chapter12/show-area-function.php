<?php
function area($x, $y)
{
  return $x * $y;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Area Example </title>
<meta http-equiv="Content-Type"
  content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php
$area = area(3, 5);
echo "<p>Area: $area</p>"; // Outputs 15
?>
</body>
</html>