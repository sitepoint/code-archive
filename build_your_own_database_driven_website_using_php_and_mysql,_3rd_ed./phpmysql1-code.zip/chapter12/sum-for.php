<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unlimited Arguments</title>
<meta http-equiv="Content-Type"
  content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php
function sum() {
  $numargs = func_num_args();
  $sum = 0;
  for ($i = 0; $i < $numargs; $i++) {
    $sum += func_get_arg($i);
  }
  return $sum;
}

echo sum() . '<br />';
echo sum(1, 1) . '<br />';
echo sum(123, 456, 789) . '<br />';
?>
</body>
</html>