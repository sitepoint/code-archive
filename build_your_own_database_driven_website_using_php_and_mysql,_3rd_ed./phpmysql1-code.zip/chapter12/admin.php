<?php require 'secure.inc.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Site Administration Area</title>
<meta http-equiv="Content-Type"
  content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Administrative Options</h1>
<ul>
  <li><a href="news.php">News items</a></li>
  <li><a href="jobs.php">Job advertisements</a></li>
  <li><a href="comps.php">Competitions</a></li>
  <li><a href="events.php">Special events</a></li>
</ul>
<p><a href="<?php echo $_SERVER['PHP_SELF']; ?>?logout=1"
  >Logout</a></p>
</body>
</html>