<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <title>Client and Server-side form validation</title>
    <link type="text/css" rel="stylesheet" href="exampleValidation.css">
  </head>
  <body>
    <h1>Client and server-side form validation</h1>
    <?php
      include 'serverValidation.php';
    ?>
  </body>
</html>
