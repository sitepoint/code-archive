<p id="footer">
	The contents of this webpage are copyright &copy; 1998 -
	<?php echo date('Y'); ?> Example Pty. Ltd. All Rights
	Reserved.
</p>