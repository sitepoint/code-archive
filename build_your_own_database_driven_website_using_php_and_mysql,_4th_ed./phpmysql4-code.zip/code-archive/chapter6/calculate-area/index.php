<?php
include_once 'area-function.inc.php';

$area = area(3, 5);

include 'output.html.php';
?>