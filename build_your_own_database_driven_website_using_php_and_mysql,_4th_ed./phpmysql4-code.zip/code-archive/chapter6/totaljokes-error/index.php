<?php
include_once 'totaljokes-function.inc.php';

$totaljokes = totaljokes();

include 'output.html.php';
?>