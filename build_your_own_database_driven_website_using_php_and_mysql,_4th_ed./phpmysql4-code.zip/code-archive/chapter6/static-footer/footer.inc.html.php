<p id="footer">
	The contents of this webpage are copyright &copy; 1998 - 2009
	Example Pty. Ltd. All Rights Reserved.
</p>