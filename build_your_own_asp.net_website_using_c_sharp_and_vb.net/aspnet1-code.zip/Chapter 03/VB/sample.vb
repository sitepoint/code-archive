Imports System
Imports System.Web.UI
Imports System.Web.UI.WebControls

' All code behind classes generally inherit from Page
Public Class Sample
     Inherits Page

     ' Declare the presentation elements on the ASPX page
     Protected WithEvents lblMessage As Label
     Protected WithEvents btnSubmit As Button

     ' Here's the Click handler just as it appeared before
     Sub Click(s As Object, e As EventArgs)
          lblMessage.Text = "Hello World"
     End Sub
End Class