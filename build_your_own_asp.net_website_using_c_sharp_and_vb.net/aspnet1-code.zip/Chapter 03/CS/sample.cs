using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public class Sample : System.Web.UI.Page 
{
     protected Button btnSubmit;
     protected Label lblMessage;

     public void Click(Object s, EventArgs e) {
          lblMessage.Text = "Hello World";
     }
}
