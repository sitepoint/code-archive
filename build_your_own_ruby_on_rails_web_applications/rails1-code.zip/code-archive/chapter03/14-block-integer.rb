class Car
  WHEELS = 4                # class constant
  @@number_of_cars = 0      # class variable
  @mileage = 0              # instance variable
  
  def initialize
    @@number_of_cars = @@number_of_cars + 1
  end
  
  def self.count
    @@number_of_cars
  end
  
  def mileage=(x)
    @mileage = x
  end
  
  def mileage
    @mileage
  end
end

# Block example using Integer class
10.times { Car.new }
puts "#{Car.count} cars have been produced."