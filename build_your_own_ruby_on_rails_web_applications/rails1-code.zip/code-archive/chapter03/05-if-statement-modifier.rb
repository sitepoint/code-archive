class Car
  WHEELS = 4                # class constant
  @@number_of_cars = 0      # class variable
  @mileage = 0              # instance variable
  
  def initialize
    @@number_of_cars = @@number_of_cars + 1
  end
  
  def self.count
    @@number_of_cars
  end
  
  def mileage=(x)
    @mileage = x
  end
  
  def mileage
    @mileage
  end
end

class StretchLimo < Car
  WHEELS = 6                # class constant
  @@televisions = 1         # class variable
  
  def turn_on_television
    # Invoke code for switching on on-board TV here
  end
end

class PontiacFirebird < Car
end

class VolksWagen < Car
end

# Example if statement modifier.
puts "No cars have been produced yet." if Car.count.zero?