class StoryController < ApplicationController
  scaffold :story
end