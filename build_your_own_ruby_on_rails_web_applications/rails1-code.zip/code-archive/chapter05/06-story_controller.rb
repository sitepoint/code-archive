class StoryController < ApplicationController
  def index
  end
end