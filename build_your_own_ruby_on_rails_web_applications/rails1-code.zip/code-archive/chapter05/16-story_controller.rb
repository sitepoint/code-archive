class StoryController < ApplicationController
  def index
    @story = Story.find(:first, :order => 'RAND()')
  end
end