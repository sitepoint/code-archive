require File.dirname(__FILE__) + '/../test_helper'

class StoryTest < Test::Unit::TestCase
  fixtures :stories, :votes

  def test_should_require_name
    s = Story.create(:name => nil)
    assert s.errors.on(:name)
  end
  
  def test_should_require_link
    s = Story.create(:link => nil)
    assert s.errors.on(:link)
  end
  
  def test_should_create_story
    s = Story.create(
      :name => 'My test submission',
      :link => 'http://www.testsubmission.com/')
    assert s.valid?
  end
  
  def test_votes_association
    assert_equal [ votes(:first), votes(:second) ],
      stories(:first).votes
  end
end