class StoryController < ApplicationController
  def index
    @story = Story.find(:first, :order => 'RAND()')
  end
  
  def new
    @story = Story.new(params[:story])
    if request.post? and @story.save
      flash[:notice] = 'Story submission succeeded'
      redirect_to :action => 'index'
    end
  end
  
  def show
    @story = Story.find_by_permalink(params[:permalink])
  end
  
  def vote
    @story = Story.find(params[:id])
    @story.votes.create

    respond_to do |wants|
      wants.html { redirect_to :action => 'show', :id => @story.permalink }
      wants.js   { render }
    end
  end
end