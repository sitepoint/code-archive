require File.dirname(__FILE__) + '/../test_helper'

class VoteTest < Test::Unit::TestCase
  fixtures :votes, :stories
  
  def test_story_association
    assert_equal stories(:first), votes(:first).story
  end
end