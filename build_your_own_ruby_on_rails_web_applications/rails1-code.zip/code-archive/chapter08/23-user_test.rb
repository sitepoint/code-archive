require File.dirname(__FILE__) + '/../test_helper'

class UserTest < Test::Unit::TestCase
  fixtures :users, :stories, :votes
  
  def test_stories_association
    assert_equal 2, users(:patrick).stories_count
    assert_equal stories(:first), users(:patrick).stories.first
  end
end
