class AccountController < ApplicationController

  def login
    if request.post?
      @current_user = User.find_by_login_and_password(
        params[:login], params[:password])
      unless @current_user.nil?
        session[:user_id] = @current_user.id
        redirect_to :controller => 'story'
      end
    end
  end
  
  def logout
    session[:user_id] = @current_user = nil
  end

end