require File.dirname(__FILE__) + '/../test_helper'
require 'story_controller'

# Re-raise errors caught by the controller.
class StoryController; def rescue_action(e) raise e end; end

class StoryControllerTest < Test::Unit::TestCase
  fixtures :stories, :votes, :users
  
  def setup
    @controller = StoryController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  def test_should_show_index
    get :index
    assert_response :success
    assert_template 'index'
    assert_not_nil assigns(:story)
  end
  
  def test_should_show_new
    get :new
    assert_response :success
    assert_template 'new'
    assert_not_nil assigns(:story)
  end
  
  def test_should_show_new_form
    get :new
    assert_select 'form p', :count => 3
  end
  
  def test_should_add_story
    post :new, :story => {
      :name => 'test story',
      :link => 'http://www.test.com/'
    }
    assert ! assigns(:story).new_record?
    assert_redirected_to :action => 'index'
    assert_not_nil flash[:notice]
  end
  
  def test_should_reject_missing_story_attribute
    post :new, :story => { :name => 'story without a link' }
    assert assigns(:story).errors.on(:link)
  end
  
  def test_should_show_story
    get :show, :permalink => 'my-shiny-weblog'
    assert_response :success
    assert_template 'show'
    assert_equal stories(:first), assigns(:story)
  end
  
  def test_should_show_story_vote_elements
    get :show, :permalink => 'my-shiny-weblog'
    assert_select 'h2 span#vote_score'
    assert_select 'ul#vote_history li', :count => 2
    assert_select 'div#vote_link'
  end
  
  def test_should_accept_vote
    assert ! stories(:another).has_votes?
    post :vote, :id => 2
    assert assigns(:story).reload.has_votes?
  end
  
  def test_should_render_rjs_after_vote_with_ajax
    @request.env['HTTP_ACCEPT'] = 'text/javascript'
    xml_http_request :post, :vote, :id => 2
    assert_response :success
    assert_template 'vote'
  end
  
  def test_should_redirect_after_vote_with_get
    get :vote, :id => 2
    assert_redirected_to :action => 'show', :permalink => 'sitepoint-forums'
  end
  
  def test_should_show_story_submitter
    get :show, :permalink => 'my-first-story'
    assert_select 'p.submitted_by', 'patrick'
  end
  
  def test_should_indicate_not_logged_in
    get :index
    assert_select 'div#login_logout em', 'Not logged in.'
  end

  def test_should_show_navigation_menu
    get :index
    assert_select 'ul#navigation li', 2
  end
  
  def test_should_indicate_logged_in_user
    get_with_user :index
    assert_equal users(:patrick), assigns(:current_user)
    assert_select 'div#login_logout em a', '(Logout)' 
  end
  
  protected
  
  def get_with_user(action, parameters = nil, session = nil, flash = nil)
    get action, parameters, :user_id => users(:patrick).id
  end
  
  def post_with_user(action, parameters = nil, session = nil, flash = nil)
    post action, parameters, :user_id => users(:patrick).id
  end
  
end