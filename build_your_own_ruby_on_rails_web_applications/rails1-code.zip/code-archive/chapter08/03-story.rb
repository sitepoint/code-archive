class Story < ActiveRecord::Base
  validates_presence_of :name, :link
  belongs_to :user
  has_many :votes
  def latest_votes
    votes.find(:all, :order => 'id DESC', :limit => 3)
  end
end