require File.dirname(__FILE__) + '/../test_helper'

class StoryTest < Test::Unit::TestCase
  fixtures :stories

  def test_should_require_name
    s = Story.create(:name => nil)
    assert s.errors.on(:name)
  end
end