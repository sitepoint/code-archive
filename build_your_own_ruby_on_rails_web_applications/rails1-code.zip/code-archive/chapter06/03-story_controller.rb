class StoryController < ApplicationController
  
  def index
    @story = Story.find(:first, :order => 'RAND()')
  end
  
  def new
    @story = Story.new(params[:story])
    if request.post?
      @story.save
    end
  end
end