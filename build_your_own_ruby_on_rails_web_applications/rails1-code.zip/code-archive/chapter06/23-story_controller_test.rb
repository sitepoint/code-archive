require File.dirname(__FILE__) + '/../test_helper'
require 'story_controller'

# Re-raise errors caught by the controller.
class StoryController; def rescue_action(e) raise e end; end

class StoryControllerTest < Test::Unit::TestCase
  fixtures :stories
  def setup
    @controller = StoryController.new
    @request = ActionController::TestRequest.new
    @response = ActionController::TestResponse.new
  end

  def test_should_show_index
    get :index
    assert_response :success
    assert_template 'index'
    assert_not_nil assigns(:story)
  end
  
  def test_should_show_new
    get :new
    assert_response :success
    assert_template 'new'
    assert_not_nil assigns(:story)
  end
  
  def test_should_show_new_form
    get :new
    assert_select 'form p', :count => 3
  end
  
  def test_should_add_story
    post :new, :story => {
      :name => 'test story',
      :link => 'http://www.test.com/'
    }
    assert ! assigns(:story).new_record?
    assert_redirected_to :action => 'index'
    assert_not_nil flash[:notice]
  end
end