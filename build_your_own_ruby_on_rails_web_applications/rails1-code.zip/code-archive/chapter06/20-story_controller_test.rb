require File.dirname(__FILE__) + '/../test_helper'
require 'story_controller'

# Re-raise errors caught by the controller.
class StoryController; def rescue_action(e) raise e end; end

class StoryControllerTest < Test::Unit::TestCase
  fixtures :stories
  def setup
    @controller = StoryController.new
    @request = ActionController::TestRequest.new
    @response = ActionController::TestResponse.new
  end

  def test_should_show_index
    get :index
    assert_response :success
    assert_template 'index'
    assert_not_nil assigns(:story)
  end
end