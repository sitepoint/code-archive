require File.dirname(__FILE__) + '/../test_helper'

class StoryTest < Test::Unit::TestCase
  fixtures :votes, :stories, :users

  def test_should_require_name
    s = Story.create(:name => nil)
    assert s.errors.on(:name)
  end
  
  def test_should_require_link
    s = Story.create(:link => nil)
    assert s.errors.on(:link)
  end
  
  def test_should_create_story
    s = Story.create(
      :name => 'My test submission',
      :link => 'http://www.testsubmission.com/')
    assert s.valid?
  end
  
  def test_votes_association
    assert_equal [ votes(:first), votes(:second) ],
      stories(:first).votes
  end
  
  def test_should_return_highest_vote_id_first
    assert_equal votes(:second), stories(:first).latest_votes.first
  end

  def test_should_return_3_latest_votes
    10.times { stories(:first).votes.create }
    assert_equal 3, stories(:first).latest_votes.size
  end
  
  def test_user_association
    assert_equal users(:patrick), stories(:first).user
  end

  def test_should_increment_votes_counter_cache
    stories(:second).votes.create
    stories(:second).reload
    assert_equal 1, stories(:second).attributes['votes_count']
  end
  
  def test_should_decrement_votes_counter_cache
    stories(:first).votes.first.destroy
    stories(:first).reload
    assert_equal 1, stories(:first).attributes['votes_count']
  end
end