var Highlight =
{
  init: function()
  {
    new Effect.Highlight("introduction", {startcolor: "#FF0000", endcolor: "#0000FF", duration: 2});
  }
};

Core.start(Highlight);