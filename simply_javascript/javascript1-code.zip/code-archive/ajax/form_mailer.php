<?php
header("Content-type: text/html");
?>