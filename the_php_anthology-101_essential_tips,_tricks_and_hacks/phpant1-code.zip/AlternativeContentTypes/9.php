<?php
header('Content-type: text/vnd.wap.wml');
echo '<?xml version="1.0"?>';
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN"
    "http://www.wapforum.org/DTD/wml_1.1.xml">

<wml>

<card id="index" title="PHP and WAP in Action" newcontext="true">
<big>Menu:</big><br />
<a href="#news">News</a><br/>
<a href="#products">Products</a><br/>
</card>

<card id="news" title="News">
<p align="right"><small><a href="#index">Back</a></small></p>
<big>News:</big><br />
<a href="#news1">Something happened</a><br />
<a href="#news2">Something else happened</a><br />
</card>

<card id="news1" title="Something happened">
<p align="right"><small><a href="#index">Back</a></small></p>
Yep something happened.
</card>

<card id="news2" title="Something else happened">
<p align="right"><small><a href="#index">Back</a></small></p>
Oh and something else happened
</card>

<card id="products" title="For Sale">
<p align="right"><small><a href="#index">Back</a></small></p>
<big>Products:</big><br />
Here are some things to buy...
</card>

</wml>