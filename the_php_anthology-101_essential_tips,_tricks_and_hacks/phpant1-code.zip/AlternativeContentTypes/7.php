<?php
echo ( date ('H:i:s d M Y') );
?>