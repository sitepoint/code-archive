<?php
// No time limit for large documents
set_time_limit(0);

// Include the MySQL class
require_once('Database/MySQL.php');

// Include the data fetching articles class
require_once('ExampleApps/Articles.php');

// Include the ArticlePDF class
require_once('ExampleApps/ArticlePDF.php');

// Include the HTMLtoPDF converter
require_once('XML/HTMLtoPDF.php');

// Define font path - MODIFY THIS!!!
$fontPath = 'c:/htdocs/phpanth/SPLIB/ThirdParty/rospdf/fonts/';

// Define variables for MySQL class
$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Settings for PDF generation
$baseUrl='http://localhost/phpanth/AlternativeContentTypes/4.php?id=';
$producer='Sitepoint';


// Instantiate MySQL class
$db = & new MySQL($host,$dbUser,$dbPass,$dbName);

// Instantiate Articles class
$articles = new Articles($db);

$table="<table>\n";

// If viewing an article
if ( isset($_GET['id']) ) {

    // Get the article from the client class
    if ( $articles->getArticle($_GET['id']) ) {

        // Fetch the article object
        $article=$articles->fetch();
        
        // If PDF format has been requested
        if ( isset ( $_GET['mime'] ) && $_GET['mime']=='pdf' ) {

            // Instantiate the PdfArticle class
            $articlePDF=& new ArticlePDF($baseUrl.$article->id(),$fontPath);

            // Add the "meta" information
            $articlePDF->addInfo($article->title(),
                                 $article->author(),
                                 $producer,
                                 $article->published());

            // Add the title page
            $articlePDF->addTitlePage($article->title(),
                                      $article->author(),
                                      $article->published(),
                                      $article->intro());

            // Instantiate the HTMLtoPDF class
            $htmlToPdf=new HTMLtoPDF($articlePDF);

            // Parse the article body
            $htmlToPdf->parse($article->body());

            // Get back the ArticlePDF object
            $articlePDF = $htmlToPdf->getPdf();

            // Display the PDF document
            $articlePDF->display($article->title().'.pdf');

            // Terminate execution to avoid mixed headers
            exit();
        } else {

            // Build the article into an HTML table
            $heading=$article->title();
            $table.="<tr>\n<td class=\"date\">".$article->published().
                    "</td>\n</tr>\n";
            $table.="<tr>\n<td class=\"author\">by ".$article->author().
                    "</td>\n</tr>\n";
            $table.="<tr>\n<td>".$article->intro()."</td>\n</tr>\n";
            $table.="<tr>\n<td>".$article->body()."</td>\n</tr>\n";
            $table.="<tr>\n<td align=\"center\"><a href=\"".
                    $_SERVER['PHP_SELF']."?id=".$article->id().
                    "&mime=pdf\">PDF Version</a></td>\n</tr>";
        }
    } else {
        $table.="<tr>\n<td>Service unavailable at this time</td>\n</tr>";
    }
} else {
    // Get an array of articles
    if ( $articles->getArticles() ) {
        $heading='Latest Articles';
        // Loop through each article building the table
        while ( $article=$articles->fetch() ) {
            $table.="<tr>\n";
            $table.="<td><a href=\"".$_SERVER['PHP_SELF'].
                    "?id=".$article->id()."\">".$article->title()."</a></td>";
            $table.="<td>".$article->author()."</td>";
            $table.="<td>".$article->published()."</td>";
            $table.="</tr>\n";
            $table.="<tr>\n";
            $table.="</tr>\n";
        }
    } else {
        $table.="<tr>\n<td>Service unavailable at this time</td>\n</tr>";
    }

}
$table.="</table>\n";
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Sitepoint Articles </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
h1 {
    font-family: verdana;
    font-size: 15px;
    font-weight: bold;
    color: navy;
}
table {
    background-color: silver;
    width: 450px;
}
th {
    background-color: #f2f3f5;
    font-family: verdana;
    font-size: 11px;
    font-weight: bold;
    text-align: left;
}
td {
    background-color: white;
    font-family: verdana;
    font-size: 11px;
}
a {
    font-weight: bold;
}
.title {
    font-size: 14px;
    font-weight: bold;
}
.date {
    font-weight: italic;
}
.author {
    font-weight: italic;
    text-align: right;
}
</style>
</head>
<body>
<h1><?php echo ( $heading ); ?></h1>
<?php echo ( $table ); ?>
</body>
</html>