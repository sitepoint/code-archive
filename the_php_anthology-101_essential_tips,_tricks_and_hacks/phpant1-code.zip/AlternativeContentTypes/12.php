<?php
// Include the Magic Quotes stripper
require_once('MagicQuotes/strip_quotes.php');

// Include the MySQL class
require_once('Database/MySQL.php');

// Include the QuickForm class
require_once ("HTML/QuickForm.php");

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// A function for comparing password
function cmpPass($element, $confirmPass)
{
    global $form;
    $password = $form->getElementValue('password');
    return ($password == $confirmPass);
}

// Instantiate QuickForm
$form = new HTML_QuickForm('edit_user','POST');

if ( isset($_GET['id'] ) ) {
    // Instantiate the MySQL class
    $db=& new MySQL($host,$dbUser,$dbPass,$dbName);

    $id = mysql_escape_string($_GET['id']);
    $sql = "SELECT * FROM user WHERE user_id = '".$id."'";
    $result = $db->query($sql);
    $row = $result->fetch();
    unset($row['password']);

    $form->setDefaults($row);
}

// The login field
$form->addElement('text','login','Username');
$form->addRule('login','Please provide a username','required',false,'client');
$form->addRule('login','Username must be at least 6 characters','minlength',6,'client');
$form->addRule('login','Username cannot be more than 50 characters','maxlength',50,'client');
$form->addRule('login','Username can only contain letters and numbers','alphanumeric',NULL,'client');

// The password field
$form->addElement('password','password','Password');
$form->addRule('password','Please provide a password','required',false,'client');
$form->addRule('password','Password must be at least 6 characters','minlength',6,'client');
$form->addRule('password','Password cannot be more than 12 characters','maxlength',50,'client');
$form->addRule('password','Password can only contain letters and numbers','alphanumeric',NULL,'client');

// The field for confirming the password
$form->addElement('password','confirmPass','Confirm');
$form->addRule('confirmPass','Please confirm password','required',false,'client');
$form->addRule('confirmPass','Passwords must match','compare','function');

// The email field
$form->addElement('text','email','Email Address');
$form->addRule('email','Please an email address','required',false,'client');
$form->addRule('email','Please enter a valid email address','email',false,'client');
$form->addRule('email','Email cannot be more than 50 characters','maxlength',50,'client');

// The first name field
$form->addElement('text','firstName','First Name');
$form->addRule('firstName','Please enter your first name','required',false,'client');
$form->addRule('firstName','First name cannot be more than 50 characters','maxlength',50,'client');

// The last name field
$form->addElement('text','lastName','Last Name');
$form->addRule('lastName','Please enter your last name','required',false,'client');
$form->addRule('lastName','Last name cannot be more than 50 characters','maxlength',50,'client');

// The signature field
$form->addElement('textarea','signature','Signature');

// Add a submit button called submit and "Send" as the text for the button
$form->addElement('submit','submit','Update');
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Edit User </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
body {
    background: white;
    font-family: verdana;
}
</style>
</head>
<body>
<h1>Edit User</h1>
<?php echo ( $form->display() );?>
</body>
</html>