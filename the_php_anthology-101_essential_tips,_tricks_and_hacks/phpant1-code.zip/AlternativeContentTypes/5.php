<?php
header ('Content-type: image/svg+xml');
echo '<?xml version="1.0" encoding="ISO-8859-1" standalone="no"?>';
?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20010904//EN"
    "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">
<svg xmlns="http://www.w3.org/2000/svg"
     xmlns:xlink="http://www.w3.org/1999/xlink">
    <circle cx="50" cy="50" r="40" fill="navy"/>
</svg>