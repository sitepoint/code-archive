<?php
error_reporting(E_ALL ^ E_NOTICE);

// Include the R&OS PDF Classes
require_once('ThirdParty/rospdf/class.pdf.php');
require_once('ThirdParty/rospdf/class.ezpdf.php');

// Some information about the article
$title="Build your own Database Driven Website using PHP & MySQL";
$author="Kevin Kank";
$producer="Sitepoint";
$articleUrl="http://www.sitepoint.com/article/228";
$date="October 1st 2001";

// Get the intro from a text file
$intro=file('intro.txt');
$intro=implode('',$intro);

// Get the body from a text file
$body=file('body.txt');
$body=implode('',$body);

// Start the PDF document ( A4 size x:595.28 y:841.89 )
$pdf =& new Cezpdf();

// Add document information (File > Document Properties > Summary)
$pdf->addInfo('Title',$title);
$pdf->addInfo('Author',$author);
$pdf->addInfo('Producer',$producer);
$pdf->addInfo('CreationDate',$date);

// Set the page margins
$pdf->ezSetMargins(40,40,155.28,90);

// Set up header and footer as a recurring object
$headfoot = $pdf->openObject(); // Create object
$pdf->saveState(); // Save document state
$pdf->addJpegFromFile('sitepoint_logo.jpg',430,813,70,20); // Add logo
$pdf->setStrokeColor(0,0.2,0.4); // set line color
$pdf->setLineStyle(2,'round'); // set line style
$pdf->line(155.28,811.89,505.28,811.89); // Add top line
$pdf->line(155.28,30,505.28,30); // Add bottom line
$pdf->restoreState(); // Restore document state
$pdf->closeObject(); // Close the object

// Set up bottom link object
$bottomUrl = $pdf->openObject(); // Create object
$pdf->saveState(); // Save document state
$pdf->selectFont('rospdf/fonts/Helvetica.afm'); // Select font
$pdf->addText(155.28,24,6,'Found at: '.$articleUrl); // Add footer text
$pdf->restoreState(); // Restore document state
$pdf->closeObject(); // Close the object

// Add the $headfoot object to every page (all,odd or even)
$pdf->addObject($headfoot,'all'); // Add to 'all' pages

// Add the bottom url to even pages
$pdf->addObject($bottomUrl,'even'); // Add to 'even' pages

// Add the title page
$pdf->selectFont('rospdf/fonts/Helvetica-Bold.afm'); // Change font
$pdf->ezSetY(650); // Set current Y position
$pdf->saveState(); // Save document state
$pdf->setColor(1,0.4,0); // Change the text color
$pdf->ezText($title,20,array('justification'=>'center')); // Add Title
$pdf->restoreState(); // Restore state (text color returns to black)
$pdf->ezSetDy(-50); // Move down 50
$pdf->ezText('by '.$author,15,array('justification'=>'center')); // Author
$pdf->ezSetDy(-50); // Move down 50
$pdf->ezText("<c:alink:".$articleUrl.">".$articleUrl."</c:alink>",
            11,array('justification'=>'centre')); // Add article link
$pdf->ezSetDy(-50); // Move down 50
$pdf->ezText($date,13,array('justification'=>'center')); // Date
$pdf->ezSetDy(-50); // Move down 50
$pdf->selectFont('rospdf/fonts/Helvetica.afm'); // Change font
$pdf->ezText($intro,10,array('justification'=>'full')); // Intro
$pdf->ezNewPage(); // New page

// Start the rest of the document
$pdf->ezStartPageNumbers(505,24,6); // Page numbering
$pdf->selectFont('rospdf/fonts/Helvetica.afm'); // Change font
$pdf->ezText($body,10,array('justification'=>'full')); // Body

// Display the document
$pdf->ezStream();
?>