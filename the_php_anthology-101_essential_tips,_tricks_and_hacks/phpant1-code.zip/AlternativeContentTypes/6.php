<?php
// Send SVG header
header ('Content-type: image/svg+xml');
echo '<?xml version="1.0" encoding="ISO-8859-1" standalone="no"?>';

// Edit this line
$timeUrl='http://localhost/sitepoint/AlternativeContentTypes/7.php';
?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20010904//EN"
    "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">
<svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"  onload="init(evt);">

    <script type="text/ecmascript">
<![CDATA[
    var clock;

    function init(e) {
     if ( window.svgDocument == null ) {
        svgDocument = e.target.ownerDocument;
     }
     clock = svgDocument.getElementById("clock").firstChild;
       getTime();
    }
    function getTime() {
     getURL('<?php echo ( $timeUrl ); ?>',showTime);
    }
    function showTime(response) {
     clock.data = response.content;
     setTimeout('getTime()',1000);
    }
]]>
    </script>
    <text id="clock" x="80" y="20" fill="navy" text-anchor="middle">
    Time goes here
    </text>
</svg>