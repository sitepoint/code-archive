<?php
// Include MySQL class
require_once('Database/MySQL.php');

// Define the base URL for editing users - MODIFY THIS!!!
$baseUrl = 'http://localhost/phpanth/AlternativeContentTypes/12.php';

// Define variables for MySQL class
$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL class
$db = & new MySQL($host,$dbUser,$dbPass,$dbName);

// Select all the available users
$sql = "SELECT * FROM user ORDER BY user_id";
$result = $db->query($sql);

// Send XUL content header
header( "Content-type: application/vnd.mozilla.xul+xml" );
echo '<?xml version="1.0"?>';
echo '<?xml-stylesheet href="chrome://global/skin/" type="text/css"?>';
?>
<window id="admin" title="Admin Interface"
        xmlns:html="http://www.w3.org/1999/xhtml"
        xmlns="http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul">
  <script type="application/x-javascript">
      <![CDATA[
        var baseUrl = '<?php echo ( $baseUrl ); ?>'; /* Base URL */
        /* Redirects XUL browser element to correct editing URL */
        function editUser (id) {
            var user_edit=document.getElementById('user_edit');
            user_edit.setAttribute('src',baseUrl+id);
        }
      ]]>
  </script>
  <grid flex="1" style="background-color: silver">
    <columns>
      <column flex="1" />
      <column flex="3" />
    </columns>
    <rows>
      <row flex="1">
        <browser id="user_edit" src="<?php echo ( $baseUrl ); ?>"/>
        <listbox flex="1">
          <listhead>
            <listheader/>
            <listheader label="Login"/>
            <listheader label="Name"/>
            <listheader label="Email"/>
          </listhead>
          <listcols>
            <listcol flex="0.3"/>
            <listcol flex="1"/>
            <listcol flex="1"/>
            <listcol flex="1"/>
          </listcols>
        <?php
        $alt = '#d3d3d3';
        while ( $user = $result->fetch() ) {
            $alt = $alt == '#d3d3d3' ? 'silver' : '#d3d3d3';
        ?>
          <listitem
            onclick="editUser('?id=<?php echo ( $user['user_id'] ); ?>')"
            style="background-color: <?php echo ( $alt ); ?>">
            <listcell label="<?php echo ( $user['user_id'] ); ?>"/>
            <listcell label="<?php echo ( $user['login'] ); ?>"/>
            <listcell label="<?php echo ( $user['firstName'].' '.$user['lastName'] ); ?>" flex="1"/>
            <listcell label="<?php echo ( $user['email'] ); ?>"/>
          </listitem>
        <?php
        }
        ?>
        </listbox>
      </row>
    </rows>
  </grid>
</window>