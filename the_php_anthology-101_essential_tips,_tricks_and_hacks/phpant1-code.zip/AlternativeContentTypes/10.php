<?php
// Switch off error notices - required for HAWHAW
error_reporting(E_ALL ^ E_NOTICE);

// Include MySQL, Articles and Article class
require_once('Database/MySQL.php');
require_once('ExampleApps/Articles.php');

// Include the HAWHAW library
require_once('ThirdParty/hawhaw/hawhaw.php');

// Define variables for MySQL class
$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// (Modify this) Specify the root URL of the site
$url='http://localhost/sitepoint/AlternativeContentTypes/10.php';

// Instantiate MySQL class
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Instantiate Articles class
$articles = new Articles($db);

// Instantiate the HAW_Deck root node
$wml = new HAW_deck('Sitepoint Articles');

// For web browsers...
$wml->set_waphome('http://www.sitepoint.com');

// Instantiate HAW_link for the "Home" url
$home = new HAW_link('Home',$url);

// Add the link to the WML document
$wml->add_link($home);

// If viewing a single article
if ( isset($_GET['id']) ) {

    // Prepare the article
    if ( $articles->getArticle($_GET['id']) ) {

        // Get the article object
        $article = $articles->fetch();

        // Create a HAW_Table
        $table = new HAW_table();

        // Create a HAW_Row
        $row = new HAW_row();

        // Create a text node for the title
        $title = new HAW_text($article->title(),
            HAW_TEXTFORMAT_BOLD);

        // Add the title to the row
        $row->add_column($title);

        // Add the row to the table
        $table->add_row($row);

        // The author row
        $row = new HAW_row();
        $author = new HAW_text($article->author(),
            HAW_TEXTFORMAT_SMALL);
        $row->add_column($author);
        $table->add_row($row);

        // The date row
        $row = new HAW_row();
        $date = new HAW_text($article->published(),
            HAW_TEXTFORMAT_SMALL);
        $row->add_column($date);
        $table->add_row($row);

        // The intro
        $row = new HAW_row();
        $intro = new HAW_text(strip_tags($article->intro()),
            HAW_TEXTFORMAT_SMALL);
        $row->add_column($intro);
        $table->add_row($row);

        // Add table to document
        $wml->add_table($table);

    } else {
        // Error message
        $wml->add_text(new HAW_text('Sorry:',HAW_TEXTFORMAT_BIG));
        $wml->add_text(new HAW_text('Service unavailable at this time'));
    }
} else {
    if ( $articles->getArticles() ) {
        // Build a table and loop through the rows
        $table = new HAW_table();
        while ( $article = $articles->fetch() ) {
            $row = new HAW_row();
            $title = new HAW_link($article->title(),
                $url.'?id='.$article->id());
            $author = new HAW_text($article->author(),
                HAW_TEXTFORMAT_SMALL);
            $row->add_column($title);
            $row->add_column($author);
            $table->add_row($row);
        }
        $wml->add_table($table);
    } else {
        $wml->add_text(new HAW_text('Sorry:',HAW_TEXTFORMAT_BIG));
        $wml->add_text(new HAW_text('Service unavailable at this time'));
    }
}

// Display the page
$wml->create_page();
?>