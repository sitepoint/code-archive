<?php
// Include the PEAR::XML_HTMLSax
require_once('XML/XML_HTMLSax.php');

// Include the ParseHTML class
require_once('XML/ParseHTML.php');

// A Classic violation of XML rules...
$html=<<<EOD
<p>If you've ever trawled the PHP listings over at Hotscripts in search
of a content management system to save you from writing your own,
you've probably run into <a href="http://developer.ez.no">eZ publish</a>,
a PHP-based CMS application, and thought <i><b>"Wow!"</i></b> Jubilant,
you tried to install it... to no avail. Desperately you tried reading
the code, only to discover it made no sense whatsoever. Finally you
skulked away to a quiet corner to lick your wounds, resorting to
PHP Nuke instead.

<p>This series is all about eZ publish and why it deserves the
title of "PHP's killer app". We'll start from the ground up: first,
we'll install eZ publish in your development environment.
EOD;

// Create the parser
$parseHTML=new ParseHTML();

// Parse the HTML
$parseHTML->parse($html);
?>