<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> SVG Network Clock </title>
</head>
<style type="text/css">
body {
    font-family: verdana;
    font-size: 13px;
    font-weight: bold;
    color: red;
}
</style>
<body>
The time sponsored by SVG is<br />
<object data="6.php" width="200" height="30"
  type="image/svg+xml" />
</body>
</html>