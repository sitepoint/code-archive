<?php
// Include the PdfArticle class
require_once('ExampleApps/ArticlePDF.php');

// Define font path - MODIFY THIS!!!
$fontPath = 'c:/htdocs/phpanth/SPLIB/ThirdParty/rospdf/fonts/';

// Some information about the article
$title="Build your own Database Driven Website using PHP & MySQL";
$author="Kevin Kank";
$producer="Sitepoint";
$articleUrl="http://www.sitepoint.com/article/228";
$date="October 1st 2001";

// Get the intro from a text file
$intro=file('intro.txt');
$intro=implode('',$intro);

// Get the body from a text file
$body=file('body.txt');
$body=implode('',$body);

$pdfArticle=new ArticlePDF($articleUrl,$fontPath);
$pdfArticle->addInfo($title,$author,$producer,$date);
$pdfArticle->addTitlePage($title,$author,$date,$intro);
$pdfArticle->addText($body);
$pdfArticle->display();
?>