<?php
// Specify a file to download
$fileName = 'sample.zip';
$mimeType = 'applicaton/zip';
if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 5') or
    strpos($_SERVER['HTTP_USER_AGENT'], 'Opera 7')) {
  $mimeType = 'application/x-download';
}

// Tell the browser it's a file for downloading
header('content-disposition: attachment; filename=' . $fileName);
header('content-type: ' . $mimeType);
header('content-length: ' . filesize($fileName));

// Display the file
readfile($fileName);
?>