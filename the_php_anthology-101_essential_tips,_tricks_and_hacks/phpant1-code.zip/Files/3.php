<?php
// Read file and display it directly
readfile('demo/writeSecureScripts.html');
?>