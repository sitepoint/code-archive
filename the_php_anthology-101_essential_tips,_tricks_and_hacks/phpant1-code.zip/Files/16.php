<?php
$host='www.sitepoint.com';   // Remote host
$port='80';                  // Port number
$timeout='10';               // Timeout in seconds
$uri='/print/758';           // Page to fetch

// Open remote socket
if ( !$fp=fsockopen($host,$port,$errNo,$errMsg,$timeout) )
    die ( 'Error connecting: '.$errNo.' - '.$errMsg );

// Build an HTTP request header
$requestHeader="GET ".$uri." HTTP/1.0\r\n";
$requestHeader.="Host: ".$host."\r\n\r\n";

// Send the request header
fputs ($fp, $requestHeader);

// Loop while the connection is good and not as end of file
while ( !feof ($fp) ) {
    // Get a chunk to the next linefeed
    $chunk = fgets($fp);
    echo $chunk;
}

// Close the file handle!
fclose( $fp );
?>