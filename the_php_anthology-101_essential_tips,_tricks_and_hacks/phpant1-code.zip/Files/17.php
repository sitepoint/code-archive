<?php
// Set time limit to infinite
set_time_limit(0);

// Define server and target directory
$ftpServer='ftp.uselinux.org';
$targetDir='/pub/redhat/updates/8.0/en/os/i386/';

// Connect to server
if ( !$fp = ftp_connect($ftpServer,21,30) ) {
    die ( 'Connection failed' );
}

// Login anonymously
if ( !ftp_login ( $fp, 'anonymous','you@yourdomain.com' ) ) {
    die ( 'Login failed' );
}

// Change directory
if ( !ftp_chdir ($fp,$targetDir) ) {
    die ( 'Unable to change directory to: '.$targetDir );
}


// Display the remote directory location
echo ( '<b>Current Directory:</b> <code>'.ftp_pwd($fp).'<code><br />' );

echo ( '<b>Files Available:</b><br />' );

// Get a list of files on the server
$files = ftp_nlist($fp,'./');

// Display the files
foreach ( $files as $file ) {
    echo ( $file.'<br />' );
}
?>