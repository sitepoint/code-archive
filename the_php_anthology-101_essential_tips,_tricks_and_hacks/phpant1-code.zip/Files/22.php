<?php
// Include MySQL class
require_once('Database/MySQL.php');

// Include PEAR::Archive_Tar
require_once('Archive/Tar.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Instantiate Archive_Tar
$tar = new Archive_Tar('demo/articles.tar.gz','gz');

$sql = "SELECT * FROM articles";

$result = $db->query($sql);

while ( $row = $result->fetch() ) {
    // Add a string as a file
    $tar->addString('articles/'.$row['article_id'].'.txt',$row['body']);
}
echo ( 'Article archive created' );
?>