<?php
// Include PEAR::Archive_Tar
require_once('Archive/Tar.php');

// Instantiate Archive_Tar
$tar = new Archive_Tar('demo/demo.tar.gz','gz');

// An array of files to archive
$files = array (
    'demo/example.ini',
    'demo/writeSecureScripts.html'
    );

// Create the archive file
$tar->create($files);

echo ( 'Archive created' );
?>