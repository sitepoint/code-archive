<?php
// Include PEAR::Archive_Tar
require_once('Archive/Tar.php');

// Instantiate Archive_Tar
$tar = new Archive_Tar('demo/demo.tar.gz');

// Create the archive file
$tar->extract('extract');

echo ( 'Archive extracted' );
?>