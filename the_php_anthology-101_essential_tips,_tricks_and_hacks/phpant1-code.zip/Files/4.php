<?php
// Variable to store the location of the file
$location='demo/writeSecureScripts.html';

// Open the file handle for reading
$fp=fopen($location,'r');

// Read the complete file into a string
$file = fread ( $fp, filesize($location) );

// Close the file handle!
fclose( $fp );

echo ( $file );
?>