<?php
// Set time limit to infinite
set_time_limit(0);

// Include PEAR::Net_FTP
require_once 'NET/FTP.php';

// Define server, username and password
$ftpServer='ftp.uselinux.org';
$ftpUser='anonymous';
$ftpPass='user@domain.com';

// Local Directory to place files
$localDir='ftpdownloads/';

// Remote Directory to fetch files from
$remoteDir='/pub/software/web/html-utils/';

// Instantiate Net_FTP
$ftp = new Net_FTP();

// Set host and login details
$ftp->setHostname($ftpServer);
$ftp->setUsername($ftpUser);
$ftp->setPassword($ftpPass);

// Connect and login
$ftp->connect();
$ftp->login();

// Specify the extensions file
$ftp->getExtensionsFile("extensions.ini");

// Get the remote directory contents
if ( $ftp->getRecursive($remoteDir,$localDir) ) {
    echo ( 'Files transfered successfully' );
} else {
    echo ( 'Transfer failed' );
}
?>