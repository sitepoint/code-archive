<?php
$file = 'demo/writeSecureScripts.html';

// Is it a file? Could be is_dir() for directory
if ( is_file ( $file ) )
    echo ( 'Yep: '.$file.' is a file<br />' );

// Is it readable
if ( is_readable ( $file ) )
    echo ( $file.' can be read<br />' );

// Is it writeable
if ( is_writeable ( $file ) )
    echo ( $file.' can be written to<br />' );

// When was it last modified?
$modified = date ( "D d M g:i:s",filemtime($file) );
echo ( $file.' last modifed at '.$modified.'<br />' );

// When was it last accessed?
$accessed = date ( "D d M g:i:s",fileatime($file) );
echo ( $file.' last accessed at '.$accessed.'<br />' );
?>