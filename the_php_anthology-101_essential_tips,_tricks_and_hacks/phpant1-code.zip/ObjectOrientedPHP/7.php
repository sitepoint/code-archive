<?php
// Look and feel contains $color and $size
class LookAndFeel {
    var $color;
    var $size;
    function LookAndFeel () {
        $this->color='white';
        $this->size='medium';
    }
    function getColor() {
        return $this->color;
    }
    function getSize () {
        return $this->size;
    }
    function setColor ($color) {
        $this->color=$color;
    }
    function setSize ($size) {
        $this->size=$size;
    }
}

// Output deals with building content for display
class Output  {
    var $lookandfeel;
    var $output;
    // Constructor takes LookAndFeel as it's argument
    function Output (& $lookandfeel) {
        $this->lookandfeel= & $lookandfeel;
    }
    function buildOutput () {
        $this->output='Color is '.$this->lookandfeel->getColor().
            ' and size is '.$this->lookandfeel->getSize();
    }
    function display () {
        $this->buildOutput();
        return $this->output;
    }
}

// ControlPanel changes settings in the application
class ControlPanel {
    var $lookandfeel;
    // Takes LookAndFeel as it's argument
    function ControlPanel (& $lookandfeel) {
        $this->lookandfeel=& $lookandfeel;
    }
    function changeColor ($color) {
        $this->lookandfeel->setColor($color);
    }
    function changeSize ($size) {
        $this->lookandfeel->setSize($size);
    }
}

$lookandfeel=new LookAndFeel(); // Create an instance of LookAndFeel
$output=new Output ($lookandfeel); // Pass it to an instance of Output


// Use ControlPanel to modify some settings
$cp= new ControlPanel($lookandfeel);
$cp->changeColor('red');
$cp->changeSize('large');

// Display the output
echo ($output->display());
?>