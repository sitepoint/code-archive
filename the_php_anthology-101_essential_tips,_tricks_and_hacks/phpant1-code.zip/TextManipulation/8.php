<?php
$string = 'Hello World!';

$length = strlen($string);

for ($i = 0; $i < $length; $i++) {
    echo $string[$i] . '<br />';
}
?>