<?php
$text='This is <b>bold</b> text';

// Strip that tag
echo (strip_tags($text));
?>