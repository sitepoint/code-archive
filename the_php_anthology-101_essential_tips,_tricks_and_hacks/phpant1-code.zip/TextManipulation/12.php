<?php
// Include PEAR::Validate
require_once('Validate.php');

// Include PEAR::XML_HTMLSax
require_once('TextManipulation/FormFilter.php');

// Include file to strip quotes if needed
require_once('MagicQuotes/strip_quotes.php');

// If the form is submitted...
if ( isset ($_POST['submit']) ) {
    // Instantiate the form filter
    $formFilter = & new FormFilter();

    // Filter the message
    if (false===($filtered_message = $formFilter->filter($_POST['message'])))
        $filtered_message = $formFilter->getError();
}
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Form HTML Filter</title>
</head>
<body>
<b>Add your comment:</b><br />
<form action="<?php echo ( $_SERVER['PHP_SELF'] ); ?>" method="POST">
<textarea cols="40" rows="5" name="message"></textarea><br />
<input type="submit" name="submit" value=" Post ">
</form>
<p>Allowed tags: &lt;a&gt; &lt;b&gt; &lt;strong&gt; &lt;i&gt; &lt;em&gt;</p>
<?php
if ( isset ( $filtered_message ) ) {
    echo ( "<p>Your post:</b><br />\n<code>\n".
        htmlspecialchars($filtered_message)."</code>\n" );
}
?>
</body>
</html>