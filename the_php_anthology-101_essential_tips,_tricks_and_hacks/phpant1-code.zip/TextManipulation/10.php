<?php
// Include the word filter
require_once('TextManipulation/WordFilter.php');

// An array of words to replace
$badWords = array ('telly','tubby','tubbies','byebye');

// Include the word file with the list of bad words
$wordFilter=new WordFilter($badWords);

// $text simulates some data from the database
$text= 'Time for telly tubbies! I like tubbies so much. ByeBye!';

// Filter the words
$text = $wordFilter->filter($text);

echo ( $text );
?>