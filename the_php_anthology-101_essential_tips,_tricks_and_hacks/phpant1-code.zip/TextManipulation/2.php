<?php
$text='This is <b>bold</b> and this is <i>italic</i>.
       What about this <a href="http://www.php.net">link</a>?';

// Strip those tags
echo (strip_tags($text,'<b><i>'));
?>