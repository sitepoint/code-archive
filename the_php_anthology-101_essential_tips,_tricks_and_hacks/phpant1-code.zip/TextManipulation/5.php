<?php
$text = <<<EOD
PHP (recursive acronym for "PHP: Hypertext Preprocessor") is a widely-used
Open Source general-purpose scripting language that is especially suited
for Web development and can be embedded into HTML.
EOD;

$lines = explode("\n", $text);

echo "<table border=\"1\">\n";

foreach ($lines as $line) {
    echo "<tr>\n<td>$line</td>\n</tr>\n";
}

echo "</table>\n";
?>