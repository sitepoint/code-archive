<?php
// Places part of a string inside an HTML tag
function addTag($text,$word, $tag)
{
    $length = strlen($word);
    $start  = strpos($text, $word);
    $word   = '&lt;' . $tag . '>' . $word . '&lt;/' . $tag . '>';
    return substr_replace($text,$word, $start, $length);
}
$text = <<<EOD
PHP (recursive acronym for "PHP: Hypertext Preprocessor") is a widely-used
Open Source general-purpose scripting language that is especially suited
for Web development and can be embedded into HTML.
EOD;

$word = 'general-purpose';
echo addTag($text, $word,'b');
?>