<?php
$text = <<<EOD
PHP (recursive acronym for "PHP: Hypertext Preprocessor") is a widely-used
Open Source general-purpose scripting language that is especially suited
for Web development and can be embedded into HTML.
EOD;

$word = 'general-purpose';

echo str_replace($word, '<b>' . $word . '</b>', $text);
?>