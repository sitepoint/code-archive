<?php
$string = '  This has whitespace at both ends   ';

// Remove that whitespace!
$string = trim($string);
?>