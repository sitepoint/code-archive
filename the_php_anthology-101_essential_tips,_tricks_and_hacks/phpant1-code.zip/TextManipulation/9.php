<?php
// Include the BBCode class
require_once('ThirdParty/bbcode/bbcode.inc.php');

// Include the SitepointBBCode class which defines custom BBCode tags
require_once('TextManipulation/SitepointBBCode.php');

$text=<<<EOD
Here is some <b>bold HTML which is unparsed</b>.

[i]This[/i] text [bg=yellow]illustrates[/bg]
the [b]bbcode[/b] class in action[/u].

You can visit [url=http://www.sitepointforums.com/]Sitepointforums[/url]
with it [color=c5c6c7]just[/color] like the [size=15]real thing[/size].

You can even [s]email[/s] the
[align=center][email=editor@sitepoint.com]editor[/email][/align].
EOD;

// Replace any real HTML with entities
$text=htmlspecialchars($text);

$bbCode=new SitepointBBCode();
echo ( nl2br($bbCode->parse($text)) );
?>