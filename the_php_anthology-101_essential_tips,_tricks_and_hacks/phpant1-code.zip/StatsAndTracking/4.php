<?php
// Include phpOpenTracker
include ('phpOpenTracker.php');

// Redefine document name
$params = array ( 'document' => 'Article: Stats with PHP' );

// Log
phpOpenTracker::log($params);

echo ( 'This page view was logged!' );
?>