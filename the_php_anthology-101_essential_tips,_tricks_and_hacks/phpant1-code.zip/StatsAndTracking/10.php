<?php
// Include phpOpenTracker
require_once('phpopentracker.php');

$num_visitors = phpOpenTracker::get(
  array(
    'api_call' => 'all_paths',
    'result_format' => 'xml'
  )
);

echo ('<pre>' );
print_r($num_visitors);
echo ('</pre>' );
?>