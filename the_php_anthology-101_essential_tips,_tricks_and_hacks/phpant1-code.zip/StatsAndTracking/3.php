<?php
$webbugUrl = 'image.php?document_url='.$_SERVER['REQUEST_URI'].
             '&referer='.@$_SERVER['HTTP_REFERER'];
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type"
    content="text/html" charset="iso-8859-1" />
<title> phpOpenTracker Web Bug </title>
</head>
<body>
<img alt="" src="<?php echo($webbugUrl); ?>" />
This page is logged.
</body>
</html>
