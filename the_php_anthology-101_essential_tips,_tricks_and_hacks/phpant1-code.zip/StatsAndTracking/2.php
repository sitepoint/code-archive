<?php
// Include phpOpenTracker
include ('phpOpenTracker.php');

// Log
phpOpenTracker::log();

echo ( 'This page view was logged!' );
?>
