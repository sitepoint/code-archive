<?php
// Include phpOpenTracker
require_once('phpopentracker.php');

$page_count = phpOpenTracker::get(
  array(
    'api_call' => 'page_impressions',
    'range' => 'today'
  )
);

$num_visitors = phpOpenTracker::get(
  array(
    'api_call' => 'visits',
    'range' => 'today'
  )
);

echo ( 'Total page impressions for '.date('d M Y').': '.$page_count.'<br />' );
echo ( 'Total visitors for '.date('d M Y').': '.$num_visitors.'<br />' );
?>