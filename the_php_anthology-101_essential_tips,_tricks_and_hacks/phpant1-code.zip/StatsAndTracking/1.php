<?php
echo ( 'Nearest IP address: '.@$_SERVER['REMOTE_ADDR'].'<br />' );
echo ( 'Nearest Hostname: '.@gethostbyaddr(@$_SERVER['REMOTE_ADDR']).'<br />' );
echo ( 'Useragent: '.@$_SERVER['HTTP_USER_AGENT'].'<br />' );
echo ( 'Request: '.@$_SERVER['REQUEST_URI'].'<br />' );
echo ( 'Preferred Language: '.@$_SERVER['HTTP_ACCEPT_LANGUAGE'].'<br />' );
echo ( 'Referer: '.@$_SERVER['HTTP_REFERER'].'<br />' );

echo ( '<p>Click <a href="'.$_SERVER['PHP_SELF'].'?link=referer">here</a>' );
?>