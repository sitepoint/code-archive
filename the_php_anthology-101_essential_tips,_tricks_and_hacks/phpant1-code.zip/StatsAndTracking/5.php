<?php
// Note rand() must be seeded for PHP < 4.2.0
// see: http://www.php.net/rand
$uniqueId=md5('example'. uniqid(rand(), TRUE));

// Set the cookie
if ( !isset ($_COOKIE['MyIdentifier']) ) {
    setcookie ('MyIdentifier', $uniqueId,time()+60*60*24*120, "/");
    echo ( 'Cookie Set' );
} else {
    echo ('MyIdentifier: '.$_COOKIE['MyIdentifier'] );
}
?>