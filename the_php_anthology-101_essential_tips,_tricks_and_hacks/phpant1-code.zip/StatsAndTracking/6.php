<?php
// Include the phpOpenTracker code
require_once 'phpOpenTracker.php';

// The link for forward to is passed using the GET variable "url"
if (isset($_GET['url'])) {
  // Convert HTML entities back to URI entities
  $exitURL = str_replace('&amp;', '&', base64_decode($_GET['url']));

  // Set up the config, database and container objects
  $config    = &phpOpenTracker_Config::singleton();
  $db        = &phpOpenTracker_DB::singleton();
  $container = &phpOpenTracker_Container::singleton(
    array(
      'initNoSetup' => true
    )
  );

  // Perform the query which logs the exit URL
  $db->query(
    sprintf(
      'UPDATE %s
          SET exit_target_id = %d
        WHERE accesslog_id   = %d
          AND document_id    = %d
          AND timestamp      = %d',

      $config['accesslog_table'],
      $db->storeIntoDataTable($config['exit_targets_table'], $exitURL),
      $container['accesslog_id'],
      $container['document_id'],
      $container['timestamp']
    )
  );

  // Redirect to the new site
  header('Location: http://' . $exitURL);
}
?>