<?php
// Modifies links to point an exit handling script
function encodeExitUrls($content,$exitScript) {
    return preg_replace(
        "#<a href=(\"|')http://([^\"']+)(\"|')#ime",
        '"<a href=\"$exitScript?url=".base64_encode(\'\\2\')."\""',
        $content);
}

$content=<<<EOD
This is some text containing a <a href="http://www.sitepoint.com">link
to Sitepoint.com</a>
EOD;

echo ( encodeExitUrls ( $content,'6.php' ) );
?>