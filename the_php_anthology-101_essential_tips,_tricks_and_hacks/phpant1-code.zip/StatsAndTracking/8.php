<?php
// Include phpOpenTracker
require_once('phpopentracker.php');

$visitors_online = phpOpenTracker::get(
  array(
    'api_call' => 'visitors_online'
  )
);

echo ( 'There are currently '.count($visitors_online).' visitors online' );
?>