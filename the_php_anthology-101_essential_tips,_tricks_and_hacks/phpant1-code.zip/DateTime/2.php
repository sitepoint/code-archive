<?php
// Include MySQL class
require_once ('Database/MySQL.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Get the UNIX timestamp for right now
$now=time();

// A query to create an article
$sql = "INSERT INTO articles
          SET
            title='Test Article',
            body='This is a test...',
            author='HarryF',
            published='".$now."'";

// Perform the query
$result=$db->query($sql);

if ( $result->isError() )
    echo ( 'Problem: '.$result->isError() );
else
    echo ( 'Article inserted' );
?>