<?php
echo ( 'Current time: '.date ('H:i:s T O' ).'<br />' );
putenv ('TZ=Europe/London');
echo ( 'New time: '.date ('H:i:s T O' ) );
?>