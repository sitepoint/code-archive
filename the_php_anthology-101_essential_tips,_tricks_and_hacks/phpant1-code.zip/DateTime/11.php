<?php
// Include DateMath class
require_once ('DateTime/DateMath.php');

// Instantiate DateMath class 22nd March 2003
$dateMath= new DateMath(2003,3,22,0,0,0);

echo ( '22nd March 2003 is the;<br />' );
echo ( ($dateMath->dayOfWeek(true) + 1).
       $dateMath->suffix($dateMath->dayOfWeek(true) + 1).
       ' day of the week<br />');
echo ( $dateMath->weekOfYear().
       $dateMath->suffix($dateMath->weekOfYear()).
       ' week of the year<br />');
echo ( $dateMath->dayOfYear().
       $dateMath->suffix($dateMath->dayOfYear()).
       ' day of the year<br />');
?>