<?php
// Include DateMath class
require_once ('DateTime/DateMath.php');
// Include the TimeUnitValidator
require_once ('DateTime/TimeUnitValidator.php');

// Include Calendar and subclasses
require_once ('DateTime/Calendar.php');
require_once ('DateTime/Year.php');
require_once ('DateTime/Month.php');

//Initialize $_GET variables to this year and month if not set
if ( !isset($_GET['y']) ) $_GET['y'] = date('Y');
if ( !isset($_GET['m']) ) $_GET['m'] = date('m');

// Create a new Year object
$year=new Year($_GET['y']);

$selectedMonths = array(
    new Month($_GET['y'],$_GET['m'])
    );

// Instruct the Year to build Month objects
$year->build($selectedMonths);

$prev = $_SERVER['PHP_SELF']."?y=".$year->lastYear();
$next = $_SERVER['PHP_SELF']."?y=".$year->nextYear();

// Start building HTML
$calendar="<table>\n";
$calendar.=
    "<caption><a href=\"".$prev."\" class=\"nav\"><<</a> ".
    $year->thisYear().
    " <a href=\"".$next."\" class=\"nav\">>></a></caption>\n";

while ( $month = $year->fetch() ) {
    $calendar.="<tr>\n";
    $link = $_SERVER['PHP_SELF']."?y=".$month->thisYear()."&m=".$month->thisMonth();
    if ( !$month->isSelected() ) {
        $calendar.="<td><a href=\"".$link."\">".date('F',$month->thisMonth(true))."</a></td>\n";
    } else {
        $calendar.="<td class=\"selected\"><a href=\"".$link."\">".date('F',$month->thisMonth(true))."</a></td>\n";
    }
    $calendar.="</tr>\n";
}
$calendar.="</table>\n";
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Months in the Year </title>
<style type="text/css">
table {
    background-color: silver;
    width: 300px;
}
caption {
    font-family: verdana;
    font-size: 11px;
    text-align: center;
    background-color: white;
}
.nav {
    font-size: 9px;
}
td {
    font-family: verdana;
    font-size: 11px;
}
.selected {
    background-color: yellow;
}
</style>
</head>
<body>
<?php
echo ( $calendar );
?>
</body>
</html>