<?php
// Include DateMath class
require_once ('DateTime/DateMath.php');

// Build an array for the next ten years
$thisyear = date('Y');
$years = range ($thisyear, $thisyear + 10);

// Find the leap years
foreach ( $years as $year ) {
    $dateMath= new DateMath($year,1,1,0,0,0);
    if ( !$dateMath->isLeapYear() )
        echo ( $year.' is not a leap year<br />');
    else
        echo ( $year.' is a leap year!<br />');
}
?>