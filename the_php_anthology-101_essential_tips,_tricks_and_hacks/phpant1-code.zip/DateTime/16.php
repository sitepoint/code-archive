<?php
function getMicroTime() {
    list($usec,$sec) = explode(" ",microtime()); 
    return ((float)$usec + (float)$sec); 
} 

$start = getMicroTime();
    
for ($i=0; $i < 5; $i++){
    sleep (1);
}

echo ( 'Script took: '.(getMicroTime() - $start) );
?>