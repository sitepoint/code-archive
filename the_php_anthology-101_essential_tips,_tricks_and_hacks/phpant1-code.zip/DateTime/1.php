<?php
echo ('1st Jan 1899: '.mktime(0,0,0,1,1,1899).'<br />');
echo ('1st Jan 1902: '.mktime(0,0,0,1,1,1902).'<br />');
echo ('31st Dec 1969: '.mktime(0,0,0,12,31,1969).'<br />');
echo ('1st Jan 1790: '.mktime(0,0,0,1,1,1970).'<br />');
echo ('1st Jan 1937: '.mktime(0,0,0,1,1,2037).'<br />');
echo ('1st Jan 2038: '.mktime(0,0,0,1,1,2038).'<br />');
echo ('19th Jan 2038: '.mktime(0,0,0,1,19,2038).'<br />');
echo ('20th Jan 2038: '.mktime(0,0,0,1,20,2038).'<br />');
echo ('1st Jan 2039: '.mktime(0,0,0,1,19,2039).'<br />');
?>