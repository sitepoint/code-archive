<?php
// Include MySQL class
require_once ('Database/MySQL.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Timestamp for last week
$lastWeek=mktime(0,0,0,date('m'),date('d')-7,date('Y'));

$sql="SELECT * FROM articles
        WHERE
          published > '".$lastWeek."'
        ORDER BY
          published
        DESC";

// Perform the query
$result=$db->query($sql);

while ( $row=$result->fetch() ) {
    echo ( $row['title'].': '.
        date('F j, Y',$row['published']).'<br />' );
}
?>