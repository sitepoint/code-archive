<?php
// Include DateMath class
require_once ('DateTime/DateMath.php');

// Instantiate DateMath class 22nd March 2003
$dateMath= new DateMath(2003,03,22);

echo ( '22nd March 2003 is a '.$dateMath->dayOfWeek() );
?>