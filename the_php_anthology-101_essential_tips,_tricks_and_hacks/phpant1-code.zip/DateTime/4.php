<?php
// Include MySQL class
require_once 'Database/MySQL.php';

$host   = 'localhost'; // Hostname of MySQL server
$dbUser = 'harryf';    // Username for MySQL
$dbPass = 'secret';    // Password for user
$dbName = 'sitepoint'; // Database name

// Instantiate MySQL connection
$db = &new MySQL($host, $dbUser, $dbPass, $dbName);

// Select articles
$sql = "SELECT
          *,
          DATE_FORMAT(published,'%M %e, %Y') as published
        FROM articles
        WHERE published > UTC_TIMESTAMP() - INTERVAL 7 DAY
        ORDER BY published DESC";

// Perform the query
$result = $db->query($sql);

while ($row = $result->fetch()) {
    echo $row['title'] . ': ' .
         $row['published'] . '<br />';
}
?>