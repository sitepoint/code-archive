<?php
// If a cached version exists use it...
if ( file_exists('./cache/2.cache') ) {

    // Read and display the file
    readfile('./cache/2.cache');
    exit();

}

// Start buffering the output
ob_start();

// Display some HTML
?>

<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Cached Page </title>
</head>
<body>
This page was cached with PHP's
<a href="http://www.php.net/outcontrol">Output Control Functions</a>
</body>
</html>

<?php
// Get the contents of the buffer
$buffer = ob_get_contents();

// Stop buffering and display the buffer
ob_end_flush();

// Write a cache file from the contents
$fp = fopen('./cache/2.cache','w');
fwrite($fp,$buffer);
fclose($fp);
?>