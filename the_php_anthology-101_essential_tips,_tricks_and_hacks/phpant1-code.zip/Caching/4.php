<?php
// Include the PEAR::Cache_Lite Output class
require_once('Cache/Lite/Output.php');

// Define options for Cache_Lite
$options = array(
    'cacheDir' => './cache/',
    'fileNameProtection' => false,
    'writeControl' => TRUE,
    'readControl' => TRUE,
    'readControlType' => 'strlen'
);

// Instantiate Cache_Lite_Output
$cache = new Cache_Lite_Output($options);

// Set lifetime for this "chunk"
$cache->setLifeTime(604800);

// Start the cache with an id and group for this chunk
if ( !$cache->start('header','Static') ) {
?>
    <!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
    <html>
    <head>
    <title> PEAR::Cache_Lite example </title>
    </head>
    <body>
    <h2>PEAR::Cache_Lite example</h2>
    The header time is now: <?php echo (date('H:i:s')); ?><br />
    <?php
// Stop and write the cache
    $cache->end();
}

$cache->setLifeTime(5);
if ( !$cache->start('body','Dynamic') ) {
    echo ( 'The body time is now: '.date('H:i:s').'<br />' );
    $cache->end();
}

$cache->setLifeTime(604800);
if ( !$cache->start('footer','Static') ) {
    ?>
    The footer time is now: <?php echo (date('H:i:s')); ?><br />
    </body>
    </html>
    <?php
    $cache->end();
}
?>