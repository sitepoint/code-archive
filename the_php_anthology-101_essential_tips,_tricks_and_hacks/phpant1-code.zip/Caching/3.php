<?php
/**
 * Write a cache file
 * @param string contents of the buffer
 * @param string filename to use when creating cache file
 * @return void
 */
function writeCache ($content,$filename) {
    $fp = fopen('./cache/'.$filename,'w');
    fwrite($fp,$content);
    fclose($fp);
}

/**
 * Checks for cache files
 * @param string filename of cache file to check for
 * @param int maximum age of the file in seconds
 * @return mixed either the contents of the cache or false
 */
function readCache ($filename,$expiry) {
    if ( file_exists('./cache/'.$filename) ) {
        if ( (time() - $expiry) >  filemtime('./cache/'.$filename) ) {
            return false;
        }
        $cache = file('./cache/'.$filename);
        return implode('',$cache);
    }
    return false;
}

// Start buffering the output
ob_start();

// Handle the page header
if ( !$header = readCache('3_header.cache',604800) ) {
    // Display the header
    ?>

    <!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
    <html>
    <head>
    <title> Chunked Cached Page </title>
    </head>
    <body>
    The header time is now: <?php echo (date('H:i:s')); ?><br />
    <?php
    $header = ob_get_contents();
    ob_clean();
    writeCache($header,'3_header.cache');
}

// Handle body of the page
if ( !$body = readCache('4_body.cache',5) ) {
    echo ( 'The body time is now: '.date('H:i:s').'<br />' );
    $body = ob_get_contents();
    ob_clean();
    writeCache($body,'3_body.cache');
}

// Handle the footer of the page
if ( !$footer = readCache('3_footer.cache',604800) ) {
    ?>

    The footer time is now: <?php echo (date('H:i:s')); ?><br />
    </body>
    </html>

    <?php
    $footer = ob_get_contents();
    ob_clean();
    writeCache($footer,'3_footer.cache');
}
// Stop buffering
ob_end_clean();

// Display the contents of the page
echo ( $header.$body.$footer );
?>