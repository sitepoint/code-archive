<?php
// Include PEAR::SOAP Client class
require_once('SOAP/Client.php');

// Include PEAR::Cache_Lite_Function
require_once ( 'Cache/Lite/Function.php' );

// Instantiate the SOAP_WSDL class using the online document
$wsdl=new SOAP_WSDL('http://live.capescience.com/wsdl/GlobalWeather.wsdl');

// Instantiate the ArticleClient class
$articleClient=$wsdl->getProxy();

// Define options for Cache_Lite_Function
// NOTE: fileNameProtection = true !
$options = array(
    'cacheDir' => './cache/',
    'fileNameProtection' => true,
    'writeControl' => TRUE,
    'readControl' => TRUE,
    'readControlType' => 'strlen',
    'defaultGroup' => 'SOAP'
);

// Instantiate Cache_Lite_Function
$cache = new Cache_Lite_Function($options);

// Instantiate the SOAP_WSDL class using the online document
$wsdl=new SOAP_WSDL('http://live.capescience.com/wsdl/GlobalWeather.wsdl');

// Get the proxy class for the service
$stationInfo = $wsdl->getProxy();

$countries = $cache->call('stationInfo->listCountries');

// A select box to choose a country
$select = "<select name=\"country\">\n";
foreach ( $countries as $country ) {
    if ( $country == 'switzerland' ) {
        $select .= "<option selected>".$country."</option>\n";
    } else {
        $select .= "<option>".$country."</option>\n";
    }
}
$select .= "</select>";

// Initialize a variable to store a table
$table='';

// If a country search has been performed...
if ( isset ( $_GET['country'] ) && in_array($_GET['country'],$countries) ) {

    // Start building the table
    $table = "<table>\n";
    $table.= "<tr>\n<th>Airports in ".$_GET['country']."</th>\n</tr>\n";

    // Use the services searchByCountry() method
    $country = $cache->call('stationInfo->searchByCountry',$_GET['country']);

    // Display the airports in the country as table rows
    foreach ( $country as $airport ) {
        $table.="<tr>\n<td>".$airport->string."</td>\n</tr>\n";
    }
    $table .= "</table>";
}
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Global Weather Service </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
body, td {
    font-size: 13px;
    font-family: verdana;
    color: navy
}
b {
    font-weight: bold;
}
form {
    margin: 0px;
}
input, select {
    font-size: 12px;
    font-family: verdana;
    background-color: silver;
    color: black;
}
</style>
</head>
<body>
<form method="GET" action="<?php echo ( $_SERVER['PHP_SELF'] ); ?>">
<table>
<tr>
<td><b>Pick a Country:</b></td>
<td><?php echo ( $select ); ?></td>
<td><input type="submit" value=" Search "></td>
</tr>
</table>
</form>
<?php echo ( $table );?>
</body>
</html>