<?php
// Include PEAR::Cache_Lite
require_once('Cache/Lite.php');

// Define options for Cache_Lite
$options = array(
    'cacheDir' => './cache/'
);

// Instantiate Cache_Lite
$cache = new Cache_Lite($options);

// Some dummy data to store
$id = 'MyCache';

// Initialize the cache if this is the first time the page is requested.
if ( !$cache->get($id) ) {
    $cache->save('Dummy',$id);
}

// A randomizer...
$random = array (0,1,1);
shuffle($random);

// Randomly update the cache
if ( $random[0] == 0 ) {
    $cache->save('Dummy',$id);
}

// Get the time the cache file was last modified
$lastModified = filemtime($cache->_file);

// Issue an HTTP last modified header
header ( 'Last-Modified: '.
    gmdate('D, d M Y H:i:s',$lastModified).' GMT');

// Get client headers - Apache only
$request = getallheaders();

if ( isset($request['If-Modified-Since']) ) {
    // Split the If-Modified-Since (Netscape < v6 sends this incorrectly)
    $modifiedSince = explode(';', $request['If-Modified-Since']);

    // Turn the client request If-Modified-Since into a timestamp
    $modifiedSince = strtotime($modifiedSince[0]);
} else {
    // Set modified since to 0
    $modifiedSince = 0;
}

// Compare the time the content was last modified with what the client sent
if ( $lastModified <= $modifiedSince ) {
    // Save on some bandwidth!
    header('HTTP/1.0 304 Not Modified');
    exit();
}

// Display the time the page was last modified
echo ( 'The GMT is now '.gmdate('H:i:s').'<br />' );
echo ( '<a href="'.$_SERVER['PHP_SELF'].'">View Again</a><br />' );
?>