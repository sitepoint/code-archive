# phpMyAdmin MySQL-Dump
# version 2.3.0-rc3
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Aug 18, 2003 at 06:51 AM
# Server version: 4.00.00
# PHP Version: 4.3.2
# Database : `sitepoint`
# --------------------------------------------------------

#
# Table structure for table `user2collection`
#

CREATE TABLE user2collection (
  user_id int(11) NOT NULL default '0',
  collection_id int(11) NOT NULL default '0',
  PRIMARY KEY  (user_id,collection_id)
) TYPE=MyISAM;

#
# Dumping data for table `user2collection`
#

INSERT INTO user2collection VALUES (1, 2);
INSERT INTO user2collection VALUES (2, 1);
INSERT INTO user2collection VALUES (2, 2);
INSERT INTO user2collection VALUES (3, 2);
INSERT INTO user2collection VALUES (4, 2);

