# phpMyAdmin MySQL-Dump
# version 2.3.0-rc3
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Sep 21, 2003 at 11:43 AM
# Server version: 4.00.00
# PHP Version: 4.3.2
# Database : `sitepoint`
# --------------------------------------------------------

#
# Table structure for table `menu`
#

CREATE TABLE menu (
  menu_id int(11) NOT NULL auto_increment,
  parent_id int(11) NOT NULL default '0',
  name varchar(255) NOT NULL default '',
  description text NOT NULL,
  location varchar(255) NOT NULL default '',
  PRIMARY KEY  (menu_id),
  UNIQUE KEY location (location)
) TYPE=MyISAM;

#
# Dumping data for table `menu`
#

INSERT INTO menu VALUES (1, 0, 'Home', 'Home', '/');
INSERT INTO menu VALUES (2, 1, 'News', 'Site news', '/news/');
INSERT INTO menu VALUES (3, 1, 'About', 'About us', '/about/');
INSERT INTO menu VALUES (4, 1, 'Contact', 'Contact Us', '/contact/');
INSERT INTO menu VALUES (5, 0, 'Products', 'Product Catalog', '/products/');
INSERT INTO menu VALUES (6, 5, 'Pets', 'The Petstore', '/products/pets/');
INSERT INTO menu VALUES (7, 6, 'Birds', 'The Aviary', '/products/pets/birds/');
INSERT INTO menu VALUES (8, 6, 'Cats', 'The Lions Den', '/products/pets/cats/');
INSERT INTO menu VALUES (9, 5, 'Books', 'The Bookstore', '/products/books/');
INSERT INTO menu VALUES (10, 9, 'Fiction', 'Fiction', '/products/books/fiction/');
INSERT INTO menu VALUES (11, 9, 'Biography', 'Biographies', '/products/books/biography/');
INSERT INTO menu VALUES (12, 3, 'Folio', 'Sites', '/about/folio/');

