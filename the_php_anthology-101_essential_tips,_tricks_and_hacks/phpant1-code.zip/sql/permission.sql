# phpMyAdmin MySQL-Dump
# version 2.3.0-rc3
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Mar 03, 2003 at 05:07 AM
# Server version: 4.00.00
# PHP Version: 4.3.0
# Database : `sitepoint`
# --------------------------------------------------------

#
# Table structure for table `permission`
#

CREATE TABLE permission (
  permission_id int(11) NOT NULL auto_increment,
  name varchar(50) NOT NULL default '',
  description text NOT NULL,
  PRIMARY KEY  (permission_id)
) TYPE=MyISAM;

#
# Dumping data for table `permission`
#

INSERT INTO permission VALUES (1, 'create', 'Permission to create content');
INSERT INTO permission VALUES (2, 'edit', 'Permission to edit content');
INSERT INTO permission VALUES (3, 'delete', 'Permission to delete content');
INSERT INTO permission VALUES (4, 'view', 'Permission to view content');

