# phpMyAdmin MySQL-Dump
# version 2.3.0-rc3
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Aug 18, 2003 at 06:49 AM
# Server version: 4.00.00
# PHP Version: 4.3.2
# Database : `sitepoint`
# --------------------------------------------------------

#
# Table structure for table `collection2permission`
#

CREATE TABLE collection2permission (
  collection_id int(11) NOT NULL default '0',
  permission_id int(11) NOT NULL default '0',
  PRIMARY KEY  (collection_id,permission_id)
) TYPE=MyISAM;

#
# Dumping data for table `collection2permission`
#

INSERT INTO collection2permission VALUES (1, 1);
INSERT INTO collection2permission VALUES (1, 2);
INSERT INTO collection2permission VALUES (1, 3);
INSERT INTO collection2permission VALUES (1, 4);
INSERT INTO collection2permission VALUES (2, 1);
INSERT INTO collection2permission VALUES (2, 4);

