# phpMyAdmin MySQL-Dump
# version 2.3.0-rc3
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Mar 03, 2003 at 05:05 AM
# Server version: 4.00.00
# PHP Version: 4.3.0
# Database : `sitepoint`
# --------------------------------------------------------

#
# Table structure for table `signup`
#

CREATE TABLE signup (
  signup_id int(11) NOT NULL auto_increment,
  login varchar(50) NOT NULL default '',
  password varchar(50) NOT NULL default '',
  email varchar(50) default NULL,
  firstName varchar(50) default NULL,
  lastName varchar(50) default NULL,
  signature text NOT NULL,
  confirm_code varchar(40) NOT NULL default '',
  created int(11) NOT NULL default '0',
  PRIMARY KEY  (signup_id),
  UNIQUE KEY confirm_code (confirm_code),
  UNIQUE KEY user_login (login),
  UNIQUE KEY email (email)
) TYPE=MyISAM;

