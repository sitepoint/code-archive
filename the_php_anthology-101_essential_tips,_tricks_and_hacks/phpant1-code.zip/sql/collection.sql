# phpMyAdmin MySQL-Dump
# version 2.3.0-rc3
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Aug 18, 2003 at 06:50 AM
# Server version: 4.00.00
# PHP Version: 4.3.2
# Database : `sitepoint`
# --------------------------------------------------------

#
# Table structure for table `collection`
#

CREATE TABLE collection (
  collection_id int(11) NOT NULL auto_increment,
  name varchar(50) NOT NULL default '',
  description text NOT NULL,
  PRIMARY KEY  (collection_id)
) TYPE=MyISAM;

#
# Dumping data for table `collection`
#

INSERT INTO collection VALUES (1, 'Administrators', 'Site administrators');
INSERT INTO collection VALUES (2, 'Authors', 'Authors who write for the site');

