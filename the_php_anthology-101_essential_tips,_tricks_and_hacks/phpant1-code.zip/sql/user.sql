# phpMyAdmin MySQL-Dump
# version 2.3.0-rc3
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Aug 16, 2003 at 07:30 PM
# Server version: 4.00.00
# PHP Version: 4.3.2
# Database : `sitepoint`
# --------------------------------------------------------

#
# Table structure for table `user`
#

CREATE TABLE user (
  user_id int(11) NOT NULL auto_increment,
  login varchar(50) NOT NULL default '',
  password varchar(50) NOT NULL default '',
  email varchar(50) default NULL,
  firstName varchar(50) default NULL,
  lastName varchar(50) default NULL,
  signature text NOT NULL,
  PRIMARY KEY  (user_id),
  UNIQUE KEY email (email),
  UNIQUE KEY user_login (login)
) TYPE=MyISAM;

#
# Dumping data for table `user`
#

INSERT INTO user VALUES (1, 'hjones', 'ae2b1fca515949e5d54fb22b8ed95575', 'hjones@php.net', 'Hale', 'Jones', 'Nearly all men can stand adversity, but if you want to test a man\'s character, give him power.');
INSERT INTO user VALUES (2, 'dschwarzenegger', '1ff4de55be352b8221a160a268b55575', 'dschwarzenegger@hotmail.com', 'Demi', 'Schwarzenegger', 'Some people like my advice so much that they frame it upon the wall instead of using it.');
INSERT INTO user VALUES (3, 'hwilliams', '515aee827f0b53a42a072a4070c3c230', 'hwilliams@mysql.com', 'Hale', 'Williams', 'I\'m astounded by people who want to \'know\' the universe when it\'s hard enough to find your way around Chinatown.');
INSERT INTO user VALUES (4, 'jwillis', '44e528a3b0cd87c9928c30dd7a3b75b8', 'jwillis@mysql.com', 'John', 'Willis', 'A verbal contract isn\'t worth the paper it\'s written on.');
INSERT INTO user VALUES (5, 'dwilliams', 'bc59249e0dbcf86856442e0b195946d6', 'dwilliams@hotmail.com', 'Demi', 'Williams', 'Progress might have been all right once, but it has gone on too long.');
INSERT INTO user VALUES (6, 'mtravolta', '87f46e312a583452a75996f7fc7929ee', 'mtravolta@mysql.com', 'Madeline', 'Travolta', 'Anyone can do any amount of work provided it isn\'t the work he is supposed to be doing at the moment.');
INSERT INTO user VALUES (7, 'dmoore', '4dca32c6105409aec531d19409d19f0e', 'dmoore@hotmail.com', 'Demi', 'Moore', 'A lie told often enough becomes the truth.');
INSERT INTO user VALUES (8, 'hmoore', '57bb7866fbddb103f9697db65b2c898d', 'hmoore@php.net', 'Hale', 'Moore', 'A man cannot be too careful in the choice of his enemies.');
INSERT INTO user VALUES (9, 'jschwarzenegger', 'da56d8e40e6d21065d1734255bdbe84f', 'jschwarzenegger@hotmail.com', 'John', 'Schwarzenegger', 'I believe that people would be alive today if there were a death penalty.');
INSERT INTO user VALUES (10, 'awillis', '98d20b990b4995311e2167a13479abd2', 'awillis@hotmail.com', 'Arnold', 'Willis', 'Life is a zoo in a jungle.');
INSERT INTO user VALUES (11, 'mschwarzenegger', '898953e4a781e36a39ac85108474db01', 'mschwarzenegger@yahoo.co.uk', 'Madeline', 'Schwarzenegger', 'A musicologist is a man who can read music but can\'t hear it.');
INSERT INTO user VALUES (12, 'bjones', 'bd988f371a8a80381084bb83a2c8a146', 'bjones@hotmail.com', 'Bruce', 'Jones', 'Journalism largely consists of saying \'Lord Jones is Dead\' to people who never knew that Lord Jones was alive.');
INSERT INTO user VALUES (13, 'cstowe', 'bf9d9588b84ba6161c24fad149a7daa9', 'cstowe@yahoo.co.uk', 'Catherine', 'Stowe', 'The idea of all-out nuclear war is unsettling.');
INSERT INTO user VALUES (14, 'rwillis', '26fb2412009b5893713959bdc62424b5', 'rwillis@mysql.com', 'Robin', 'Willis', 'Sometimes I get the feeling the whole world is against me, but deep down I know that\'s not true. Some smalleer countries are neutral.');
INSERT INTO user VALUES (15, 'btravolta', 'c5a83c3a2adbd2e348d5f903f0ef4cd8', 'btravolta@mysql.com', 'Bruce', 'Travolta', 'Basic research is what I am doing when I don\'t know what I am doing.');
INSERT INTO user VALUES (16, 'rtravolta', '4089a17271187b4f724d09f7dfac790e', 'rtravolta@hotmail.com', 'Robin', 'Travolta', 'The older I grow, the less important the comma becomes. Let the reader catch his own breath.');
INSERT INTO user VALUES (17, 'hstowe', '24c7058846dfb498e65a016f329a5374', 'hstowe@yahoo.co.uk', 'Hale', 'Stowe', 'Every man is wise when attacked by a mad dog; fewer when pursued by a mad woman; only the wisest survive when attacked by a mad notion.');
INSERT INTO user VALUES (18, 'mmoore', '57cc12d50ba6df8e444e5b82d050054f', 'mmoore@php.net', 'Madeline', 'Moore', 'After being Turned Down by numerous Publishers, he had decided to write for Posterity.');

