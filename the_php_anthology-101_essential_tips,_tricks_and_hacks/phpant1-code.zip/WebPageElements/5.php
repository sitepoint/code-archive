<?php
// Include the QuickForm class
require_once ("HTML/QuickForm.php");

// Instantiate the QuickForm class
$form = new HTML_QuickForm('quickForm1', 'POST');

// Add a text input field called firstName, labelled with "Enter your name"
$form->addElement('text','firstName','Enter your name');

// Add a submit button called submit and "Send" as the text for the button
$form->addElement('submit','submit','Send');

// If the form is submitted...
if ( isset ($_POST['submit']) ) {
    // Display the submitted value "firstName"
    echo ( 'Hello '.$form->getSubmitValue('firstName') );
} else {
    // If not submitted, display the form
    $form->display();
}
?>