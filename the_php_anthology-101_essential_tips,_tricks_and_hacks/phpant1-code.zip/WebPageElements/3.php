<?php
// Include the MySQL class
require_once('Database/MySQL.php');

// Include the Simple Pager clas
require_once('Database/SimplePager.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Find out how many rows are available
$sql="SELECT COUNT(*) AS num_rows FROM user";
$result=$db->query($sql);
$row=$result->fetch();

// Define the number of rows per page
$rowsPerPage=10;

// Set a default page number
if ( !isset ($_GET['page']) )
    $_GET['page']=1;

// Instantiate the pager
$pager=new SimplePager ($rowsPerPage,$row['num_rows'],$_GET['page']);

// Build a table for the pager
echo ( "<table align=\"center\">\n<tr>\n" );

// Build the HTML for the pager
for ( $i=1;$i<=$pager->getTotalPages();$i++ ) {
    echo ( "<td><a href=\"".$_SERVER['PHP_SELF']."?page=".$i."\">" );
    if ( $i==$_GET['page'] )
        echo ( "<strong>".$i."</strong>" );
    else
        echo ( $i );
    echo ( "</a></td>\n" );
}
echo ( "</tr>\n</table>\n" );

// Now construct the "real" SQL statement
$sql="SELECT * FROM user LIMIT ".$pager->getStartRow().", ".$rowsPerPage;

// Fetch and display the results
$result=$db->query($sql);

echo ( "<table align=\"center\">\n" );
echo ( "<tr>\n<th>Login</th><th>Name</th><th>Email</th>\n</tr>" );

while ( $row=$result->fetch() ) {
    echo ( "<tr>\n
            <td>".$row['login']."</td>
            <td>".$row['firstName'].' '.$row['lastName']."</td>
            <td>".$row['email']."</td>\n
            </tr>\n" );
}
echo ( "</table>" );
?>