<?php
// Include MySQL class
require_once('Database/MySQL.php');

// Include Menu class
require_once('UI/Menu.php');

// Include BreadCrumb class
require_once('UI/BreadCrumb.php');

// Include Context class
require_once('UI/ContextMenu.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Set the base location for this page relative to web root - MODIFY THIS!!!
$baseUrl='/phprecipes/WebPageElements/13.php';

// Fetch the location framement to match against menu table
$location = str_replace ($baseUrl,'',$_SERVER['PHP_SELF']);

// Instantiate new BreadCrumb menu passing the MySQL connection and location
$crumbs=& new BreadCrumb($db,$location);

// Instantiate the ContextMenu class
$menu=& new ContextMenu($db,$location);
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Context Menu + BreadCrumbs Example </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
body, a, li, td
{
    font-family: verdana;
    font-size: 11px;
}
h1
{
    font-family: verdana;
    font-size: 15px;
    color: navy
}
ul
{
    list-style-type: square
}
table
{
    width: 500px;
}
.breadCrumbs
{
    margin-bottom: 10px;
    border-style: dashed;
    border-width: 1px;
    padding: 4px;
    width: 500px;
}
.menu
{
    border-style: dashed;
    border-width: 1px;
    padding: 4px;
    width: 80px;
}
</style>
</head>
<body>
<h1>Context Sensitive + Bread Crumbs Menu</h1>
<div class="breadCrumbs">
<?php
// Display the breadcrumbs   
while ($crumb = $crumbs->fetch()) {
    if ( $crumb->isRoot() ) {
        echo ( "<a href=\"".$baseUrl.$crumb->location()."\">"
                .$crumb->name()."</a>" );
    } else {
        echo ( " > <a href=\"".$baseUrl.$crumb->location()."\">"
                .$crumb->name()."</a>" );
    }
}
?>
</div>
<table>
<tr valign="top">
<td class="menu">
<?php
// Display the context menu
while ( $item = $menu->fetch() ) {
    if ( $item->isStart() )
        echo ( "<ul>" );
    else if ( $item->isEnd() )
        echo ( "</ul>" );
    else
        echo ( "<li><a href=\"".$baseUrl.$item->location()."\">"
                .$item->name()."</a></li>" );
}
?>
</td>
<td>
The URL is <?php echo ( $_SERVER['PHP_SELF'] );?><br />
The BaseUrl is <?php echo ( $baseUrl );?><br />
The Location fragment is <?php echo ( $location );?>
</body>
</html>