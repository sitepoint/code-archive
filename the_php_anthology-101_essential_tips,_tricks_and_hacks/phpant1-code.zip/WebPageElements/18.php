<?php
// Examine some pre-defined variables
echo ( '$_SERVER[\'PATH_INFO\']: '.@$_SERVER['PATH_INFO'].'<br />' );
echo ( '$_SERVER[\'PHP_SELF\']: '.@$_SERVER['PHP_SELF'].'<br />' );
echo ( '$_SERVER[\'REQUEST_URI\']: '.@$_SERVER['REQUEST_URI'].'<br />' );
echo ( '$_SERVER[\'SCRIPT_NAME\']: '.@$_SERVER['SCRIPT_NAME'].'<br />' );
?>