<?php
// Include the MySQL class
require_once('Database/MySQL.php');

// Include the QuickForm class
require_once ("HTML/QuickForm.php");

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// A function to apply mysql_real_escape_string
function escapeValue($value) {
    return mysql_real_escape_string($value);
}

// Instantiate QuickForm
$form = new HTML_QuickForm('imageUpload','POST');

// The file upload field
$form->addElement('file', 'image', 'Select Image:');
$form->addRule('image', 'The maximum file size is 56KB', 'maxfilesize', 57344);
$form->addRule('image', 'The file must be an image', 'mimetype',
               array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png'));
$form->addRule('image', 'No file selected.', 'uploadedfile',NULL,'client');

// The submit button
$form->addElement('submit', 'submit', 'Upload');

if ($form->validate()) {
    // Apply the escape filter to all fields
    $form->applyFilter('__ALL__', 'escapeValue');

    // Instantiate the MySQL class
    $db=& new MySQL($host,$dbUser,$dbPass,$dbName);

    // Fetch the details fof the file
    $name=escapeValue($form->_submitFiles['image']['name']);
    $size=escapeValue($form->_submitFiles['image']['size']);
    $type=escapeValue($form->_submitFiles['image']['type']);

    // Fetch file
    $contents=file_get_contents($form->_submitFiles['image']['tmp_name']);

    // Escape binary data
    $contents=escapeValue($contents);
    
    $sql="INSERT INTO image SET
            name='".$name."',
            size='".$size."',
            type='".$type."',
            contents='".$contents."'";

    // Perform the query
    $result=$db->query($sql);

    // If all went well, say thanks
    if ( !$result->isError() ) {
        echo ( 'File Uploaded Successfully' );
    }
} else {
    $form->display();
}
?>