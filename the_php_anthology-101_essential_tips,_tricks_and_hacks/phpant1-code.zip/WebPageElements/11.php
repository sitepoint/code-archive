<?php
// Include the MySQL class
require_once('Database/MySQL.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate the MySQL class
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// If there's not image, die
if ( !isset($_GET['id']) )
    die ('No image selected');

// Escape the string, for good practice
$_GET['id']=mysql_real_escape_string($_GET['id']);

// An SQL statement to get the contents and MIME type of the image
$sql="SELECT * FROM image WHERE image_id='".$_GET['id']."'";

// Fetch the data
$result=$db->query($sql);
$row=$result->fetch();

// Use a header to tell the browser what MIME type the image is
header('content-disposition: inline; filename=' . $row['name']);
header('content-type: '.$row['type']);
header('content-length: ' . $row['size']);

// Display the contents
echo $row['contents'];
?>