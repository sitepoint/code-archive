<?php
// Include the MySQL class
require_once('Database/MySQL.php');

// Include the QuickForm class
require_once ("HTML/QuickForm.php");

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// A function for comparing password
function cmpPass($element, $confirmPass)
{
    global $form;
    $password = $form->getElementValue('password');
    return ($password == $confirmPass);
}

// A function to apply mysql_real_escape_string
function escapeValue($value) {
	return mysql_real_escape_string($value);
}

// A function to encrypt the password
function encryptValue($value) {
	return md5($value);
}

// Instantiate the QuickForm class
$form = new HTML_QuickForm('regForm', 'POST');

// Register the compare function
$form->registerRule('compare', 'function', 'cmpPass');

// The login field
$form->addElement('text','login','Desired Username');
$form->addRule('login','Please provide a username','required',false,'client');
$form->addRule('login','Username must be at least 6 characters','minlength',6,'client');
$form->addRule('login','Username cannot be more than 50 characters','maxlength',50,'client');
$form->addRule('login','Username can only contain letters and numbers','alphanumeric',NULL,'client');

// The password field
$form->addElement('password','password','Password');
$form->addRule('password','Please provide a password','required',false,'client');
$form->addRule('password','Password must be at least 6 characters','minlength',6,'client');
$form->addRule('password','Password cannot be more than 12 characters','maxlength',50,'client');
$form->addRule('password','Password can only contain letters and numbers','alphanumeric',NULL,'client');

// The field for confirming the password
$form->addElement('password','confirmPass','Confirm');
$form->addRule('confirmPass','Please confirm password','required',false,'client');
$form->addRule('confirmPass','Passwords must match','compare','function');

// The email field
$form->addElement('text','email','Email Address');
$form->addRule('email','Please an email address','required',false,'client');
$form->addRule('email','Please enter a valid email address','email',false,'client');
$form->addRule('email','Email cannot be more than 50 characters','maxlength',50,'client');

// The first name field
$form->addElement('text','firstName','First Name');
$form->addRule('firstName','Please enter your first name','required',false,'client');
$form->addRule('firstName','First name cannot be more than 50 characters','maxlength',50,'client');

// The last name field
$form->addElement('text','lastName','Last Name');
$form->addRule('lastName','Please enter your last name','required',false,'client');
$form->addRule('lastName','Last name cannot be more than 50 characters','maxlength',50,'client');

// The signature field
$form->addElement('textarea','signature','Signature');

// Add a submit button called submit and "Send" as the text for the button
$form->addElement('submit','submit','Register');

// If the form is submitted...
if ( $form->validate() ) {

    // Apply the escape filter to all fields
    $form->applyFilter('__ALL__', 'escapeValue');

    // Apply the encryption filter to the password
    $form->applyFilter('password', 'encryptValue');

    // Instantiate the MySQL class
    $db=& new MySQL($host,$dbUser,$dbPass,$dbName);

    // Construct a query using the submitted values
    $sql="INSERT INTO user SET
          login='".$form->getSubmitValue('login')."',
          password='".$form->getSubmitValue('password')."',
          email='".$form->getSubmitValue('email')."',
          firstName='".$form->getSubmitValue('firstName')."',
          lastName='".$form->getSubmitValue('lastName')."',
          signature='".$form->getSubmitValue('signature')."'";

    // Perform the query
    $result=$db->query($sql);

    // If all went well, say thanks
    if ( !$result->isError() ) {
        echo ( 'Thank you. Registration completed' );
    }
} else {
    // If not submitted, display the form
    $form->display();
}
?>