<?php
// Include the PathVars class
require_once('Url/PathVars.php');

echo ( '$_SERVER[\'REQUEST_URI\'] is '.$_SERVER['REQUEST_URI'].'<br />' );
echo ( '$_SERVER[\'SCRIPT_NAME\'] is '.$_SERVER['SCRIPT_NAME'].'<br />' );

// Instaniate PathVars
$pathVars = & new PathVars($_SERVER['SCRIPT_NAME']);

echo ( "<b>Iterate over Extracted Variables</b><br />\n" );
while ($var = $pathVars->fetch()) {
    echo ( $var."<br />\n" );
}

echo ( "<b>Fetch Variable 3 by Index</b><br />\n" );
echo ( $pathVars->fetchByIndex(3) );
?>