<?php
// Include MySQL class
require_once('Database/MySQL.php');

// Include Menu class
require_once('UI/Menu.php');

// Include BreadCrumb class
require_once('UI/BreadCrumb.php');

// Include CollapsingTree menu
require_once('UI/CollapsingTree.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Set the base location for this page relative to web root - MODIFY THIS!!!
$baseUrl='/phprecipes/WebPageElements/15.php';

// Fetch the location framement to match against menu table
$location = str_replace ($baseUrl,'',$_SERVER['PHP_SELF']);

// Instantiate new BreadCrumb menu passing the MySQL connection and location
$crumbs=& new BreadCrumb($db,$location);

// Instantiate the Collapsing Tree class
$menu=& new CollapsingTree($db,$location);
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Collasping Menu + BreadCrumbs </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
body, a, td
{
    font-family: verdana;
    font-size: 11px;
}
h1
{
    font-family: verdana;
    font-size: 15px;
    color: navy
}
table
{
    width: 500px;
}
.breadCrumbs
{
    margin-bottom: 10px;
    border-style: dashed;
    border-width: 1px;
    padding: 4px;
    width: 500px;
}
.menu
{
    border-style: dashed;
    border-width: 1px;
    padding: 4px;
    width: 80px;
}
</style>
</head>
<body>
<h1>Collapsing Menu + BreadCrumbs</h1>
<div class="breadCrumbs">
<?php
// Display the breadcrumbs   
while ($crumb = $crumbs->fetch()) {
    if ( $crumb->isRoot() ) {
        echo ( "<a href=\"".$baseUrl.$crumb->location()."\">"
                .$crumb->name()."</a>" );
    } else {
        echo ( " > <a href=\"".$baseUrl.$crumb->location()."\">"
                .$crumb->name()."</a>" );
    }
}
?>
</div>
<table>
<tr valign="top">
<td class="menu">
<?php
// Define some bullet for menu items, in this case just spaces
$bullet='&nbsp;&nbsp;';

// Set the current depth of the menu
$depth=0;

// Display the collapsing tree menu
while ( $item = $menu->fetch() ) {
    // If this is the start of a new menu branch, increase the depth
    if ( $item->isStart() ) {
        $depth++;
    // If this is the end of a menu branch, decrease the depth
    } else if ( $item->isEnd() ) {
        $depth--;
    // Display a menu item
    } else {
        // Reset the bullets
        $bullets='';

        // Build the bullets based on the current depth
        for ( $i=0;$i<=$depth;$i++ )
            $bullets.=$bullet;

        // Build onMouseOver description
        $mouseOver=" onMouseOver=\"window.status='".addslashes($item->description()).
            "';return true\" onMouseOut=\"window.status='';return true\"";

        // Display the menu item with bullets
        echo ( $bullets."<a href=\"".$baseUrl.$item->location().
            "\"".$mouseOver.">".$item->name()."</a><br />" );
    }
}
?>
</td>
<td>
The URL is <?php echo ( $_SERVER['PHP_SELF'] );?><br />
The BaseUrl is <?php echo ( $baseUrl );?><br />
The Location fragment is <?php echo ( $location );?>
</body>
</html>