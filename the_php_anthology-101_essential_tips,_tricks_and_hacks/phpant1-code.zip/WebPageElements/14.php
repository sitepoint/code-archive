<?php
// Include MySQL class
require_once('Database/MySQL.php');

// Include Menu class
require_once('UI/Menu.php');

// Include BreadCrumb class
require_once('UI/BreadCrumb.php');

// Include ChildNodes class
require_once('UI/ChildNodes.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Set the base location for this page relative to web root - MODIFY THIS!!!
$baseUrl='/phprecipes/WebPageElements/14.php';

// Fetch the location framement to match against menu table
$location = str_replace ($baseUrl,'',$_SERVER['PHP_SELF']);

// Instantiate new BreadCrumb menu passing the MySQL connection and location
$crumbs=& new BreadCrumb($db,$location);

// Get the number of breadcrumbs
$size=$crumbs->size();

// Instantiate the ChildNodes class
$menu=& new ChildNodes($db,$location);
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> ChildNodes + BreadCrumbs Example </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
body, a, li, td
{
    font-family: verdana;
    font-size: 11px;
}
h1
{
    font-family: verdana;
    font-size: 15px;
    color: navy
}
ul
{
    list-style-type: square
}
table
{
    width: 500px;
}
.root
{
    font-weight: bold;
}
.menu
{
    width: 50px;
}
.filler
{
    width: 100%;
}
</style>
</head>
<body>
<h1>Child Menu + Bread Crumbs</h1>
<table>
<tr valign="top">
<?php
// Display the breadcrumbs   
$i=1;
while ($crumb = $crumbs->fetch()) {
    echo ( "<td class=\"menu\">" );
    echo ( "<a class=\"root\" href=\"".$baseUrl.$crumb->location()."\">"
            .$crumb->name()."</a><br />" );
    // Check if this is now current place to attach the drop down
    if ( $i == $size ) {
        // Display the child nodes
        while ( $item = $menu->fetch() ) {
            echo ( "<a href=\"".$baseUrl.$item->location()."\">"
                    .$item->name()."</a><br />" );
        }
    }
    $i++;
    echo ( "</td>" );
}
?>
<td class="filler">&nbsp;</td>
</tr>
</table>
</body>
</html>