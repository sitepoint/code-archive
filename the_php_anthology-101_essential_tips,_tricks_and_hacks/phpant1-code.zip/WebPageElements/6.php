<?php
// Include the QuickForm class
require_once ("HTML/QuickForm.php");

// Instantiate the QuickForm class
$form = new HTML_QuickForm('quickForm2', 'POST');

// Add a text input field called firstName, labelled with "Enter your name"
$form->addElement('text','firstName','Enter your name');

// Rule to validate with JavaScript and PHP
$form->addRule('firstName','Please enter your name','required',false,'client');

// Add a submit button called submit and "Send" as the text for the button
$form->addElement('submit','submit','Send');

// If the form is submitted...
if ( $form->validate() ) {
    // Display the submitted value "firstName"
    echo ( 'Hello '.$form->getSubmitValue('firstName') );
} else {
    // If not submitted, display the form
    $form->display();
}
?>