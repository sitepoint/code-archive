<?php
// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Build the correct $location variable e.g. 
$baseUrl='/index.php';
$location = str_replace ($baseUrl,'',$_SERVER['PHP_SELF']);

// Instantiate the menu, one of the following

$menu=& new BreadCrumb($mysql,$location); // Breadcrumb navigation
$menu=& new ChildNodes($mysql,$location); // Child nodes of current location
$menu=& new ContextMenu($mysql,$location); // A menu in context with location
$menu=& new CollapsingTree($mysql,$location); // Collapsing tree menu
$menu=& new FullTree($mysql,$location); // Fulltree menu

// If you need it, find out how many items in the menu
$size=$menu->size();

// Loop through the items
while ( $item = $menu->fetch() ) {
    if ( $item->isStart() ) {
        // This is a Marker to show the START of a submenu
    } else if ( $item->isEnd() ) {
        // This is a Marker to show the END of a submenu
    } else {
        if ( $item->isCurrent() ) {
            // This is the menu item corrsponding to the current location
        }
        $item->id(); // The menu_id from table menu (should not be needed)
        $item->parent_id(); // The parent_id from table menu ( not needed)
        $item->name(); // The name field from table menu
        $item->description(); // The description field from table menu
        $item->location(); // The location field from table menu
    }
}
?>