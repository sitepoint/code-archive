<?php
// Include Magic Quotes filter
require_once('MagicQuotes/strip_quotes.php');

// If the form has been submitted...
if ( isset( $_POST['submit'] ) ) {

    // If the file is a GIF image...
    if ( $_FILES['image']['type'] == 'image/gif' ) {

        // Copy the file from temporary storage to final destination
        copy ($_FILES['image']['tmp_name'], "./files/".$_FILES['image']['name'] )
            or die ("Could not copy");

        // Display some information about the file
        echo ( "File Upload Complete<br />\n" );
        echo ( "Name: ".$_FILES['image']['name']."<br />\n" );
        echo ( "Size: ".$_FILES['image']['size']."<br />\n" );
        echo ( "Type: ".$_FILES['image']['type']."<br />\n" );
        echo ( "<img src=\"files/".$_FILES['image']['name']."\" />" );
    }

// ... otherwise display the form
} else {
?>
<form method="POST" action="<?php echo ($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">
Upload a GIF image: <input type="file" name="image" />
<input type="submit" name="submit" value="Submit" />
</form>
<?php
}
?>