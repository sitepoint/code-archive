<?php
// Include MySQL class
require_once('Database/MySQL.php');

// Include Menu class
require_once('UI/Menu.php');

// Include BreadCrumb class
require_once('UI/BreadCrumb.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Set the base location for this page relative to web root - MODIFY THIS!!!
$baseUrl='/phprecipes/WebPageElements/12.php';

// Fetch the location framement to match against menu table
$location = str_replace ($baseUrl,'',$_SERVER['PHP_SELF']);

// Instantiate new BreadCrumb menu passing the MySQL connection and location
$crumbs=& new BreadCrumb($db,$location);
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> BreadCrumb Menu Example </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
body, a, li
{
    font-family: verdana;
    font-size: 11px;
}
h1
{
    font-family: verdana;
    font-size: 15px;
    color: navy
}
.breadCrumbs
{
    margin-bottom: 10px;
    border-style: dashed;
    border-width: 2px;
    padding: 4px;
    width: 400px;
}
</style>
</head>
<body>
<h1>Bread Crumbs Menu</h1>
<div class="breadCrumbs">
<?php
// Display the breadcrumbs   
while ( $item = $crumbs->fetch() ) {
    if ( $item->isRoot() ) {
        echo ( "<a href=\"".$baseUrl.$item->location()."\">"
                .$item->name()."</a>" );
    } else {
        echo ( " > <a href=\"".$baseUrl.$item->location()."\">"
                .$item->name()."</a>" );
    }
}
?>
</div>
<b>Sample Urls:</b><br />
<a href="<?php echo ( $baseUrl ); ?>/contact/">Contact</a><br />
<a href="<?php echo ( $baseUrl ); ?>/about/folio/">Folio</a><br />
<a href="<?php echo ( $baseUrl ); ?>/products/">Products</a><br />
<a href="<?php echo ( $baseUrl ); ?>/products/books/fiction/">Fiction</a><br />
</body>
</html>