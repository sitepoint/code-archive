<?php
// Include MySQL class
require_once('Database/MySQL.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Include the PEAR::HTML_Table class
require_once('HTML/Table.php');

// Include the PEAR::Pager_Sliding class
require_once('Pager/Sliding.php');

// Include the extended class
require_once('Database/DB_Pager_Sliding.php');

// Instantiate MySQL
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

$sql="SELECT COUNT(*) AS num_rows FROM user";
$result=$db->query($sql);
$row=$result->fetch();

// Define pager settings
$pager_params=array (
            // The total number of rows
            'totalItems' => $row['num_rows'],
            // Rows per page
            'perPage'    => 10,
            // The size of the sliding Window +/-
            'delta'      => 2,
            // Seperator and spacing between links
            'separator'  => '.',
            'spacesBeforeSeparator' => 2,
            'spacesAfterSeparator'  => 2,
            // The $_GET variable name
            'urlVar'     => 'page',
            // Browser status bar text
            'altPrev'    => 'Previous Page',
            'altNext'    => 'Next Page',
            'altPage'    => 'Page: ',
            // CSS Class names
            'curPageLinkClassName' =>'currentPage',
            'linkClass'  => 'pageLink',
            );

// Instantiate the pager
$pager = &new DB_Pager_Sliding($pager_params);

// Fetch the HTML links
$links = $pager->getLinks();

// Basic SQL statement
$sql="SELECT * FROM user";

// A switch to allow sorting by column
switch ( @$_GET['sort'] ) {
    case 'login';
        $sql.=" ORDER BY login ASC";
    break;
    case 'email';
        $sql.=" ORDER BY email ASC";
    break;
    default:
        $sql.=" ORDER BY lastName, firstName ASC";
    break;
}

// Add the LIMIT clause
$sql.=" LIMIT ".$pager->getStartRow().", ".$pager->getRowsPerPage();

// Overall style for the table
$tableStyle=array (
            'width'=>'650',
            'style'=>'border: 1.75px dotted #800080;',
            'align'=>'center'
            );

// Create a new instance of the table, passing the style
$table = new HTML_Table($tableStyle);

// Define a style for the caption of the table
$captionStyle=array(
            'style'=>'font-family: Verdana; font-weight: bold;
                      font-size: 14.75px; color: navy;');

// Add the caption, passing the text to display and the style
$table->setCaption('User List',$captionStyle);

// Define an array of column header data
$columnHeaders=array(
            '<a href="'.$_SERVER['PHP_SELF'].'?sort=login">Login</a>',
            '<a href="'.$_SERVER['PHP_SELF'].'?sort=name">Name</a>',
            '<a href="'.$_SERVER['PHP_SELF'].'?sort=email">Email</a>');

// Add the header row, passing header text and indentifying as a TH tag
$table->addRow($columnHeaders,'','TH');

// Fetch the result object
$result=$db->query($sql);

// A loop for each row of the result set
while ( $row=$result->fetch() ) {
    // Place row data in indexed array
    $rowData=array(
            $row['login'],
            $row['firstName'].' '.$row['lastName'],
            $row['email']
              );

    // Add the row, passing the data
    $table->addRow($rowData);
}

// Set the style for each cell of the row
$cellStyle='style="font-family: verdana; font-size: 11;"';

// Apply the style
$table->updateAllAttributes($cellStyle);

// Define the style for the column headings
$headerStyle='style="background-color: #ffffff;
              font-family: verdana;
              font-weight: bold;
              font-size: 12;"';

// Set the row attributes for the header row
$table->setRowAttributes(0,$headerStyle);

// Set alternating row colors
$table->altRowAttributes(
            1,
            'style="background-color: #d3d3d3"',
            'style="background-color: #ffffff"',
            true );

?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Users </title>
<style type="text/css">
.currentPage
{
    font-family: verdana;
    font-size: 10px;
    font-weight: bold;
    color: red;
}
.pageLink
{
    font-family: verdana;
    font-size: 10px;
    color: red;
}
</style>
</head>

<body>
<?php
// Display the table
echo ($table->toHTML());
?>
<div align="center">
<?php
// Display the paging links
echo ( $links['all'] );
?>
</div>
</body>
</html>