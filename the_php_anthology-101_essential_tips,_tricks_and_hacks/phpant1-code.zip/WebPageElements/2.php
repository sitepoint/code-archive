<?php
// Include MySQL class
require_once('Database/MySQL.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Include the PEAR::HTML_Table class
require_once('HTML/Table.php');

$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Basic SQL statement
$sql="SELECT * FROM user";

// A switch to allow sorting by column
switch ( @$_GET['sort'] ) {
    case 'login';
        $sql.=" ORDER BY login ASC";
    break;
    case 'email';
        $sql.=" ORDER BY email ASC";
    break;
    default:
        $sql.=" ORDER BY lastName, firstName";
    break;
}

// Overall style for the table
$tableStyle=array (
            'width'=>'650',
            'style'=>'border: 1.75px dotted #800080;' );

// Create a new instance of the table, passing the style
$table = new HTML_Table($tableStyle);

// Define a style for the caption of the table
$captionStyle=array(
            'style'=>'font-family: Verdana; font-weight: bold;
                      font-size: 14.75px; color: navy;');

// Add the caption, passing the text to display and the style
$table->setCaption('User List',$captionStyle);

// Define an array of column header data
$columnHeaders=array(
            '<a href="'.$_SERVER['PHP_SELF'].'?sort=login">Login</a>',
            '<a href="'.$_SERVER['PHP_SELF'].'?sort=name">Name</a>',
            '<a href="'.$_SERVER['PHP_SELF'].'?sort=email">Email</a>');

// Add the header row, passing header text and indentifying as a TH tag
$table->addRow($columnHeaders,'','TH');

// Fetch the result object
$result=$db->query($sql);

// A loop for each row of the result set
while ( $row=$result->fetch() ) {
    // Place row data in indexed array
    $rowData=array(
            $row['login'],
            $row['firstName'].' '.$row['lastName'],
            $row['email']
              );

    // Add the row, passing the data
    $table->addRow($rowData);
}

// Set the style for each cell of the row
$cellStyle='style="font-family: verdana; font-size: 11;"';

// Apply the style
$table->setAllAttributes($cellStyle);

// Define the style for the column headings
$headerStyle='style="background-color: #ffffff;
              font-family: verdana;
              font-weight: bold;
              font-size: 12;"';

// Set the row attributes for the header row
$table->setRowAttributes(0,$headerStyle);

// Set alternating row colors
$table->altRowAttributes(
            1,
            'style="background-color: #d3d3d3"',
            'style="background-color: #ffffff"',
            true );

// Display the table
echo ($table->toHTML());
?>