<?php
require_once('MySQL.php');
require_once('Menu.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

$mysql=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Set the base location for this page
$base='/test/WebPageElements/12.php';

// Fetch the location framement to match against menu table
$location = str_replace ($base,'',$_SERVER['PHP_SELF']);

// Instantiate new BreadCrumb menu
$menu=& new BreadCrumb($mysql,$location);

// Get the menu items array
$items=$menu->getMenu();

echo ( '<h1>Bread Crumbs Menu</h1>' );
// Display the breadcrumbs   
foreach ($items as $item) {
    if ( $item->isRoot() ) {
        echo ( "<a href=\"".$base.$item->location()."\">".$item->name()."</a> " );
    } else {
        echo ( "> <a href=\"".$base.$item->location()."\">".$item->name()."</a> " );
    }
}

// Instantiate a tree menu
$menu=& new ContextMenu($mysql,$location);

// Get the menu
$items=$menu->getMenu();

echo ( '<h1>Context Menu</h1>' );
// Display the children
echo ( "<ul>\n" );
foreach ( $items as $item ) {
    if ( $item->isStart() )
        echo ( "<ul>\n" );
    else if ( $item->isEnd() )
        echo ( "</ul>\n" );
    echo ( "<li><a href=\"".$base.$item->location()."\">".$item->name()."</a></li>\n" );
}
echo ( "</ul>\n" );

// Instantiate a tree menu
$menu=& new CollapsingTree($mysql,$location);

// Get the menu
$items=$menu->getMenu();

echo ( '<h1>Collapsing Tree Menu</h1>' );
// Display the collapsing tree menu
echo ( "<ul>\n" );
foreach ( $items as $item ) {

    // Use the isStart() method to find out if this is the start
    // of a branch
    if ( $item->isStart() )
        echo ( "<ul>\n" );
    else if ( $item->isEnd() )
        echo ( "</ul>\n" );
    else
        echo ( "<li><a href=\"".$base.$item->location()."\">".$item->name()."</a></li>\n" );
}
echo ( "</ul>\n" );

// Instantiate a tree menu
$menu=& new FullTree($mysql,$location);

// Get the menu
$items=$menu->getMenu();

echo ( '<h1>Full Tree Menu</h1>' );
// Display the full tree menu
echo ( "<ul>\n" );
foreach ( $items as $item ) {
    if ( $item->isStart() ) {
        echo ( "<ul>\n" );
    } else if ( $item->isEnd() ) {
        echo ( "</ul>\n" );
    } else {
        echo ( "<li><a href=\"".$base.$item->location()."\">" );
        if ( $item->isCurrent() ) {
            echo('>> '.$item->name().' <<');
        } else {
            echo($item->name());
        }
        echo ( "</a></li>\n" );
    }
}
echo ( "</ul>\n" );
?>