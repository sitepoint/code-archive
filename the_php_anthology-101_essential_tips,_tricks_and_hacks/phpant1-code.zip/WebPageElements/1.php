<?php
// Include the MySQL class
require_once('Database/MySQL.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

$db = & new MySQL($host,$dbUser,$dbPass,$dbName);

$sql = "SELECT * FROM user ORDER BY lastName, firstName";

$result = $db->query($sql);

echo ( "<table align=\"center\">\n" );
echo ( "<tr>\n<th>Login</th><th>Name</th><th>Email</th>\n</tr>" );

while ( $row = $result->fetch() ) {
    echo ( "<tr>
            <td>".$row['login']."</td>
            <td>".$row['firstName'].' '.$row['lastName']."</td>
            <td>".$row['email']."</td>
            </tr>\n" );
}
echo ( "</table>" );
?>