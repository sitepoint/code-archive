<?php
// Include the MySQL class
require_once('Database/MySQL.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Define SQL statement to fetch image information but NOT CONTENTS!!!
$sql="SELECT image_id, name, size, type FROM image ORDER BY name";

// Fetch the result object
$result=$db->query($sql);

// A loop for each row of the result set
while ( $row=$result->fetch() ) {
    echo ( "<img src=\"11.php?id=".$row['image_id']."\" /><br />\n" );
    echo ( $row['name']." : ".$row['size']." : ".$row['type']."<br />\n" );
}
?>