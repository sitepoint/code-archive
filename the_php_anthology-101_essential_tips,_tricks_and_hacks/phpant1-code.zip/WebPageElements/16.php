<?php
// Include MySQL class
require_once('Database/MySQL.php');

// Include Menu class
require_once('UI/Menu.php');

// Include BreadCrumb class
require_once('UI/BreadCrumb.php');

// Include FullTree menu
require_once('UI/FullTree.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Set the base location for this page relative to web root - MODIFY THIS!!!
$baseUrl='/phprecipes/WebPageElements/16.php';

// Fetch the location framement to match against menu table
$location = str_replace ($baseUrl,'',$_SERVER['PHP_SELF']);

// Instantiate the FullTree class
$menu=& new FullTree($db,$location);
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Full Tree Menu </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
body, a, li, td
{
    font-family: verdana;
    font-size: 11px;
}
h1
{
    font-family: verdana;
    font-size: 15px;
    color: navy
}
table
{
    width: 500px;
}
</style>
</head>
<body>
<h1>Full Tree Menu</h1>
<table>
<tr valign="top">
<td>
<?php
// Display the FullTree menu
while ( $item = $menu->fetch() ) {
    // If this is the start of a new menu branch, increase the depth
    if ( $item->isStart() ) {
        echo ( '<ul>' );
    // If this is the end of a menu branch, decrease the depth
    } else if ( $item->isEnd() ) {
        echo ( '</ul>' );
    // Display a menu item
    } else {
        // Display the menu item with bullets
        echo ( "<li><a href=\"".$baseUrl.$item->location()."\">" );
        if ( $item->isCurrent() )
            echo ( '>> '.$item->name().' <<' );
        else
            echo ( $item->name() );
        echo ( "</a></li>" );
    }
}
?>
</td>
<td>
The URL is <?php echo ( $_SERVER['PHP_SELF'] );?><br />
The BaseUrl is <?php echo ( $baseUrl );?><br />
The Location fragment is <?php echo ( $location );?>
</body>
</html>