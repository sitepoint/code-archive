<?php
// Include the PathVars class
require_once ('Url/PathVars.php');

// MODIFY THIS!!!
$baseUrl='/phpanth/WebPageElements/rewrite/';

// Create instance of PathVars
$pathVars=new PathVars($baseUrl);

// What's the first path variable?
switch ( $pathVars->fetchByIndex(0) ) {
    case 'download':
        // Examine the second path variable
        if ( $pathVars->fetchByIndex(1) ) {
            echo ( 'Downloading file '.$pathVars->fetchByIndex(1) );
        } else {
            echo ( 'Download <a href="'.$baseUrl.
                'download/myStuff.zip">myStuff.zip</a><br />' );
        }
        break;
    case 'article':
        // Examine the second path variable
        if ( $pathVars->fetchByIndex(1) ) {
            echo ( 'Viewing article '.$pathVars->fetchByIndex(1) );
        } else {
            echo ( 'View <a href="'.$baseUrl.
                'article/123">Article 123</a><br />' );
        }
        break;
    default:
        echo ( 'This is the home page<br />' );
        echo ( '<a href="'.$baseUrl.'download/">Downloads</a><br />' );
        echo ( '<a href="'.$baseUrl.'article/">Articles</a><br />' );
        break;
}
?>