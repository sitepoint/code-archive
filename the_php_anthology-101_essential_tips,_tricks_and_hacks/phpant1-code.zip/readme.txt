The PHP Anthology Code Archive
------------------------------

This archive contains all of the code discussed and referred to in "The PHP
Anthology" (1st Edition) by Harry Fuecks.

For each chapter of the two volumes, there is a corresponding directory in this
archive, which contains all of the sample scripts (1.php, 2.php, ...) and
supporting files where applicable.

There are two additional directories that you should also be aware of:

sql	This directory houses a number of text files, which contain the SQL
	code to create the MySQL database tables (complete with sample data)
	used in the books.

SPLIB	This directory contains all of the reusable code in the books. This
	includes most of the PHP classes developed throughout the text.
	Whenever a file appearing within the text can be found in the SPLIB
	directory, this is indicated at the top of the code listing for that
	file.

To try out the scripts in this code archive, simply extract the entire archive
(with directory structures intact) to a directory on your PHP-enabled Web
server. Once you've done that, you need only set your PHP include_path to
include the SPLIB directory, as described below.


IMPORTANT: SPLIB AND YOUR PHP include_path SETTING

Many of the sample scripts in the individual chapter directories rely on PHP
files that may be found in the SPLIB directory. For the scripts to find these
files on your server, the SPLIB directory must be added to your PHP
include_path setting.

Making this change also allows you to write your own scripts that use the
classes and other library files provided in the SPLIB directory, without
having to worry about where they are located.

The include_path can be set in your server's php.ini file, and can also be
modified on a per-directory basis with Apache .htaccess files. See Appendix A
of either volume for a description of the include_path setting. This setting
is also covered in greater detail in Volume I, Chapter 1, in the section
called "How do I include one PHP script in another?"


	Enjoy the code archive!
	-- Harry Fuecks and the team at SitePoint

