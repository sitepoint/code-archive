<?php
// include_me.php

echo ( "I've been included!<br />" );
?>