<?php
echo ( "This is some code<br />");
echo ( "Somewhere in here I've got a " );
echo ( "parse error!<br />" )
echo ( "But where is it?<br />" );
?>