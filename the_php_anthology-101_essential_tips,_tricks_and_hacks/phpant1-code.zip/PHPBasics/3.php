<?php
/* Note: This script will only work with PHP 4.3.0 + */

// Read a PHP script as a string
$script=file_get_contents('2.php');

// Fetch the tokens into an array
$tokens=token_get_all($script);

// Display
echo ( '<pre>' );
print_r($tokens);
echo ( '</pre>' );
?>