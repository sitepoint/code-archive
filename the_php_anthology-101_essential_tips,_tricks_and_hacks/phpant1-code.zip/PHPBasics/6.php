<?php
// Configuration settings
define ('DOMAIN','sitepoint.com');

// In another script
echo ( 'The domain is '.DOMAIN );
?>