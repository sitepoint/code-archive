<?php
$variable='This is not an array';

foreach ( $variable as $key => $value ) {
    echo ( $key.' : '.$value );
}
?>