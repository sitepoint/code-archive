#!/usr/bin/php
<?php
// Include the PEAR::Mimedecode class
require_once ( 'Mail/mimeDecode.php' );

// Read the email from the stdin file
$fp = fopen('php://stdin', 'r');
$email = fread ($fp, filesize ('php://stdin'));
fclose($fp);

$decode = new Mail_mimeDecode($email, "\r\n");
$structure = $decode->decode();

// Forward the message to the hotline email
if ( strstr ( $structure->headers['from'], 'vip@mycustomer.com' ) ) {
    mail ( 'you@yourdomain.com','Urgent Message!','Check your mail!' );
}
?>