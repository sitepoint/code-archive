<?php
// Include the phpmailer class
require('ThirdParty/phpmailer/class.phpmailer.php');

// Instantiate it
$mail = new phpmailer();

// Modify this
$yourEmail='you@yourdomain.com';
$yourName='Your Name';

// An array of recipients: Modify these
$recipients=array (
    'Your Name1'=>'you@yourdomain.com',
    'Your Name2'=>'you@yourdomain.com',
    'Your Name3'=>'you@yourdomain.com'
            );


// Define who the message is from
$mail->From = $yourEmail;
$mail->FromName = $yourName;

// Set the subject of the message
$mail->Subject = 'Test Group Mail';

// Add the body of the message
$body='This message is being sent to a group';
$mail->Body = $body;

// Look through the recipients
foreach ( $recipients as $name => $address ) {
    // Add a recicient address
    $mail->AddAddress($address, $name);

    // Send the message
    if(!$mail->Send())
        echo ('Mail sending failed to '.$address.'<br />');
    else
        echo ('Mail sent successfully to '.$address.'<br />');
    
    // Reset the address
    $mail->clearAddresses();
}

echo ( 'Finished sending emails<br />' );
?>