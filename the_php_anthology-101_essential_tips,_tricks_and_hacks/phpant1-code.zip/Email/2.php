<?php
// Include the phpmailer class
require('ThirdParty/phpmailer/class.phpmailer.php');

// Instantiate it
$mail = new phpmailer();

// Modify this
$yourEmail='your@yourdomain.com';
$yourName='Your Name';

// Modify this
$recipientEmail='your@yourdomain.com';
$recipientName='Your Name';

// Define who the message is from
$mail->From = $yourEmail;
$mail->FromName = $yourName;

// Set the subject of the message
$mail->Subject = 'Test Attachment';

// Add the body of the message
$body='This message has an attachment';
$mail->Body = $body;

// Add an attachment, 
if ( !$mail->AddAttachment ('./files/php_logo.gif',
                            'php_logo.gif',
                            'base64','image/gif') )
    echo ( 'Failed to attach file!<br />' );


// Add a recicient address
$mail->AddAddress($recipientEmail, $recipientName);

// Send the message
if(!$mail->Send())
    echo ('Mail sending failed');
else
    echo ('Mail sent successfully');
?>