<?php
// Include the phpmailer class
require('ThirdParty/phpmailer/class.phpmailer.php');

// Instantiate it
$mail = new phpmailer();

// Define who the message is from
$mail->From = 'you@yourdomain.com';
$mail->FromName = 'Your Name';

// Set the subject of the message
$mail->Subject = 'Test Message';

// Add the body of the message
$body='This is a test';
$mail->Body = $body;

// Add a recicient address
$mail->AddAddress('you@yourdomain.com', 'Your Name');

// Send the message
if(!$mail->Send())
    echo ('Mail sending failed');
else
    echo ('Mail sent successfully');
?>