<?php
// Include the QuickForm class
require_once ("HTML/QuickForm.php");

// Include the phpmailer class
require('ThirdParty/phpmailer/class.phpmailer.php');

// Modify this
$yourEmail='you@yourdomain.com';
$yourName='Your name';

// Instantiate QuickForm
$form = new HTML_QuickForm('imageUpload','POST');

// Add the recipient name field
$form->addElement('text', 'name' , 'Recepient Name: ');
$form->addRule('name', 'Enter a name','required',NULL,'client');

// Add the recipient address field
$form->addElement('text','mailTo' , 'Recepient Email: ');
$form->addRule('mailTo', 'Enter an email address','required',NULL,'client');
$form->addRule('mailTo', 'Enter a valid email address','email',NULL,'client');

// Add the subject field
$form->addElement('text', 'subject', 'Subject: ');
$form->addRule('subject', 'Enter a subject','required',NULL,'client');

// Add the message body
$form->addElement('textarea', 'body', 'Message: ');
$form->addRule('body', 'Add a body to the message','required',NULL,'client');

// The file upload field
$form->addElement('file', 'image', 'Select Image: ');
$form->addRule('image', 'The maximum file size is 56k', 'maxfilesize', 57344);
$form->addRule('image', 'The file must be an image', 'mimetype',
                            array('image/gif', 'image/jpeg', 'image/png'));
$form->addRule('image', 'No file selected.', 'uploadedfile',NULL,'client');

// The submit button
$form->addElement('submit', 'submit', 'Send');

if ($form->validate()) {
    // Fetch the details fof the file
    $name=$form->_submitFiles['image']['name'];
    $type=$form->_submitFiles['image']['type'];

    // Fetch file
    $filename = $form->_submitFiles['image']['tmp_name'];
    $fp = fopen ($filename, 'r');
    $contents = fread ($fp, filesize ($filename));
    fclose ($fp);

    // Instantiate it
    $mail = new phpmailer();

    // Define who the message is from
    $mail->From = $yourEmail;
    $mail->FromName = $yourName;

    // Set the subject of the message
    $mail->Subject = $form->getSubmitValue('subject');

    // Add the body of the message
    $mail->Body = $form->getSubmitValue('body');

    // Add the contents of the form upload 
    $mail->AddStringAttachment ($contents,$name,'base64',$type);

    // Add a recicient address
    $mail->AddAddress($form->getSubmitValue('mailTo'),
                      $form->getSubmitValue('name'));

    // Send the message
    if(!$mail->Send())
        echo ('Mail sending failed');
    else
        echo ('Mail sent successfully');

} else {
    $form->display();
}
?>