<?php
// Get the contents of the XML document
$articles=file('articles.xml');
$articles=implode("\n",$articles);

// Instantiate a DOM Document from the file
$dom=domxml_open_mem($articles); 

// Fetch new XPathContext object
$ctx = $dom->xpath_new_context(); 

// Register the Sitepoint namespace
$ctx->xpath_register_ns("spt","http://www.sitepoint.com"); 

// Fetch the articles with an XPath statement into an XPath object
$articles=& $ctx->xpath_eval("//spt:article");

echo ( '<b>Current Articles</b><br />' );

// Loop through the articles
foreach ( $articles->nodeset as $article ) {

    // Fetch the titles passing the $article object as a context node
    $title=& $ctx->xpath_eval("spt:title/text()",$article);

    // Fetch the authors passing the $article object as a context node
    $author=& $ctx->xpath_eval("spt:author/text()",$article);

    // Display the content
    echo ( '- '.$title->nodeset[0]->content.' ('.
        $author->nodeset[0]->content . ')<br />' );

}
?>