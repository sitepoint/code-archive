<?php
// Include the client class
require_once('ExampleApps/XMLRPCArticleClient.php');

// Define the URL of the server ( MODIFY THIS!! )
$server='http://localhost/phprecipes/XML/16.php';

// Instantiate the ArticleClient class
$articleClient= new XMLRPCArticleClient($server);

// Start building a table
$table="<table>\n";

// If we're viewing a single article
if ( isset ( $_GET['id'] ) ) {

    // Get the article from the client class
    if ( $article = $articleClient->getArticleById($_GET['id']) ) {

        // Build the table
        $table.="<tr>\n<td class=\"title\">".$article['title'].
                "</td>\n</tr>\n";
        $table.="<tr>\n<td class=\"author\">by ".$article['author'].
                "</td>\n</tr>\n";
        $table.="<tr>\n<td>".$article['body']."</td>\n</tr>\n";
    } else {
        $table.="<tr>\n<td>Service unavailable at this time</td>\n</tr>";
    }
} else {

    // Get an array of articles
    if ( $articles = $articleClient->getArticles() ) {

        // Loop through each article building the table
        foreach ( $articles as $article ) {
            $table.="<tr>\n";
            $table.="<td><a href=\"".$_SERVER['PHP_SELF'].
                    "?id=".$article['article_id']."\">".$article['title']."</a></td>";
            $table.="<td>".$article['author']."</td>";
            $table.="</tr>\n";
        }
    } else {
        $table.="<tr>\n<td>Service unavailable at this time</td>\n</tr>";
    }
}

// Finish the table
$table.="</table>\n";
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Sitepoint Articles </title>
<style type="text/css">
h1 {
    font-family: verdana;
    font-size: 15px;
    font-weight: bold;
    color: navy;
}
table {
    background-color: silver;
    width: 450px;
}
th {
    background-color: #f2f3f5;
    font-family: verdana;
    font-size: 11px;
    font-weight: bold;
    text-align: left;
}
td {
    background-color: white;
    font-family: verdana;
    font-size: 11px;
}
a {
    font-weight: bold;
}
.title {
    font-size: 14px;
    font-weight: bold;
}
.author {
    font-weight: italic;
    text-align: right;
}
</style>
</head>
<body>
<h1>Latest Articles</h1>
<?php echo ( $table ); ?>
</body>
</html>