<?php
// Fetch the entire document
$rssDoc=file('http://www.sitepoint.com/rss.php');
$rssDoc=implode('',$rssDoc);

// Start the xml parser tell it the character encoding
$sax = xml_parser_create('UTF-8');

// Perserve the orginal case of the XML document
xml_parser_set_option ( $sax, XML_OPTION_CASE_FOLDING, false);

// Read the XML document and drop it into the array $rssData
xml_parse_into_struct($sax,$rssDoc,$rssData);

// Free up the memory used by the parser
xml_parser_free ($sax);

// Start displaying a table
echo ( "<table width=\"400\" border=\"1\">\n" );

// Loop through the array
foreach ( $rssData as $element ) {

    // If this element contains a value
    if ( isset($element['value']) ) {

        // "Listen" for particular tags and display the correct HTML
        switch ( $element['tag'] ) {
            case 'title':
                echo ( "<tr>\n<td><b>".$element['value']."</b><br />" );
            break;
            case 'description':
                echo ( $element['value'].'<br />' );
            break;
            case 'link':
                echo ( "<a href=\"".$element['value']."\">".
                    $element['value']."</a></td>\n</tr>\n" );
            break;
        }
    }
}
echo ( "</table>\n" );
?>