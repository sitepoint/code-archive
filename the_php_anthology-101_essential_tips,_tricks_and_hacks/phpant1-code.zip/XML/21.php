<?php
// Include PEAR::SOAP Client class
require_once('SOAP/Client.php');

// Instantiate the SOAP_WSDL class; Modify this!
$wsdl=new SOAP_WSDL('http://localhost/phprecipes/XML/20.php?wsdl');

// Instantiate the ArticleClient class
$articleClient=$wsdl->getProxy();

// Start building a table
$table="<table>\n";

// If we're viewing a single article
if ( isset ( $_GET['id'] ) ) {
    // Call the getArticle() SOAP method
    $article = $articleClient->getArticleById($_GET['id']);

    // Handle any errors
    if (PEAR::isError($article)) {
        $fault=$article->getFault();
        trigger_error('Fault: '.$fault->faultcode.' '.$fault->faultstring);
        $table.="<tr>\n<td>Service unavailable at this time</td>\n</tr>\n";
    } else {
        // Build the table
        $table.="<tr>\n<td class=\"title\">".$article->title.
                "</td>\n</tr>\n";
        $table.="<tr>\n<td class=\"author\">by ".$article->author.
                "</td>\n</tr>\n";
        $table.="<tr>\n<td>".$article->body."</td>\n</tr>\n";
    }

} else {
    // Call the getArticles() SOAP method
    $articles = $articleClient->getArticles();

    // Handle any errors
    if (PEAR::isError($articles)) {
        $fault=$articles->getFault();
        trigger_error('Fault: '.$fault->faultcode.' '.$fault->faultstring);
        $table.="<tr>\n<td>Service unavailable at this time</td>\n</tr>\n";
    } else {
        // Loop through each article building the table
        foreach ( $articles as $article ) {
            $table.="<tr>\n";
            $table.="<td><a href=\"".$_SERVER['PHP_SELF'].
                    "?id=".$article->article_id."\">".$article->title."</a></td>";
            $table.="<td>".$article->author."</td>";
            $table.="</tr>\n";
        }
    }
}

// Finish the table
$table.="</table>\n";
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Sitepoint Articles </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
h1 {
    font-family: verdana;
    font-size: 15px;
    font-weight: bold;
    color: navy;
}
table {
    background-color: silver;
    width: 450px;
}
th {
    background-color: #f2f3f5;
    font-family: verdana;
    font-size: 11px;
    font-weight: bold;
    text-align: left;
}
td {
    background-color: white;
    font-family: verdana;
    font-size: 11px;
}
a {
    font-weight: bold;
}
.title {
    font-size: 14px;
    font-weight: bold;
}
.author {
    font-weight: italic;
    text-align: right;
}
</style>
</head>
<body>
<h1>Latest Articles</h1>
<?php echo ( $table ); ?>
</body>
</html>