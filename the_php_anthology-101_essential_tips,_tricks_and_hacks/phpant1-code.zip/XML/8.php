<?php
// Instantiate new XML document
$dom = domxml_new_doc('1.0');

// Create the root <example /> element
$example=$dom->create_element('example');

// Create the date element
$date=$dom->create_element('date');

// Create a text node to place the date in
$dateText=$dom->create_text_node(date('h:ia l jS M Y'));

// Append the date text node to the <date /> element
$date->append_child($dateText);

// Append the <date /> element to the <example /> element
$example->append_child($date);

// Append the root element to the document
$dom->append_child($example);

// Send the XML MIME type
header ('Content-Type: text/xml');

// Display the XML
echo ( $dom->dump_mem() );
?>