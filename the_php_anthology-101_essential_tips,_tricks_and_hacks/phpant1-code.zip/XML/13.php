<?php
// Include classes for accessing data from articles.xml
require_once('ExampleApps/ArticlesXML.php');
require_once('ExampleApps/Article.php');

// Get the contents of articles.xml
$articlesDoc=file('articles.xml');
$articlesDoc=implode('',$articlesDoc);

// Instantiate the Articles class
$articles = new ArticlesXML ( $articlesDoc );

// Begin constructing a table
$table = "<table>\n";

// If visitor is viewing a single article...
if ( isset ( $_GET['id'] ) ) {

    // Get the article by it's id
    if ( $article = $articles->getArticleById($_GET['id']) ) {

        // Build the body of the table
        $table.="<tr>\n<td class=\"title\">".$article->title().
                "</td>\n</tr>\n";
        $table.="<tr>\n<td class=\"author\">by ".$article->author().
                "</td>\n</tr>\n";
        $table.="<tr>\n<td>".$article->body()."</td>\n</tr>\n";
    }

// Build a list of articles
} else {
    $table.="<tr>\n<th>Title</th><th>Author</th>\n</tr>\n";

    // Loop through the articles and build into table body
    while ( $article = $articles->fetch() ) {
        $table.="<tr>\n";
        $table.="<td><a href=\"".$_SERVER['PHP_SELF'].
                "?id=".$article->id()."\">".$article->title()."</a></td>";
        $table.="<td>".$article->author()."</td>";
        $table.="</tr>\n";
    }
}

// Finish the table
$table .= "</table>\n";
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Sitepoint Articles </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
h1 {
    font-family: verdana;
    font-size: 15px;
    font-weight: bold;
    color: navy;
}
table {
    background-color: silver;
    width: 450px;
}
th {
    background-color: #f2f3f5;
    font-family: verdana;
    font-size: 11px;
    font-weight: bold;
    text-align: left;
}
td {
    background-color: white;
    font-family: verdana;
    font-size: 11px;
}
a {
    font-weight: bold;
}
.title {
    font-size: 14px;
    font-weight: bold;
}
.author {
    font-weight: italic;
    text-align: right;
}
</style>
</head>
<body>
<h1>Latest Articles</h1>
<?php echo ( $table ); ?>
</body>
</html>