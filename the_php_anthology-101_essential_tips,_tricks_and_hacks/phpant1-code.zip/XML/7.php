<?php
// Get a date as a string
$date=date('h:ia l jS M Y');

// Build an XML document as a string
$xml=<<<EOD
<?xml version="1.0"?>
<example>
<date>$date</date>
</example>
EOD;

// Send the XML MIME type
header ('Content-Type: text/xml');

// Display the XML
echo ( $xml );
?>