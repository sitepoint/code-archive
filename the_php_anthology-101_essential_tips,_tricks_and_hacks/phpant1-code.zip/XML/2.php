<?php
// Variables which will needed to be accessed "globally"

$newItem = false; // A "marker" for when we're inside an <item />
$element = ''; // Stores the name of the current element
$title = ''; // Holds the contents of a <title /> element
$description = ''; // Holds the contents of a <description /> element
$link = ''; // Holds the contents of a <link /> element
$table="<table width=\"400\">\n"; // Stores HTML table

// Responds to opening tags
function open ($sax, $element, $attributes) {

    // If we're inside an <item /> tag
    if ($GLOBALS['newItem'] == true)

        // ...store the name of the element
        $GLOBALS['element'] = $element; 

    // If it's a new <item /> tag
    else if ($element == 'ITEM')

        // Switch on the newItem marker
        $GLOBALS['newItem'] = true; 
}

// Responds to closing tags
function close($sax, $element) {
    // If it's the closing tag of an <item /> element...
    if ($element == 'ITEM') {

        // ... add the contents of <title /> etc. to the table
        $GLOBALS['table'].="<tr>\n<td><a href=\"".$GLOBALS['link'].
            "\">".$GLOBALS['title']."</a><br />\n".$GLOBALS['description'].
            "</td>\n</tr>";

        // Rest the contents variables
        $GLOBALS['title'] = '';
        $GLOBALS['description'] = '';
        $GLOBALS['link'] = ''; 

        // Switch off the newItem marker
        $GLOBALS['newItem'] = false; 
    }
}

// Responds to the character data inside an element
function data($sax, $data) { 
    // If we're inside an <item /> tag...
    if ($GLOBALS['newItem']==true) {

        // ... store the data for the elements in this list...
        switch ($GLOBALS['element']) {
            case 'TITLE':
                $GLOBALS['title'] .= $data; 
                break; 
            case 'DESCRIPTION':
                $GLOBALS['description'] .= $data; 
                break; 
            case 'LINK':
                $GLOBALS['link'] .= $data;
                break; 
        } 
    } 
}

// Create the XML parser
$sax = xml_parser_create('UTF-8');

// Register the open and close callback functions
xml_set_element_handler($sax,'open','close');

// Register the character data callback function
xml_set_character_data_handler($sax,'data');

// Open a connection to Sitepoint
$fp = fopen ( 'http://www.sitepoint.com/rss.php','r' );

// Loop until the end of the file
while ( !feof($fp) ) {
    // Fetch a chunk of data
    $data = fgets ($fp);

    // Parse it
    xml_parse($sax,$data);
}

// Now free up the parser
xml_parser_free($sax);

// Finish off the table
$table.="</table>\n";
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Sitepoint News </title>
<style type="text/css">
table {
    background-color: silver;
}
td {
    background-color: white;
    font-family: verdana;
    font-size: 11px;
}
a {
    font-weight: bold;
}
</style>
</head>
<body>
<?php echo ( $table ); ?>
</body>
</html>