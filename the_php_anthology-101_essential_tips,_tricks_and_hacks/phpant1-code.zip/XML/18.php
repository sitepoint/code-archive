<?php
// Include the PEAR::SOAP client class
require_once('SOAP/Client.php');

// Instantiate the SOAP_WSDL class using the online document
$wsdl=new SOAP_WSDL('http://live.capescience.com/wsdl/GlobalWeather.wsdl');

// Get the proxy class for the service
$proxy=$wsdl->generateProxyCode('','StationInfo');

// Display the code
echo '<pre>';
echo htmlspecialchars($proxy);
echo '</pre>';
?>