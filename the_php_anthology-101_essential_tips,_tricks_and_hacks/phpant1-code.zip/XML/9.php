<?php
// Include the RssGenerator class
require_once('XML/RssGenerator.php');

// Some sample data representing a database query
$articles = array (
    array (
        'title'=>'Verify a User\'s Email Address Using PHP',
        'link'=>'http://www.sitepoint.com/article/1051',
        'description'=>'So you published a registration page on your site... 
          and all you get is fake email addresses? Joe shows how to use
          PHP\'s checkdnsrr function to ensure the mail domain exists,
          and those addresses are valid.'
          ),
    array (
        'title'=>'Using Regular Expressions in PHP',
        'link'=>'http://www.sitepoint.com/article/974',
        'description'=>'Are you getting stuck on PHP\'s regular expressions?
          Look no further than James\' down-and-dirty how-to, which tells
          you all the basics you need to know, and shows how to put them
          to good use!'
          )
);

// Define variables to be used in building the feed
$title='Sitepoint';
$link='http://www.sitepoint.com';
$desc='Empowering Web Developers since 1997';
$about='http://www.sitepoint.com/about/';
$logo='http://www.sitepoint.com/images/sitepoint-logo.gif';
$searchTitle='Search';
$searchDesc='Search Sitepoint...';
$searchUrl='http://www.sitepoint.com/search/search.php';
$searchVar='q';

// Instantiate the RssGenerator
$rssGen=new RssGenerator();

// Add the channel information
$rssGen->addChannel($title,$link,$desc,$about);

// Add the image description
$rssGen->addImage($logo,$title,$link);

// Add the search description
$rssGen->addSearch($searchTitle,$searchDesc,$searchUrl,$searchVar);

// Loop through the articles...
foreach ($articles as $article) {
    
    // Add the <item /> for each article
    $rssGen->addItem($article['title'],
                     $article['link'],$article['description']);
}

// Send the XML Mime type
header ( 'Content-type: text/xml' );

// Display the document
echo ( $rssGen->toString() );
?>