<?php
// Define paths to XML and XSL documents (MODIFY THIS!)
// Note For Windows prepend with "file://" e.g.;
// $xml = 'file://c:/htdocs/XML/articles.xml';
$xml='/full/path/to/sitepoint/XML/articles.xml';
$xsl='/full/path/to/sitepoint/XML/articles.xsl';

// Instantiate the XSLT processor
$xp = xslt_create();

// Perform the XSL Transformation
$result = xslt_process($xp, $xml, $xsl) or
    // If there's a problem, display the error
    $result="<tr>\n<td>Error (".xslt_errno($xp).
            ") performing XSLT:".xslt_error($xp)."</td>\n</tr>\n";

// Embed the result in an HTML table
$table = "<table>\n";
$table.= $result;
$table .= "</table>\n";
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Sitepoint Articles </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
h1 {
    font-family: verdana;
    font-size: 15px;
    font-weight: bold;
    color: navy;
}
table {
    background-color: silver;
    width: 450px;
}
th {
    background-color: #f2f3f5;
    font-family: verdana;
    font-size: 11px;
    font-weight: bold;
    text-align: left;
}
td {
    background-color: white;
    font-family: verdana;
    font-size: 11px;
}
a {
    font-weight: bold;
}
.title {
    font-size: 14px;
    font-weight: bold;
}
.author {
    font-weight: italic;
    text-align: right;
}
</style>
</head>
<body>
<h1>Latest Articles</h1>
<?php echo ( $table ); ?>
</body>
</html>