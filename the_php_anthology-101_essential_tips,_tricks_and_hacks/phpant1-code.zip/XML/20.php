<?php
// Include the MySQL class
require_once('Database/MySQL.php');

// Include the SOAP Article Server
require_once('ExampleApps/SOAPArticleserver.php');

// Define variables for MySQL class
$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL class
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Instantiate ArticleServer class
$server= new SOAPArticleServer($db);
?>