<?php
// Get the contents of the XML document
$articles=file('articles.xml');
$articles=implode('',$articles);

// Instantiate a DOM Document from the file
$dom=domxml_open_mem($articles); 

// Fetch new XPathContext object
$ctx = $dom->xpath_new_context(); 

// Register the Sitepoint namespace
$ctx->xpath_register_ns("spt","http://www.sitepoint.com"); 

// Fetch all the link targets
$links=& $ctx->xpath_eval("//a/@href");

// Display the links
echo ( '<b>Document contains the following links</b><br />' );
foreach ( $links->nodeset as $link ) {
    echo ( '- '.$link->value.'<br />');
}
?>