<?php
// Include the MySQL class
require_once('Database/MySQL.php');

// Include the XMLRPCArticleServer
require_once('ExampleApps/XMLRPCArticleServer.php');

// Define variables for MySQL class
$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL class
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Instantiate ArticleServer class
$server= new XMLRPCArticleServer($db);
?>