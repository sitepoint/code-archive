<?php
// Set up global variables
$rssItem=new stdClass;  // Temporary variable stores contents of <item />
$rssItems=array(); // Stores a list of <item> objects

// Get the root RDF element
function rdf ($dom) {
    $rdf = $dom->document_element();

    // Call Items() to fetch all <item /> tags
    items($rdf);
}

// Gets all the <item /> tags
function items ($rdf) {
    // Fetch all the <item /> elements from the document
    $items = $rdf->get_elements_by_tagname('item');
    item ($items);
}

// Populates $rssItems with single <item />'s
function item ($items) {
    global $rssItem, $rssItems;
    // Loop through each item
    foreach ( $items as $item ) {
        // Get the children of each item
        $itemNodes = $item->child_nodes();
        itemNode($itemNodes);
        $rssItems[]=$rssItem;
        $rssItem=new stdClass;
    }
}

// Fetches the contents within at <item />
function itemNode($itemNodes) {
    // Loop through the children
    foreach ( $itemNodes as $itemNode ) {
        // Get the contents of each child
        $itemContents=$itemNode->child_nodes();
        itemContent($itemNode,$itemContents);
    }
}

// Collects the text nodes from within the content
function itemContent ($itemNode,$itemContents) {
    foreach ( $itemContents as $itemContent ) {
        // If it's a text node, display the HTML
        if( $itemContent->node_type() == XML_TEXT_NODE ) {
            $itemData=$itemContent->content;
            StoreData($itemNode,$itemData);
        }
    }
}

// Stores the text node in the current $rssItem global variable
function storeData ($itemNode,$itemData) {
    global $rssItem;
    // Deal with the specific elements we want
    switch ( strtoupper($itemNode->tagname) ) {
        case 'TITLE':
            $rssItem->title=$itemData;
            break;
        case 'DESCRIPTION':
            $rssItem->description=$itemData;
            break;
        case 'LINK':
            $rssItem->link=$itemData;
            break;
    }
}

// Fetch the entire document
$rssDoc=file('http://www.sitepoint.com/rss.php');
$rssDoc=implode('',$rssDoc);

// Instantiate an instance of DOM from file
$dom = domxml_open_mem($rssDoc);

// Call the Rdf function to start parsing
rdf($dom);

// Build a table out of the $rssItems array
$table="<table width=\"450\">\n";
foreach ( $rssItems as $rssItem ) {
    $table.="<tr>\n<td><a href=\"".$rssItem->link."\">".$rssItem->title."</a><br />\n";
    $table.=$rssItem->description."</td>\n</tr>\n";
}
$table.="</table>\n";

echo ( $table );
?>