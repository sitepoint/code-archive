<?php
// Switch off error notices
error_reporting (E_ALL ^ E_NOTICE);

// Instantiate an instance of DOM from file
$dom = domxml_open_file('http://www.sitepoint.com/rss.php');

// Get the root RDF element
$rdf = $dom->document_element();

// Fetch all the <item /> elements from the document
$items = $rdf->get_elements_by_tagname('item');

// Start displaying a table
echo ( "<table width=\"450\" border=\"1\">\n" );

// Loop through each item
foreach ( $items as $item ) {

    // Get the children of each item
    $itemNodes = $item->child_nodes();

    // Loop through the children
    foreach ( $itemNodes as $itemNode ) {

        // Get the contents of each child
        $itemContents=$itemNode->child_nodes();

        // Deal with the specific elements we want
        switch ( strtoupper($itemNode->tagname) ) {

            case 'TITLE':
                // Loop through the contents to find the text node
                foreach ( $itemContents as $itemContent ) {
                    // If it's a text node, display the HTML
                    if( $itemContent->node_type() == XML_TEXT_NODE ) {
                        echo ( "<tr>\n<td><b>".$itemContent->content .
                            "</b><br />\n" );
                    }
                }
                break;

            case 'DESCRIPTION':
                foreach ( $itemContents as $itemContent ) {
                    if( $itemContent->node_type() == XML_TEXT_NODE ) {
                        echo ( $itemContent->content ."<br />\n" );
                    }
                }
                break;

            case 'LINK':
                foreach ( $itemContents as $itemContent ) {
                    if( $itemContent->node_type() == XML_TEXT_NODE ) {
                        echo ( "<a href=\"".$itemContent->content."\">".
                            $itemContent->content."</a><br />\n" );
                    }
                }
                break;

        }
    }
}
echo ( "</table>\n" );
?>