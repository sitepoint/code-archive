<?php
// Include the SaxRssParser
require_once('XML/SaxRssParser.php');

// Instantiate it
$parser = new SaxRssParser();

// Open a connection to Sitepoint
$fp = fopen ( 'http://www.sitepoint.com/rss.php','r' );

// Loop until the end of the file
while ( !feof($fp) ) {
    // Fetch a chunk of data
    $data = fgets ($fp);

    // Parse the date with the SaxRssParser object
    $parser->parse($data);
}

// Start building a table
$table="<table width=\"400\">\n"; // Stores HTML table

// Loop through the items
while ( $item = $parser->fetch() ) {
    $table.="<tr>\n<td>";
    $table.="<a href=\"".$item->link."\">".$item->title."</a><br />\n";
    $table.=$item->description."\n";
    $table.="</td>\n</tr>\n";
}

// Finish off the table
$table.="</table>\n";
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Sitepoint News </title>
<style type="text/css">
table {
    background-color: silver;
}
td {
    background-color: white;
    font-family: verdana;
    font-size: 11px;
}
a {
    font-weight: bold;
}
</style>
</head>
<body>
<?php echo ( $table ); ?>
</body>
</html>