<?php
// Get the contents of the XML document
$articles=file('articles.xml');
$articles=implode('',$articles);

// Instantiate a DOM Document from the file
$dom=domxml_open_mem($articles); 

// Fetch new XPathContext object
$ctx = $dom->xpath_new_context(); 

// Register the Sitepoint namespace
$ctx->xpath_register_ns("spt","http://www.sitepoint.com"); 

// Fetch the titles with an XPath statement into an XPath object
$titles=& $ctx->xpath_eval("//spt:title/text()");

// Display the data structure
echo ( '<pre>' );
print_r($titles);
echo ('</pre>');
?>