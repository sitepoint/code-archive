<?php
// Include the DomRssParser class
require_once ( 'XML/DomRssParser.php' );

// Fetch the entire document
$rssDoc=file('http://www.sitepoint.com/rss.php');
$rssDoc=implode('',$rssDoc);

// Instantiate the parser
$parser = new DomRssParser($rssDoc);

// Build a table out of the $rssItems array
$table="<table width=\"450\">\n";

// Loop through the items building the HTML
while ( $item = $parser->fetch() ) {
    $table.="<tr>\n<td><a href=\"".$item->link."\">".$item->title."</a><br />\n";
    $table.=$item->description."</td>\n</tr>\n";
}

// Finish the table
$table.="</table>\n";
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Sitepoint News </title>
<style type="text/css">
table {
    background-color: silver;
}
td {
    background-color: white;
    font-family: verdana;
    font-size: 11px;
}
a {
    font-weight: bold;
}
</style>
</head>
<body>
<?php echo ( $table ); ?>
</body>
</html>