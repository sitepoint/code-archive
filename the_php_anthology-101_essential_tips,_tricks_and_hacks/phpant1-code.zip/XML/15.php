<?php
// Define paths to XML and XSL documents (MODIFY THIS!)
// Note For Windows prepend with "file://" e.g.;
// $xml = 'file://c:/htdocs/XML/articles.xml';
$xml='/full/path/to/sitepoint/XML/articles.xml';
$xsl='/full/path/to/sitepoint/XML/article2sql.xsl';

// Define the XSLT error handler
function xslt_error_handler ($xp, $errNo, $level, $fields) {
    $errMsg = 'Error #'.$errNo.', Level '.$level.', Fields:<br />';
    if ( is_array ( $fields ) ) {
        foreach ( $fields as $key => $value ) {
            $errMsg .= $key .' => '.$value.'<br />';
        }
    } else {
        $errMsg .= $fields.'<br />';
    }
    trigger_error ($errMsg);
}

// Instantiate the XSLT processor
$xp = xslt_create();

// Set the error handler
xslt_set_error_handler($xp, 'xslt_error_handler');

// An array of params to pass to the processor
$params = array ( 'tableName'=>'articles' );

// Perform the transform using the PHP variables
$result = xslt_process($xp, $xml, $xsl,null,null,$params);

// Display the result
echo ( "<pre>".$result."</pre>" );
?>