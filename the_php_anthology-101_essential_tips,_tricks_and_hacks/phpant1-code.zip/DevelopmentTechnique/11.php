<?php
if (!defined('SIMPLE_TEST')) {
    // Modify this line to point at your simpletest installation
    define('SIMPLE_TEST', '../../simpletest/');
}
require_once(SIMPLE_TEST . 'unit_tester.php');
require_once(SIMPLE_TEST . 'mock_objects.php');
require_once(SIMPLE_TEST . 'reporter.php');
require_once('8.php');

// Create a MockStamp
Mock::generate('Stamp');

// Create the test class
class TestOfStampCollection extends UnitTestCase {
    function TestOfStampCollection() {
        $this->UnitTestCase('StampCollection');
    }

    // Test adding the add method 
    function testAdd() {
        // Create the MockStamp object
        $mockStamp = & new MockStamp($this);

        // Set the member variables
        $mockStamp->name = 'Penny Black';
        $mockStamp->price = 3500;

        // Create the StampCollection
        $stampCollection = & new StampCollection();

        // Add the MockStamp to the StampCollection
        $stampCollection->add($mockStamp);

        // Get a copy of the stamp back
        $stampCopy = $stampCollection->fetch();

        // Compare the names of the stamps
        $this->assertEqual($stampCopy->name,$mockStamp->name);
    }
}

$test = &new TestOfStampCollection();
$test->run(new HtmlReporter());
?>