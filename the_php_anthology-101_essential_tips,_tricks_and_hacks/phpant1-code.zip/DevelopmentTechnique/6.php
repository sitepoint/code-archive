<?php
/**
 * @abstract
 */
class Something {

}
/**
 * This class does something.
 */
class DoesSomething extends Something {
    /**
    * Stores some string
    * @access private
    * @var string
    */
    var $someString;
    /**
    * Constructs DoesSomething
    * @param string Some string
    */
    function DoesSomething($someString) {
        $this->someString=$someString;
    }
    /**
    * Returns the stored someString
    * @param boolean whether to format XML entities
    * @return string
    * @access public
    */
    function getSomeString($specialChars=false) {
        if ( !$specialChars )
            return $this->someString;
        else
            return htmlspecialchars($this->someString);
    }
}
?>