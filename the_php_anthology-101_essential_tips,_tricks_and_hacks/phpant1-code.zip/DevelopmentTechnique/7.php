<?php
/**
 * @package MyFirstDocumentedPackage
 */
/**
 * Randomizer Class
 *
 * Given an array this class allows you fetch random
 * elements from it.
 *
 * <code>
 * $randomizer = new Randomizer($array);
 * $randomElement = $randomizer->get();
 * </code>
 *
 * @author  Joe Bloggs <joe.bloggs@example.com>
 * @access  public
 * @package MyFirstDocumentedPackage
 */
class Randomizer {
    /**
     * Stores the array to be randomized
     * @var array
     * @access private
     */
     var $array = array();
    /**
     * Constructs Randomizer
     * @param array the array to be randomized
     * @access public
     */
     function Randomizer($array) {
        $this->array = $array;
        srand ((float)microtime()*1000000);
     }
    /**
     * Gets an element value from the array at random
     * @return mixed
     * @access public
     */
     function get() {
        shuffle($this->array);
        return $this->array[0];
     }
}
?>