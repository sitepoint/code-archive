<?php
// Check Xdebug is installed
if ( !extension_loaded('xdebug') )
    die ('<a href="http://xdebug.derickrethans.nl/">Xdebug</a> required');

// Create an array with element values from 1 to 50000
$numbers = range(1,50000);

// Start Xdebug profiling
xdebug_start_profiling();

// For with count function call in loop
for ( $i=0; $i < count($numbers); $i++ ) {
    // Do something here
}

// Place count() outside for loop
$size = count($numbers); 
for ( $i=0; $i < $size; $i++ ) {
    // Do something here
}

// Display the Xdebug line by line report
xdebug_dump_function_profile();
?>