<?php
/**
 * A Class for Collecting Stamps
 * @access public
 */
class StampCollection {
    /**
     * An array of Stamp objects
     * @var Stamp
     * @access private
     */
    var $collection = array();

    /**
     * Adds a stamp to the collection
     * @param Stamp
     * @return void
     * @access public
     */
    function add($stamp) {
       $this->collection[].=$stamp;
    }

    /**
     * Fetches a stamp to the collection
     * @return mixed
     * @access public
     */
    function fetch() {
       $stamp = each ( $this->collection );
       if ( $stamp ) {
           return $stamp;
       } else {
           reset($this->collection);
           return false;
       }
    }
}

/**
 * Stores details of a single stamp
 * @access public
 */
class Stamp {
    /**
     * Name of the stamp
     * @var string
     * @access public
     */
    var $name;

    /**
     * Stores the price of the stamp
     * @var int
     * @access public
     */
    var $price;

    /**
     * Constructs Stamp
     * @param string name of stamp
     * @param int price of stamp
     * @access public
     */
    function Stamp($name,$price) {
        $this->name = $name;
        $this->price = $price;
    }
}
?>