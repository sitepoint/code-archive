<?php
class LazyInclude {
    var $session;
    function LazyInclude () {
        // Include the class as it's needed
        require_once('Session/Session.php');
        $this->session = & new Session();
    }
}

$li = new LazyInclude();
?>