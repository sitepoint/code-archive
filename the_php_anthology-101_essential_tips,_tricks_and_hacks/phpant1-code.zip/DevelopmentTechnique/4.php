<?php
// Start Data Access Layer
if ( !mysql_connect('localhost', 'harryf', 'secret') ) {
    die ('Could not connect to database server');
}
if ( !mysql_select_db('sitepoint') ) {
    die('Could not select database');
}
// End Data Access

// Start Presentation Logic
if ( isset($_GET['id']) ) {

    // Start Application logic
    $sql = "SELECT title, body, published FROM articles WHERE article_id='".
        $_GET['id']."'";
    // End Application logic

    // Start Data Access
    $result = mysql_query($sql);
    $row = mysql_fetch_array($result);
    // End Data Access Layer

    // Start Application logic
    $date = date('Y m d',$row['published']);
    // End Application logic

    // Start Presentation Logic
    echo ( "<h1>".$row['title']."</h1>\n" );
    echo ( "Published: $date<br />" );
    echo ( $row['body']."<br />\n" );
    // End Presentation Logic

} else {

    // Start Application logic
    $sql = "SELECT article_id, title FROM articles LIMIT 0,5";
    // End Application logic

    // Start Data Access
    $result = mysql_query($sql);
    while ( $row = mysql_fetch_array($result) ) {

        // Start Application logic
        $date = date('Y m d',$row['published']);
        // End Application logic

        // Start Presentation Logic
        echo ( "<a href=\"".$_SERVER['PHP_SELF']."?id=".
            $row['article_id']."\">".$row['title']."</a>".
            $date."<br />\n" );
        // End Presentation Logic

    }
    // End Data Access

}
// End Presentation Logic
?>