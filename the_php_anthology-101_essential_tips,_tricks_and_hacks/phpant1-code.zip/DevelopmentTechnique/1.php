<?php
// Check Xdebug is installed
if ( !extension_loaded('xdebug') )
    die ('<a href="http://xdebug.derickrethans.nl/">Xdebug</a> required');

// Start Xdebug profiling
xdebug_start_profiling();

// A array of colors "weighted" to red
$colors = array ('red','red','red','red','red','red','red','blue');

// The slow way
function isBlueSlow ($color) {
    if ( $color == 'blue' ) {
        return TRUE;
    }
    return FALSE;
}

// The fast way - test for red first
function isBlueFast ($color) {
    if ( $color != 'blue' ) {
        return FALSE;
    }
    return TRUE;
}


// Test the slow way
for ($i=0;$i<50;$i++) {
    if ( ! $color = each ( $colors ) ) {
        reset ( $colors );
        $color = each ( $colors );
    }
    if ( isBlueSlow($color['value']) ) {
        // Do something here
    }
}

// Test the fast way
for ($i=0;$i<50;$i++) {
    if ( ! $color = each ( $colors ) ) {
        reset ( $colors );
        $color = each ( $colors );
    }
    if ( isBlueFast($color['value']) ) {
        // Do something here
    }
}

// Display the Xdebug report grouped by function call
xdebug_dump_function_profile(XDEBUG_PROFILER_NC);
?>