<?php
if (!defined('SIMPLE_TEST')) {
    // Modify this line to point at your simpletest installation
    define('SIMPLE_TEST', '../../simpletest/');
}
require_once(SIMPLE_TEST . 'unit_tester.php');
require_once(SIMPLE_TEST . 'mock_objects.php');
require_once(SIMPLE_TEST . 'reporter.php');
require_once('8.php');

echo ( '<pre>' );
// Don't try this at home. _createClassCode is private!
echo ( Mock::_createClassCode('Stamp','MockStamp') );
echo ( '</pre>' );
?>