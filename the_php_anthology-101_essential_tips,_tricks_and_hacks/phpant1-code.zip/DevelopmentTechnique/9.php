<?php
if (!defined('SIMPLE_TEST')) {
    // Modify this line to point at your simpletest installation
    define('SIMPLE_TEST', '../../simpletest/');
}
require_once(SIMPLE_TEST . 'unit_tester.php');
require_once(SIMPLE_TEST . 'reporter.php');
require_once('8.php');

// Create the test class
class TestOfStamp extends UnitTestCase {
    function TestOfStamp() {
        $this->UnitTestCase('Stamp');
    }

    // Test the name of the stamp
    function testName() {
        // Create a Stamp object
        $stamp = new Stamp('Penny Black',3500);

        // Compare the names of the stamps
        $this->assertEqual($stamp->name,'Penny Black');
    }

    // Test the name of the stamp is a string
    function testNameType() {
        // Create a Stamp object
        $stamp = new Stamp('Penny Black',3500);

        // Compare the names of the stamps
        $this->assertTrue(is_string($stamp->name));
    }

    // Test the price of the stamp
    function testPrice() {
        // Create a Stamp object
        $stamp = new Stamp('Penny Black',3500);

        // Compare the names of the stamps
        $this->assertEqual($stamp->price,3500);
    }

    // Test the price of the stamp is an int
    function testPriceType() {
        // Create a Stamp object
        $stamp = new Stamp('Penny Black',3500);

        // Compare the names of the stamps
        $this->assertTrue(is_int($stamp->price));
    }
}

$test = &new TestOfStamp();
$test->run(new HtmlReporter());
?>