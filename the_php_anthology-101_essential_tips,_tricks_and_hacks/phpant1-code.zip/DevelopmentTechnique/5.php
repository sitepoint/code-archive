<?php
// Data Access Layer Classes
require_once('Database/MySQL.php');
require_once('ExampleApps/Articles.php');

// Application Logic Class
require_once('ExampleApps/Article.php');

// Presentation Logic Classes
require_once('ExampleApps/ArticlesView.php');
require_once('ExampleApps/ArticleView.php');

$db = & new MySQL('localhost','harryf','secret','sitepoint');

if ( isset($_GET['id']) ) {
    $articles = & new Articles($db);
    $articles->getArticle($_GET['id']);
    $article = $articles->fetch();
    $view = & new ArticleView($article);
} else {
    $articles = & new Articles($db);
    $articles->getArticles();
    $view = & new ArticlesView($articles);
}

echo ( $view->render() );
?>