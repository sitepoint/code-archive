<?php
if ( @$_GET['name'] == 'Bill' ) {
    echo ( 'This page is not available to you' );
} else {
    echo ( 'Welcome' );
}
?>