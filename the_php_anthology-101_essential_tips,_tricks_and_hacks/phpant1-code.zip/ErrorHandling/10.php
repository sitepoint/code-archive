<?php
/**
 * Custom Error handler
 *
 * @param int error level number
 * @param string error message
 * @param string php script where error occurred
 * @param int line number in script where error was triggered
 * @param array current state of all global variables
 */
function myErrorHandler ($errLvl, $errMsg, $errFile, $errLine, $errContext) {
    switch ( $errLvl ) {
        // Handle ERRORs
        case E_USER_ERROR:
            // Stop and clean the second buffer
            ob_end_clean();
            // Clean out the main buffer
            ob_clean();
            // Display an error message
            echo ( '
<html>
<head>
<title>Tempory Interruption</title>
</head>
<body>
<h2>Temporary Interruption</h2>
The site is currently down for non-scheduled maintenance.<br />
Please try again shortly
</body>
</html>' );
            // End and flush the main buffer
            ob_end_flush();
            // Stop execution
            exit();
        break;
        // Handle WARNINGs
        case E_USER_WARNING:
            // Clean out the main buffer
            ob_clean();
            // Display an error message
            echo ( '<b>Warning:</b> '.$errMsg );
        break;
        // Handle NOTICEs
        case E_USER_NOTICE:
            // Display an error message
            echo ( '<b>Notice:</b> '.$errMsg );
        break;
    }
}

// Set the custom error handler
set_error_handler('myErrorHandler');
// Start an output buffer for ERRORs
ob_start()
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Custom Error Handling with Buffering </title>
</head>
<body>
<h2>Example Errors</h2>
<?php
// Start a second output buffer for NOTICES and WARNINGs
ob_start();
?>
<a href="<?php echo ( $_SERVER['PHP_SELF'] ); ?>?triggerError=error">
Trigger a Fatal Error</a><br />
<a href="<?php echo ( $_SERVER['PHP_SELF'] ); ?>?triggerError=warning">
Trigger a Warning</a><br />
<a href="<?php echo ( $_SERVER['PHP_SELF'] ); ?>?triggerError=notice">
Trigger a Notice</a><br />

<?php
// Sample triggered errors
if ( isset ( $_GET['triggerError'] ) ) {
    switch ( $_GET['triggerError'] ) {
        case 'error':
            trigger_error('A fatal error',E_USER_ERROR);
        break;
        case 'warning':
            trigger_error('you have been warned!',E_USER_WARNING);
        break;
        case 'notice':
            trigger_error('please take note!',E_USER_NOTICE);
        break;
    }
}
// Finish and display the second buffer
ob_end_flush();
?>

</body>
</html>
<?php
// Finish the main buffer
ob_end_flush();
?>