<?php
error_reporting(E_ALL ^ E_NOTICE); // Report all errors except notices
echo ( error_reporting() ); // Displays 2039
?>