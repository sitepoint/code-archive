<?php
/**
 * Custom Error handler
 *
 * @param int error level number
 * @param string error message
 * @param string php script where error occurred
 * @param int line number in script where error was triggered
 * @param array current state of all global variables
 */
function myErrorHandler ($errLvl, $errMsg, $errFile, $errLine, $errContext) {
    $time = date ('YmdHis');
    $errMsg = htmlspecialchars($errMsg);
    $error=<<<EOD
###START ERROR###
Level: $errLvl
File: $errFile
Line: $errLine
Time: $time

$errMsg
###END ERROR###

EOD;
    error_log($error,3,'log/errors.log');
    switch ( $errLvl ) {
        case E_USER_ERROR:
            echo ('System is temporarily unavailable. Please try again later');
        break;
    }
}

// Set the custom error handler
set_error_handler('myErrorHandler');

// Trigger an error
if ( !@mysql_connect('localhost','wronguser','wrongpassword') )
    trigger_error('Error connecting to MySQL Server: '.mysql_error(),
                    E_USER_ERROR);
?>