<?php
echo ( error_reporting() );
?>