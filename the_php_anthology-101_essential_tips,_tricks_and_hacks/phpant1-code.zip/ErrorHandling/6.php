<?php
if ( !@mysql_connect('localhost','wronguser','wrongpassword') )
    trigger_error('Error connecting to MySQL Server: '.mysql_error(),
                    E_USER_ERROR);

echo ( 'Hello World!' );
?>