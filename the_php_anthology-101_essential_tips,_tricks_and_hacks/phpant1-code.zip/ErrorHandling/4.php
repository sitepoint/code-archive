<?php
// Use error reporting operator
if ( !@ mysql_connect('localhost','wronguser','wrongpassword' ) )
    echo ( 'Error connecting to MySQL Server: '.mysql_error() );
?>