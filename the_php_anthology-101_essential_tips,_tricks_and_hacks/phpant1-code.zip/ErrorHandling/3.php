<?php
error_reporting(E_ALL); // Report all errors
error_reporting(2047); // Report all errors
error_reporting(0); // Turn off error reporting
?>