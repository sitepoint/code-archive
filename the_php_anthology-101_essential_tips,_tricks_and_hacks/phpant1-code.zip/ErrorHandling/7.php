<?php
/**
 * Custom Error handler
 *
 * @param int error level number
 * @param string error message
 * @param string php script where error occurred
 * @param int line number in script where error was triggered
 * @param array current state of all global variables
 */
function myErrorHandler ($errLvl, $errMsg, $errFile, $errLine, $errContext) {
    // Switch statement watching for specific error levels
    switch ( $errLvl ) {
        case E_USER_ERROR:
            $error="
                <h2>Custom Error Message</h2>
                <b>E_USER_ERROR</b> in $errFile on line $errLine<br />
                $errMsg";
        break;
    }
    echo ( $error );
}

// Set the custom error handler
set_error_handler('myErrorHandler');

// Trigger an error
if ( !@mysql_connect('localhost','wronguser','wrongpassword') )
    trigger_error('Error connecting to MySQL Server: '.mysql_error(),
                    E_USER_ERROR);
?>