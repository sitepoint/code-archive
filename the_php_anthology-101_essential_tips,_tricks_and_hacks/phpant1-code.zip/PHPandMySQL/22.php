<?php
// Builds the DataObjects classes
$_SERVER['argv'][1] = 'db_dataobject.ini';
require_once('DB/DataObject/createTables.php');
?>