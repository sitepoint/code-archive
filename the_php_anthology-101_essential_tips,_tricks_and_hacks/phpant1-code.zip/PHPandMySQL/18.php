<?php
// Include the MySQL class
require_once('Database/MySQL.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

$db = & new MySQL($host,$dbUser,$dbPass,$dbName);

// A query to insert a row
$sql="INSERT INTO 
        articles
      SET
        title='How to use mysql_insert_id()',
        body='This is an example',
        author='HarryF'";

$result = $db->query($sql);

echo ( "The new row as ID: ".$result->insertID() );
?>