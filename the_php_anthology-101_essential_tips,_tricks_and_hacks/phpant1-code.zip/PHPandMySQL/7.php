<?php
function & connectToDb ($host,$dbUser,$dbPass,$dbName) {
    // Make connection to MySQL server
    if (!$dbConn = @mysql_connect($host, $dbUser, $dbPass))
        return false;

    // Select the database
    if ( !@mysql_select_db($dbName) )
        return false;

    return $dbConn;
}

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Connect to MySQL
$dbConn=& connectToDb($host,$dbUser,$dbPass,$dbName);

$title='How to insert data';
$body='This is the body of the article';
$author='HarryF';

// A query to INSERT data
$sql="INSERT INTO
        articles
      SET
        title='".$title."',
        body='".$body."',
        author='".$author."'";

// Run the query, identifying the connection
if (!$queryResource=mysql_query($sql,$dbConn)) {
    trigger_error ('Query error '.mysql_error().' SQL: '.$sql);
}
?>