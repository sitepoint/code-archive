<?php
// Include the MySQLDump class
require_once('Database/MySQLDump.php');

$dbUser = 'harryf';             // db User
$dbPass = 'secret';             // db User Password
$dbName = 'sitepoint';          // db name
$dest = '/home/harryf/backups'; // Path to directory (no trailing slash)
$zip = 'bz2';                   // ZIP utility to compress backup file with

// Instantiate MySQLDump
$mysqlDump=new MySQLDump($dbUser,$dbPass,$dbName,$dest,$zip);

// Perform the backup
$mysqlDump->backup();
?>