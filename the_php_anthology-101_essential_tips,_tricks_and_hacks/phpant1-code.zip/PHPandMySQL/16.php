<?php
function & connectToDb ($host,$dbUser,$dbPass,$dbName) {
    // Make connection to MySQL server
    if (!$dbConn = @mysql_connect($host, $dbUser, $dbPass))
        return false;

    // Select the database
    if ( !@mysql_select_db($dbName) )
        return false;

    return $dbConn;
}

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Connect to MySQL
$dbConn=& connectToDb($host,$dbUser,$dbPass,$dbName);

// A query which updates the database
$sql="UPDATE 
        articles
      SET
        author='The Artist Formerly Known as...'
      WHERE
        author='HarryF'";

// Run the query, identifying the connection
$queryResource=mysql_query($sql,$dbConn);

// Fetch the number of rows affected
$changedRows=mysql_affected_rows($dbConn);

echo ( $changedRows . " rows changed<br />" );
?>