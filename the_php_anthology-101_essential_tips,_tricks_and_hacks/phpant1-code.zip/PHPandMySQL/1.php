<?php
$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Make connection to MySQL server
if (!$dbConn = mysql_connect($host, $dbUser, $dbPass)) {
    trigger_error('Could not connect to server: '.mysql_error());
    die ();
}

// Select the database
if ( !mysql_select_db($dbName) )
    die ('Could not select database');

echo 'Connection successful!';
// ... some code here using MySQL


// Close the connection when finished
mysql_close($dbConn);
?>