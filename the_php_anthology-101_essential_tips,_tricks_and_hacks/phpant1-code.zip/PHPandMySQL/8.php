<?php
function & connectToDb ($host,$dbUser,$dbPass,$dbName) {
    // Make connection to MySQL server
    if (!$dbConn = @mysql_connect($host, $dbUser, $dbPass))
        return false;

    // Select the database
    if ( !@mysql_select_db($dbName) )
        return false;

    return $dbConn;
}

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Connect to MySQL
$dbConn=& connectToDb($host,$dbUser,$dbPass,$dbName);

$title='How to insert data';
$body='This is the body of the article';
$author='HarryF';

// A query to select an article
$sql="SELECT article_id FROM articles WHERE title='How to insert data'";

if (!$queryResource=mysql_query($sql,$dbConn)) {
    trigger_error ('Query error '.mysql_error().' SQL: '.$sql);
}

// Fetch a single row from the result
$row=mysql_fetch_array($queryResource,MYSQL_ASSOC);

// A new title
$title='How to update data';

$sql="UPDATE
        articles
      SET
        title='".$title."'
      WHERE
        article_id='".$row['article_id']."'";
        

if (!$queryResource=mysql_query($sql,$dbConn)) {
    trigger_error ('Query error '.mysql_error().' SQL: '.$sql);
}
?>