<?php
function & connectToDb ($host,$dbUser,$dbPass,$dbName) {
    // Make connection to MySQL server
    if (!$dbConn = @mysql_connect($host, $dbUser, $dbPass))
        return false;

    // Select the database
    if ( !@mysql_select_db($dbName) )
        return false;

    return $dbConn;
}

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Connect to MySQL
$dbConn=& connectToDb($host,$dbUser,$dbPass,$dbName);

// Query to count the rows returned
$sql="SELECT COUNT(*) as numrows FROM articles";

// Run the query, identifying the connection
$queryResource=mysql_query($sql,$dbConn);

$row=mysql_fetch_array($queryResource,MYSQL_ASSOC);

echo ( $row['numrows'] . " rows selected<br />" );

// A query to select all articles
$sql="SELECT * FROM articles ORDER BY title";

// Run the query, identifying the connection
$queryResource=mysql_query($sql,$dbConn);

// Fetch rows from MySQL one at a time
while ($row=mysql_fetch_array($queryResource,MYSQL_ASSOC)) {
    echo ( 'Title: '.$row['title'].'<br />' );
    echo ( 'Author: '.$row['author'].'<br />' );
    echo ( 'Body: '.$row['body'].'<br />' );
}
?>