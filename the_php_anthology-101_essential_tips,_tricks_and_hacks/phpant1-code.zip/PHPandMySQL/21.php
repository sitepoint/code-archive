<?php
// Include the MySQL class
require_once('Database/MySQL.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

$db = & new MySQL($host,$dbUser,$dbPass,$dbName);

// A query to show the tables in the database
$sql="SHOW TABLES FROM sitepoint";

// Execute query
$result = $db->query($sql);

// Get the number of tables found
$numTables = $result->size();

// Build a string of table names
$tables = '';
$i = 1;
while ( $table = $result->fetch() ) {
    $tables.=$table['Tables_in_sitepoint'];
    if ( $i < $numTables )
        $tables.=', ';
    $i++;
}

// Build the backup query
$sql = "BACKUP TABLE $tables TO '/home/harryf/backup'";

// Perform the query
$db->query($sql);

if ( !$db->isError() )
    echo ( 'Backup succeeded' );
else
    echo ( 'Backup failed' );
?>