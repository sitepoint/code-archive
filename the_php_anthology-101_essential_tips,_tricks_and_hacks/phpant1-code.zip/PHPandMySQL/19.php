<?php
$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Make connection to MySQL server
if (!$dbConn = mysql_connect($host, $dbUser, $dbPass)) {
    trigger_error('Could not connect to server: '.mysql_error());
    die ();
}

// Select the database
if ( !mysql_select_db($dbName) ) {
    trigger_error ('Could not select database: '.mysql_error());
    die ();
}

// Select only those rows that match
// $sql="SELECT * FROM articles WHERE MATCH (title,body,author) AGAINST ('MySQL')";

// Select all rows but display relvance
$sql="SELECT
        *, MATCH (title,body,author) 
      AGAINST
        ('The PHP Anthology Released Long Word Matching')
      AS
        score
      FROM
        articles
      ORDER BY score DESC";

// Run the query, identifying the connection
$queryResource=mysql_query($sql,$dbConn);

// Fetch rows from MySQL one at a time
while ($row=mysql_fetch_array($queryResource,MYSQL_ASSOC)) {
   
    echo ( 'Title: '.$row['title'].'<br />' );
    echo ( 'Author: '.$row['author'].'<br />' );
    echo ( 'Body: '.$row['body'].'<br />' );
    echo ( 'Score: '.$row['score'].'<br />' );
}
?>