<?php
// Start a session
session_start();

// Check to see if $viewImages is registered
if ( isset ( $_SESSION['viewImages'] ) && $_SESSION['viewImages'] == TRUE ) {

    // An array of available images
    $images=array(
        'sitepoint_logo.jpg',
        'php-big.png'
        );

    // If $_GET['img'] is set and in available...
    if ( isset ($_GET['img']) && in_array($_GET['img'],$images) ) {

        // Get the image information
        $dims=getimagesize('sample_images/'.$_GET['img']);

        // Send the correct HTTP headers
        header('content-disposition: inline; filename=' . $_GET['img']);
        header('content-type: '.$dims['mime']); # PHP 4.3.x +
        header('content-length: ' . filesize('sample_images/'.$_GET['img']));

        // Display the image
        readfile('sample_images/'.$_GET['img']);

    } else {
        die ('Invalid or no image specified');
    }

} else {
    die ('This image is protected from hotlinking');
}
?>