<?php
// Load the original image
$image=imagecreatefrompng('sample_images/mysql_logo.png');

// Get image width
$iWidth=imagesx($image);

// Allow transparent images...
imagealphablending($image, true); 

// Get the watermark image
$watermark=imagecreatefrompng('sample_images/sitepoint_watermark.png');

// Get the height and width
$wmWidth=imagesx($watermark);
$wmHeight=imagesy($watermark);

// Find the far right position
$xPos=$iWidth-$wmWidth;

// Copy the watermark to the top right of original image
imagecopy($image, $watermark, $xPos, 0, 0, 0, $wmWidth, $wmHeight); 

// Send the HTTP content header
header ( 'Content-Type: image/png' );

// Display the final image
imagejpeg($image);
?>
