<?php
// Include the Thumbnail class
require_once('Images/Thumbnail.php');

// Instantiate the thumbnail
$tn=new Thumbnail(200,200);

// Load an image into a string (this could be from a database)
$image=file_get_contents('sample_images/sitepoint_logo.jpg');

// Load the image data
$tn->loadData($image,'image/jpeg');

// Build the thumbnail and store as a file
$tn->buildThumb('sample_images/thumb_sitepoint_logo.jpg');
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Thumbnail Example </title>
</head>

<body>
<h1>Before...</h1>
<img src="sample_images/sitepoint_logo.jpg">
<h1>After...</h1>
<img src="sample_images/thumb_sitepoint_logo.jpg"
 width="<?php echo ( $tn->getThumbWidth() );?>"
 height="<?php echo ( $tn->getThumbHeight() );?>">
</body>
</html>