<?php
// Load the original image
$image=imagecreatefrompng('sample_images/mysql_logo.png');

// Get a color and allocate to the image pallet
$color=imagecolorallocate($image,153,153,153);

// Add the text to the image
imagestring($image, 3, 0, 0, 'Skippy 2003', $color);

// Send the HTTP content header
header ( 'Content-Type: image/png' );

// Display the final image
imagejpeg($image);
?>