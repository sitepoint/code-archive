<?php
// Start a session
session_start();

// Register a variable in the session
$_SESSION['viewImages'] = TRUE;
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Preventing Hotlinking </title>
</head>
<body>
<p>Here is the image:</p>
<img src="11.php?img=php-big.png">
</body>
</html>