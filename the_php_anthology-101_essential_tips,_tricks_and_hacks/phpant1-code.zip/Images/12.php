<?php
// Include the session class
require_once('Session/Session.php');

// Instantiate the Session class
$session= new Session();

// Register a variable in the session
$session->set('viewImages',TRUE);
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Preventing Hotlinking </title>
</head>
<body>
<p>Here is the image:</p>
<img src="13.php?img=php-big.png">
</body>
</html>