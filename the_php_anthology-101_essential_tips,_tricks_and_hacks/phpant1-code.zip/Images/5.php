<?php
// Include the ThumbNail class
require_once('Images/Thumbnail.php');

// Open the sample_images subdirectory
$dir=dir('sample_images');

// Read through the files looking for images to convert
while ( $image = $dir->read() ) {
    // Get the file extension
    $ext = explode('.',$image);
    $size = count($ext);
    // Check that it's a valid file
    if ( ($ext[$size-1] == 'png' || $ext[$size-1] == 'jpg')
        && !preg_match('/^thumb_/', $image)
        && $image != '.' && $image != '..' ) {
        // Check no thumbnail exists for this image
        if ( file_exists('sample_images/thumb_'.$image) ) {
            continue;
        } else {
            // Instantiate the thumbnail without scaling small images
            $tn=& new Thumbnail(200,200,true,false);
            // Create the thumbnail
            $tn->loadFile('sample_images/'.$image);
            $tn->buildThumb('sample_images/thumb_'.$image);
        }
    }
}

// Rewind the directory listing
$dir->rewind();

// Start building an HTML table
$table="<table border=\"1\" cellpadding=\"5\">\n";

// Read through the directory and add thumbnails to the table
while ( $image = $dir->read() ) {
    if ( preg_match('/^thumb_/',$image ) == 1
            && $image != '.' && $image != '..' ) {
        $table.="<tr>\n<td align=\"center\">";
        $table.="<img src=\"sample_images/".$image."\">";
        $table.="</td>\n</tr>\n";
    }
}

$table.="</table>\n";

?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Thumbnail Example </title>
</head>

<body>
<h1>Thumbnails...</h1>
<?php echo ( $table ); ?>
</body>
</html>