<?php
// Specify source image
$sourceImage='sample_images/sitepoint_logo.jpg';

// Get the size of the original
$dims=getimagesize($sourceImage);

echo ( '<pre>' );
print_r($dims);
echo ( '</pre>' );
?>