<?php
$colors = array ('red','green','blue');

echo ( '<b>First iteration:</b><br />' );
foreach ( $colors as $color ) {
    echo ( $color.'<br />' );
}

echo ( '<b>Second iteration:</b><br />' );
foreach ( $colors as $color ) {
    echo ( $color.'<br />' );
}
?>