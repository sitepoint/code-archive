<?php
/**
* Base factory class
*/
class EmailFactory {
    function getBody($text) {
        // Abstract Factory Method
    }
}
/**
* Factory for plain text emails
*/
class TextEmailFactory extends EmailFactory {
    function getBody($text) {
        return new TextBody($text);
    }
}
/**
* Factory for HTML emails
*/
class HtmlEmailFactory extends EmailFactory {
    function getBody($text) {
        return new HtmlBody($text);
    }
}
/**
* The class created by TextEmailFactory::getBody()
*/
class TextBody {
    var $text;
    function TextBody($text) {
        $this->text = $text;
    }
}
/**
* The class created by HtmlEmailFactory::getBody()
*/
class HtmlBody {
    var $text;
    function HtmlBody($text) {
        $this->text = $text;
    }
}
/**
* Class which "sends" and email
*/
class EmailSender {
    function sendMessage($email,$body) {
        echo ( "Sending email to $email with a ".get_class($body).'<br>' );
    }
}

// A dummy array of customers to send emails to
$customers = array (
    array ('email'=>'jbloggs@yahoo.com','emailpreferred'=>'html'),
    array ('email'=>'jleno@cnn.com','emailpreferred'=>'text'),
    array ('email'=>'aleegator@reptiles.com','emailpreferred'=>'html')
);

// The HTML and plain text versions of the email
$htmltext = 'This is an <em>HTML Message</em>';
$plaintext = 'This is plain text';

// Create the sender
$sender =& new EmailSender();

// Loop through the customers
foreach ( $customers as $customer ) {
    // Decide which factory class to create
    switch ( $customer['emailpreferred'] ) {
        case 'html':
            // Create the factory
            $factory = & new HtmlEmailFactory();
            // Call the factory method
            $body = & $factory->getBody($htmltext);
            break;
        case 'text':
        default:
            // Create the factory
            $factory = & new TextEmailFactory();
            // Call the factory method
            $body = & $factory->getBody($plaintext);
            break;
    }
    // "Send" the message
    $sender->sendMessage($customer['email'],$body);
}
?>