<?php
// Include the adapter classes
require_once('Database/PEARDBAdapter.php');

// Instantiate PEARDBAdapter connection
$db = & new PEARDBAdapter('localhost','harryf','secret','sitepoint');

// Perform query
$sql = "SELECT title, author FROM articles LIMIT 0,5";
$result = & $db->query($sql);

// Display some results
while ( $row = $result->fetch() ) {
    echo ( '<b>'.$row['title'].'</b> by '.$row['author']."<br />\n" );
}
?>