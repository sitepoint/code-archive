<?php
// Include MySQL class
require_once ( 'Database/MySQL.php' );
// Include HTMLTable class
require_once ( 'UI/HTMLTable.php' );

// Instantiate MySQL
$db = & new MySQL('localhost','harryf','secret','sitepoint');
$sql = "SELECT title, author FROM articles LIMIT 0,5";

// Get a query result via factory method
$result = $db->query($sql);

// Pass result to HTMLTable on instantiation
$table = & new HTMLTable($result,'Iterator_');

// Add the headings to the table
$table->addHeadings(array('Title','Author'));

// Build the rows
$table->buildRows();
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Iterator </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
td, th {
    font-size: 0.9em;
    font-family: verdana;
}
table#Iterator_Table {
    background-color: #b2b3b4;
    width: 15em;
}
tr#Iterator_HeaderRow {
    background-color: white;
}
th#Iterator_HeaderCol {
    font-size: 0.9em;
    font-family: verdana;
    font-weight: bold;
    padding: 0.3em;
}
tr#Iterator_Row1 {
    background-color: #d2d3d4;
}
tr#Iterator_Row2 {
    background-color: white;
}
td#Iterator_Col {
    padding: 0.2em;
}
</style>
</head>
<body>
<?php echo ( $table->render() ); ?>
</body>
</html>