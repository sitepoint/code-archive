<?php
require_once('Validators/ValidateUser.php');
require_once('Validators/ValidatePassword.php');
require_once('Validators/ValidateEmail.php');

// Validate the form
if ( isset ($_POST['submit']) ) {
    // A array to store errors
    $errors = array();

    // Collection of validators
    $validators = array();
    $validators[]=new ValidateUser($_POST['user']);
    $validators[]=new ValidatePassword(array($_POST['pass'],$_POST['conf']));
    $validators[]=new ValidateEmail($_POST['email']);

    // Iterate over the validators, validating as we go
    foreach($validators as $validator) {
        if (!$validator->isValid()) {
            while ( $error = $validator->fetch() ) {
                $errors[]=$error;
            }
        }
    }
}
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Form </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
</head>
<body>
<b>Please enter your details:</b><br />
<form action="<?php echo ( $_SERVER['PHP_SELF'] ); ?>" method="post">
Username: <input type="text" name="user"><br />
Password: <input type="password" name="pass"><br />
Confirm: <input type="password" name="conf"><br />
Email: <input type="text" name="email"><br />
<input type="submit" name="submit" value="Submit Form">
</form>
<?php
if ( isset($errors) && count($errors) > 0 ) {
    echo ( "<b>The following errors occurred:</b><br />\n" );
    echo ( "<ul>\n" );
    foreach ( $errors as $error ) {
        echo ( "<li>".$error."</li>\n" );
    }
    echo ( "</ul>\n" );
}
?>
</body>
</html>