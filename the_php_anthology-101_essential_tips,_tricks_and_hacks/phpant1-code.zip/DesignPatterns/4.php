<?php
class Colors {
    // An array where the colors are stored
    var $colors;
    function Colors() {
        $this->colors = array ('red','green','blue');
    }
    // This method Iterates over the colors array
    function fetch() {
        // Use the each() function to get the current value and step forward
        $color = each ( $this->colors );

        // If $color wasn't false...
        if ( $color ) {
            // return the value
            return $color['value'];

        // $color is false (reached the end of the array)...
        } else {
            // Reset the colors array
            reset ( $this->colors );
            // Return false
            return false;
        }
    }
}

// Instantiate the Colors class
$colors = new Colors();

// Iterate over it twice using a while loop and the fetch() method
echo ( '<b>First iteration:</b><br />' );
while ( $color = $colors->fetch() ) {
    echo ( $color.'<br />' );
}

echo ( '<b>Second iteration:</b><br />' );
while ( $color = $colors->fetch() ) {
    echo ( $color.'<br />' );
}
?>