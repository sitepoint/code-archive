<?php
// Include MySQL class
require_once('Database/MySQL.php');

// Instantiate MySQL connection
$db = & new MySQL('localhost','harryf','secret','sitepoint');

// Perform query
$sql = "SELECT title, author FROM articles LIMIT 0,5";
$result = & $db->query($sql);

// Display some results
while ( $row = $result->fetch() ) {
    echo ( '<b>'.$row['title'].'</b> by '.$row['author']."<br />\n" );
}
?>