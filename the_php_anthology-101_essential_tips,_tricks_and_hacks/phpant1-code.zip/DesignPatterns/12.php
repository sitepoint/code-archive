<?php
// Include the Observable and Observer base classes
require_once('Observer/Observable.php');
require_once('Observer/Observer.php');

class Article extends Observable {
    // To publish an article
    function publish() {
        echo ( 'Publishing article.<br />' );
        // Perform query here that updates the database
        $this->notifyObservers('published');
    }
    // To delete an article
    function delete() {
        echo ( 'Deleting article.<br />' );
        // Perform query here that deletes an article
        $this->notifyObservers('deleted');
    }
}

class Cache extends Observer {
    function update(& $source, $arg) {
        switch ( $arg ) {
            case 'published':
            case 'deleted':
                echo ( 'Refreshing cache<br />' );
            break;
        }
    }
}

class Subscribers extends Observer {
    function update(& $source, $arg) {
        switch ( $arg ) {
            case 'published':
                echo ( 'Notifying subscribers by email<br />' );
            break;
        }
    }
}

class RSSFeed extends Observer {
    function update(& $source, $arg) {
        switch ( $arg ) {
            case 'published':
            case 'deleted':
                echo ( 'Updating the RSS Feed<br />' );
            break;
        }
    }
}

// Create the observers
$cache = & new Cache();
$subscribers = & new Subscribers();
$rssfeed = & new RSSFeed();

// Create the observable
$article=& new Article();

// Add the observers to the observable
$article->addObserver($cache);
$article->addObserver($subscribers);
$article->addObserver($rssfeed);

if ( isset ( $_POST['publish'] ) ) {
    $article->publish();
} else if ( isset ( $_POST['delete'] ) ) {
    $article->delete();
} else {
?>
<form action="<?php echo ( $_SERVER['PHP_SELF'] ); ?>" method="post">
<textarea cols="50" rows="5">
This is a sample article
</textarea><br />
<input type="submit" name="publish" value="Publish Article"><br />
<input type="submit" name="delete" value="Delete Article"><br />
</form>
<?php
}
?>