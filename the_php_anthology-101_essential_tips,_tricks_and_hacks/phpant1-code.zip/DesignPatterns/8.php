<?php
// Validate the form
if ( isset ($_POST['submit']) ) {
    // A array to store errors
    $errors = array();

    // Check the incoming data
    if ( $_POST['user'] < '6' ) {
        $errors[]='Username is too short';
    }
    if ( $_POST['pass'] < '6' ) {
        $errors[]='Password is too short';
    }
    if ( $_POST['pass'] != $_POST['conf'] ) {
        $errors[]='Passwords do not match';
    }
    if ( !preg_match('/^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,4}$/i',
        $_POST['email']) ) {
        $errors[]='Invalid Email address';
    }
}
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Form </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
</head>
<body>
<b>Please enter your details:</b><br />
<form action="<?php echo ( $_SERVER['PHP_SELF'] ); ?>" method="post">
Username: <input type="text" name="user" /><br />
Password: <input type="password" name="pass" /><br />
Confirm: <input type="password" name="conf" /><br />
Email: <input type="text" name="email" /><br />
<input type="submit" name="submit" value="Submit Form" />
</form>
<?php
if ( isset($errors) && count($errors) > 0 ) {
    echo ( "<b>The following errors occurred:</b><br />\n" );
    echo ( "<ul>\n" );
    foreach ( $errors as $error ) {
        echo ( "<li>".$error."</li>\n" );
    }
    echo ( "</ul>\n" );
}
?>
</body>
</html>