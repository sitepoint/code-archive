<?php
// Include Session class
require_once ('Session/Session.php');

// Include RandomImageText class
require_once ('Images/RandomImageText.php');

// Instantiate the Session class
$session=new Session;

// Instantiate RandomImageText giving the background image
$imageText=new RandomImageText ('reg_image/reg_image.jpg');

// Add the text from the session
$imageText->addText($session->get('randomString'));

// Send the right mime type
header ( 'Content-type: image/jpeg' );

// Display the image
ImageJpeg($imageText->getImage());
?>