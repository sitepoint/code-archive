<?php
// Include MySQL class
require_once ('Database/MySQL.php');

// Include AccountMaintenance class
require_once ('AccessControl/AccountMaintenance.php');

// Include QuickForm class
require_once ("HTML/QuickForm.php");

// Include phpmailer class
require_once ('ThirdParty/phpmailer/class.phpmailer.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// phpmailer settings
$yourName='Your Name';
$yourEmail='you@yourdomain.com';
$subject='Your password';
$msg='Here are your login details. Please change your password.';

// Instantiate the QuickForm class
$form =& new HTML_QuickForm('passwordForm', 'POST');

// Add a header to the form
$form->addElement('header', 'header', 'Forgotten Your Password?');

// Add a field for the login
$form->addElement('text','login','Enter your login name');
$form->addRule('login','Enter your login','required',false,'client');

// Add a field for the email address
$form->addElement('text','email','Enter your email address');
$form->addRule('email','Enter your email','required',false,'client');
$form->addRule('email','Enter a valid email address','email',false,'client');

// Add a submit button
$form->addElement('submit','submit','Get Password');

// If the form is submitted...
if ( $form->validate() ) {

    // Instantiate MySQL connection
    $db=& new MySQL($host,$dbUser,$dbPass,$dbName);

    // Instantiate Account Maintenance class
    $aMaint=new AccountMaintenance($db);

    // Fetch a list of words
    $fp = fopen ( './pass_words/pass_words.txt','rb' );
    $file= fread ( $fp, filesize('./pass_words/pass_words.txt') );
    fclose($fp);

    // Add the words to the class
    $aMaint->addWords(explode("\n",$file));

    // Reset the password
    if ( !$details=$aMaint->resetPassword(
                                    $form->getSubmitValue('login'),
                                    $form->getSubmitValue('email') ) ) {
        echo ('We have no records of your account');
    } else {
        // Instantiate phpmailer class
        $mail = new phpmailer();
        // Define who the message is from
        $mail->From = $yourEmail;
        $mail->FromName = $yourName;

        // Set the subject of the message
        $mail->Subject = $subject;
        
        // Build the message
        $mail->Body = $msg."\n\nLogin: ".$details['login'].
                      "\nPassword: ".$details['password'];

        // Add the recipient
        $name=$details['firstName'].' '.$details['lastName'];
        $mail->AddAddress($form->getSubmitValue('email'),$name);

        // Send the message
        if($mail->Send())
            echo ('An email has been sent to '.
                    $form->getSubmitValue('email'));
        else
            echo ('Problem sending your details. Please contact the site '.
                  'administrators');
    }
} else {
    // If not submitted, display the form
    $form->display();
}
?>