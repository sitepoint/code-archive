<?php
// Include QuickForm class
require_once ("HTML/QuickForm.php");

// If $_GET['from'] comes from the Auth class
if ( isset ( $_GET['from'] ) ) {
    $target=$_GET['from'];
} else {
    // Default URL: usually index.php
    $target='12.php';
}

// Instantiate the QuickForm class
$form =& new HTML_QuickForm('loginForm', 'POST', $target);

// Add a header to the form
$form->addElement('header', 'header', 'Please Login');

// Add a field for the login name
$form->addElement('text','login','Username');
$form->addRule('login','Enter your login','required',false,'client');

// Add a field for the password
$form->addElement('password','password','Password');
$form->addRule('password','Enter your password','required',false,'client');

// Add a submit button
$form->addElement('submit','submit',' Login ');

$form->display();
?>