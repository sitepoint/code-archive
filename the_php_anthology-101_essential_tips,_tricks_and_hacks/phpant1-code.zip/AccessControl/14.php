<?php
// Include MySQL class
require_once ('Database/MySQL.php');

// Include Session class
require_once ('Session/Session.php');

// Include Auth class
require_once ('AccessControl/Auth.php');

// Include User class
require_once ('AccessControl/User.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Instantiate the Authentication class
$auth=& new Auth($db,'13.php','secret');

// Instantiate the User class
$user=& new User($db);

// Switch on the view GET variable
switch (@$_GET['view']) {
    case 'create':
        // Define permission (corresponding to a name in permissions table)
        $permission='create';
        // Create a message for users with access to this area
        $msg='From here you can create new content';
        break;
    case 'edit':
        $permission='edit';
        $msg='From here you can edit existing content';
        break;
    case 'delete':
        $permission='delete';
        $msg='From here you can delete existing content';
        break;
    default:
        $permission='view';
        $msg='From here you can read existing content';
}

// Check the user's permission. If inadequate, change the msg
if ( !$user->checkPermission($permission) ) {
    $msg='You do not have permission to do this';
}
?>
<p><?php echo ( $msg ); ?>
<p>
<a href="<?php echo ( $_SERVER['PHP_SELF'] ); ?>">Main</a> |
<a href="<?php echo ( $_SERVER['PHP_SELF'] ); ?>?view=create">Create</a> |
<a href="<?php echo ( $_SERVER['PHP_SELF'] ); ?>?view=edit">Edit</a> |
<a href="<?php echo ( $_SERVER['PHP_SELF'] ); ?>?view=delete">Delete</a>