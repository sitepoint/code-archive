<?php
// If $_GET['form'] comes from the Auth class
if ( isset ( $_GET['from'] ) ) {
    $target=$_GET['from'];
} else {
    // Default URL: usually index.php
    $target='5.php';
}
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Login Form </title>
<meta http-equiv="Content-type"
    content="text/html" charset="iso-8859-1" />
<style type="text/css">
body, a, td, input
{
    font-family: verdana;
    font-size: 11px;
}
h1
{
    font-family: verdana;
    font-size: 15px;
    color: navy
}
</style>
</head>
<body>
<h1>Please log in</h1>
<form action="<?php echo ( $target ); ?>" method="post">
<table>
<tr valign="top">
<td>Login Name:</td>
<td><input type="text" name="login" /></td>
</tr>
<tr valign="top">
<td>Password:</td>
<td><input type="password" name="password" /></td>
</tr>
<tr valign="top">
<td></td>
<td><input type="submit" value=" Login " /></td>
</tr>
</table>
</form>
</body>
</html>