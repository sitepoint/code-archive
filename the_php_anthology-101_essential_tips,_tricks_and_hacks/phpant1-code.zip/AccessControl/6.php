<?php
// Include the MySQL class
require_once('Database/MySQL.php');

// Include the Session class
require_once('Session/Session.php');

// Include the SignUp class
require_once('AccessControl/SignUp.php');

// Include the QuickForm class
require_once ('HTML/QuickForm.php');

// Include the phpmailer class
require_once ('ThirdParty/phpmailer/class.phpmailer.php');

// Settings for MySQL
$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Settings for SignUp class
$listener='http://localhost/phprecipes/AccessControl/6.php';
$frmName='Your Name';
$frmAddress='noreply@yoursite.com';
$subj='Account Confirmation';
$msg=<<<EOD
<h2>Thank you for registering!</h2>
<div>The final step is to confirm 
your account by clicking on:</div>
<div><confirm_url/></div>
<div>
<b>Your Site Team</b>
</div>
EOD;

// Instantiate the MySQL class
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Instantiate the Session class
$session=new Session();

// Instantiate the signup class
$signUp=new SignUp($db,$listener,$frmName,$frmAddress,$subj,$msg,TRUE);

// Is this an account confirmation ?
if ( isset ( $_GET['code'] ) ) {
    if ( $signUp->confirm($_GET['code']) ) {
        $display='Thank you. Your account has now been confirmed.<br />'.
               'You can now <a href="4.php">login</a>';
    } else {
        $display='There was a problem confirming your account.<br />'.
                 'Please try again or contact the site administrators';
    }

// Otherwise display the form
} else {

    // A function for comparing password
    function cmpPass($element, $confirmPass) {
        global $form;
        $password = $form->getElementValue('password');
        return ($password == $confirmPass);
    }

    // A function to encrypt the password
    function encryptValue($value) {
        return md5($value);
    }

    // Instantiate the QuickForm class
    $form =& new HTML_QuickForm('regForm', 'POST');
    $renderer =& $form->defaultRenderer();

    // Clear the default HTML templates
    $renderer->clearAllTemplates();

    // Define new templates
    $renderer->setFormTemplate('
<table class="registration">
  <form{attributes}>{content}
  </form>
</table>');

    $renderer->setHeaderTemplate('
    <tr>
      <td class="header" colspan="2">{header}</td>
    </tr>');

    $renderer->setElementTemplate('
    <tr valign="top">
      <td class="label">
      {label}
      </td>
      <td class="field">
      <!-- BEGIN error --><span class="error">{error}</span><br><!-- END error -->
      {element}
      <!-- BEGIN required --><span class="required">*</span><!-- END required -->
      </td>
    </tr>');

    $renderer->setRequiredNoteTemplate('
    <tr>
      <td>&nbsp;</td>
      <td class="requiredNote">{requiredNote}</td>
    </tr>');

    // Add a header to the form
    $form->addElement('header', 'header', 'Registration Form');

    // Register the compare function
    $form->registerRule('compare', 'function', 'cmpPass');

    // The login field
    $form->addElement('text','login','Desired Username:','class="signupData"');
    $form->addRule('login','Please provide a username','required',false,'client');
    $form->addRule('login','Username must be at least 6 characters','minlength',6,'client');
    $form->addRule('login','Username cannot be more than 50 characters','maxlength',50,'client');
    $form->addRule('login','Username can only contain letters and numbers','alphanumeric',NULL,'client');

    // The password field
    $form->addElement('password','password','Password:','class="signupData"');
    $form->addRule('password','Please provide a password','required',false,'client');
    $form->addRule('password','Password must be at least 6 characters','minlength',6,'client');
    $form->addRule('password','Password cannot be more than 12 characters','maxlength',50,'client');
    $form->addRule('password','Password can only contain letters and numbers','alphanumeric',NULL,'client');

    // The field for confirming the password
    $form->addElement('password','confirmPass','Confirm:','class="signupData"');
    $form->addRule('confirmPass','Please confirm password','required',false,'client');
    $form->addRule('confirmPass','Passwords must match','compare','function');

    // The email field
    $form->addElement('text','email','Email Address:','class="signupData"');
    $form->addRule('email','Please an email address','required',false,'client');
    $form->addRule('email','Please enter a valid email address','email',false,'client');
    $form->addRule('email','Email cannot be more than 50 characters','maxlength',50,'client');

    // The first name field
    $form->addElement('text','firstName','First Name:','class="signupData"');
    $form->addRule('firstName','Please enter your first name','required',false,'client');
    $form->addRule('firstName','First name cannot be more than 50 characters','maxlength',50,'client');

    // The last name field
    $form->addElement('text','lastName','Last Name:','class="signupData"');
    $form->addRule('lastName','Please enter your last name','required',false,'client');
    $form->addRule('lastName','Last name cannot be more than 50 characters','maxlength',50,'client');

    // The signature field
    $form->addElement('textarea','signature','Signature:','class="signature"');

    // Add a submit button called submit and "Send" as the text for the button
    $form->addElement('submit','submit','Register','class="createAccount"');

    // Specify the "required field" note for the bottom of the form
    $form->setRequiredNote('<span class="required">*</span> required');

    // If the form is submitted...
    if ( $form->validate() ) {
        // Apply the encryption filter to the password
        $form->applyFilter('password', 'encryptValue');

        // Build an array from the submitted form values
        $submitVars=array (
            'login'=>$form->getSubmitValue('login'),
            'password'=>$form->getSubmitValue('password'),
            'email'=>$form->getSubmitValue('email'),
            'firstName'=>$form->getSubmitValue('firstName'),
            'lastName'=>$form->getSubmitValue('lastName'),
            'signature'=>$form->getSubmitValue('signature') );

        // Create signup
        if ( $signUp->createSignup($submitVars) ) {
            // Send confirmation email
            if ( $signUp->sendConfirmation() ) {
                $display='Thank you. Please check your email to '.
                         'confirm your account';
            } else {
                $display='Unable to send confirmation email.<br />'.
                         'Please contact the site administrators';
            }
        } else {
            $display='There was an error creating your account.<br />'.
                     'Please try again later or '.
                     'contact the site administrators';
        }
    } else {
        // If not submitted, display the form
        $display=$form->toHtml();
    }
}
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Sign Up </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
body, a, td, input, textarea
{
    font-family: verdana;
    font-size: 11px;
}
.registration
{
    width: 400px;
}
.header
{
    color: navy;
    text-align: center;
    font-variant: small-caps;
    font-size: 15px;
    font-weight: bold;
    border-color: navy;
    border-style: dashed;
    border-width: 1px;
    background-color: #f6f7f8;
}
.label
{
    color: navy;
    text-align: right;
    width: 40%;
    font-weight: bold;
    padding: 3px;
}
.required
{
    color: red;
}
.field
{
    width: 60%;
    padding: 3px;
}
.error
{
    color: red;
}
.requiredNote
{
    font-size: 9px;
    text-align: right;
}
.signupData
{
    width: 200px;
    background-color: #f6f7f8;
    font-weight: bold;
}
.signature
{
    background-color: #f6f7f8;
    font-weight: bold;
    width: 200px;
    height: 100px;
}
.createAccount
{
    background-color: #f6f7f8;
    color: navy;
    font-weight: bold;
}
</style>
</head>
<body>
<?php echo ( $display );?>
</body>
</html>