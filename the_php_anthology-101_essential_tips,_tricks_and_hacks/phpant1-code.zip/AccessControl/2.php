<?php
// An array of allowed users
$users=array (
    'harryf'=>'secret',
    'littlepig'=>'chinny'
        );

// If there's no Authentication header, exit
if ( !isset ( $_SERVER['PHP_AUTH_USER'] ) ) {
    header('HTTP/1.0 401 Unauthorized');
    header('WWW-Authenticate: Basic realm="PHP Secured"');
    exit('This page requires authentication');
}

// Is the username doesnt exist, exit
if ( !isset( $users[$_SERVER['PHP_AUTH_USER']] ) ) {
    header('HTTP/1.0 401 Unauthorized');
    header('WWW-Authenticate: Basic realm="PHP Secured"');
    exit('Unauthorized!');
}

// Is the password doesn't match the username, exit
if ( $users[$_SERVER['PHP_AUTH_USER']] != $_SERVER['PHP_AUTH_PW'] ) {
    header('HTTP/1.0 401 Unauthorized');
    header('WWW-Authenticate: Basic realm="PHP Secured"');
    exit('Unauthorized!');
}

echo ( 'You\'re in' );
?>