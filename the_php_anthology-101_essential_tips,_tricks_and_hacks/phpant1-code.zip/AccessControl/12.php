<?php
// Include MySQL class
require_once ('Database/MySQL.php');

// Include Session class
require_once ('Session/Session.php');

// Include Authentication class
require_once ('AccessControl/Auth.php');

// Include AccountMaintenance class
require_once ('AccessControl/AccountMaintenance.php');

// Include QuickForm class
require_once ("HTML/QuickForm.php");

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Instantiate the Authentication class
$auth=& new Auth($db,'11.php','secret');

switch ( @$_GET['view'] ) {
    case 'changePassword':
        // Instantiate the QuickForm class
        $form =& new HTML_QuickForm('changePass','POST',
                                    '12.php?view=changePassword');

        // A function for comparing password
        function cmpPass($element, $confirm) {
            global $form;
            $password = $form->getElementValue('newPassword');
            return ($password == $confirm);
        }

        // Register the compare function
        $form->registerRule('compare', 'function', 'cmpPass');

        // Add a header to the form
        $form->addElement('header', 'header', 'Change your Password');

        // Add a field for the old password
        $form->addElement('password','oldPassword','Current Password');
        $form->addRule('oldPassword','Enter your current password',
                       'required',false,'client');

        // Add a field for the new password
        $form->addElement('password','newPassword','New Password');
        $form->addRule('password','Please provide a password','required',
                       false,'client');
        $form->addRule('password','Password must be at least 6 characters',
                       'minlength',6,'client');
        $form->addRule('password','Password cannot be more than 12 chars',
                       'maxlength',50,'client');
        $form->addRule('password','Password can only contain letters and '.
                       'numbers','alphanumeric',NULL,'client');

        // Add a field for the new password
        $form->addElement('password','confirm','Confirm Password');
        $form->addRule('confirm','Confirm your password',
                       'compare',false,'client');

        // Add a submit button
        $form->addElement('submit','submit','Change Password');

        // If the form is submitted...
        if ( $form->validate() ) {

            // Instantiate Account Maintenance class
            $aMaint=new AccountMaintenance($db);

            // Change the password
            if ( $aMaint->changePassword(
                        $auth,
                        $form->getSubmitValue('oldPassword'),
                        $form->getSubmitValue('newPassword')) ) {
                echo ( 'Your password has been changed successfully.<br />'.
                       'Click <a href="'.$_SERVER['PHP_SELF'].
                        '">here</a>' );
            } else {
                echo ( 'Error changing your password.<br />'.
                       'Click <a href="'.$_SERVER['PHP_SELF'].
                        '">here</a>' );
            }

        } else {
            // If not submitted, display the form
            $form->display();
        }
        break;
    default:
        echo ( "<b>Options:</b><br />" );
        echo ( "<a href=\"".$_SERVER['PHP_SELF']."?view=changePassword\">".
               "Change Password</a>" );
        break;
}
?>