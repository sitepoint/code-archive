<?php
// Include MySQL class
require_once ('Database/MySQL.php');

// Include SessionAnalyzer class
require_once ('Session/SessionAnalyzer.php');

$host='localhost';   // Hostname of MySQL server
$dbUser='harryf';    // Username for MySQL
$dbPass='secret';    // Password for user
$dbName='sitepoint'; // Database name

// Instantiate MySQL connection
$db=& new MySQL($host,$dbUser,$dbPass,$dbName);

// Instantiate the SessionAnalyzer class
$sAnalyzer=& new SessionAnalyzer();

$sql = "SELECT data FROM php_sessions";
$result = $db->query($sql);

while ( $row = $result->fetch() ) {
    // Add the raw session data
    $sAnalyzer->addSession($row['data']);
}

// Initialize variables for results of session analysis
$guests=0;
$members='';

// Loop through the queue of parsed sessions
while ( $sessionStore = $sAnalyzer->fetch() ) {
    if ( isset( $sessionStore->login ) )
        $members.=$sessionStore->login.' ';
    else
        $guests++;
}
// Format the output nicely

echo ( 'There are currently '.$guests.' guests online<br />' );
echo ( 'Members online: '.$members );
?>