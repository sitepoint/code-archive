$('document').ready(function(){
  var scroller = new iScroll('scroller');
});