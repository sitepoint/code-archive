<?php
// In a practical applications, these variables could come from a database or other dynamic source
$navCrumbs = '/Home/Products/Super-Dooper Products';
$navColor = 'b50000';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Flash External Variables Test</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
<!--
body {
	margin: 0;
}
#breadcrumbdiv {
	background-color: <?php echo '#' . $navColor; ?>;
	width: 100%;
	height: 50px; 
}
-->
</style>
</head>
<body> 
<div id="breadcrumbdiv"> 
	<object type="application/x-shockwave-flash"
		name="breadcrumb" width="550" height="50" id="breadcrumb"
		data="breadcrumb.swf?breadcrumb=<?php echo urlencode($navCrumbs); ?>&breadcrumbColor=<?php echo urlencode('0x' . $navColor); ?>"> 
		<param name="movie" value="breadcrumb.swf?breadcrumb=<?php echo urlencode($navCrumbs); ?>&breadcrumbColor=<?php echo urlencode('0x' . $navColor); ?>" />
		<param name="quality" value="high" />
	</object>
</div> 
</body>
</html>
