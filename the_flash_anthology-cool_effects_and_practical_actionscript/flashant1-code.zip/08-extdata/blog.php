<?php
header("content-type: text/xml");

$blogArray = array(
	2004 => array(
		1 => array(
			array(
				'datetime' => '01/01/2004 10:25:00',
				'title' => 'January 2004: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '15/01/2004 15:56:12',
				'title' => 'January 2004: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				)
			),
		2 => array(
			array(
				'datetime' => '01/02/2004 10:25:00',
				'title' => 'February 2004: News item #1',
				'content' => 'Aenean velit lorem, commodo et, varius at, molestie vel, leo. Aenean eleifend, quam at vehicula volutpat, arcu mauris pulvinar turpis, sit amet suscipit mauris odio ut risus. Mauris porttitor, justo eget gravida convallis, augue risus sollicitudin lacus, quis dapibus lorem leo at turpis.'
				),
			array(
				'datetime' => '15/02/2004 15:56:12',
				'title' => 'February 2004: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/02/2004 10:25:00',
				'title' => 'February 2004: News item #3',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '28/02/2004 15:56:12',
				'title' => 'February 2004: News item #4',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		3 => array(
			array(
				'datetime' => '15/03/2004 15:56:12',
				'title' => 'March 2004: News item #1',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/03/2004 10:25:00',
				'title' => 'March 2004: News item #2',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '31/03/2004 15:56:12',
				'title' => 'March 2004: News item #3',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		4 => array(
			array(
				'datetime' => '01/04/2004 10:25:00',
				'title' => 'April 2004: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '15/04/2004 15:56:12',
				'title' => 'April 2004: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				)
			),
		5 => array(
			array(
				'datetime' => '28/05/2004 15:56:12',
				'title' => 'May 2004: News item #1',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		6 => array(
			array(
				'datetime' => '28/06/2004 15:56:12',
				'title' => 'June 2004: News item #1',
				'content' => 'FUt gravida molestie urna. Suspendisse felis pede, blandit vitae, elementum id, adipiscing et, orci. Ut vel ligula. Vivamus velit tellus, sollicitudin at, commodo vitae, pulvinar non, turpis. Morbi est libero, sagittis sit amet, tristique eget, lobortis nec, lectus.'
				)
			),
		7 => array(
			array(
				'datetime' => '01/07/2004 10:25:00',
				'title' => 'July 2004: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '15/07/2004 15:56:12',
				'title' => 'July 2004: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				)
			),
		8 => array(
			array(
				'datetime' => '01/08/2004 10:25:00',
				'title' => 'August 2004: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec non dolor nec erat iaculis hendrerit. Nulla facilisi. Pellentesque sapien.'
				),
			array(
				'datetime' => '4/08/2004 15:56:12',
				'title' => 'August 2004: News item #2',
				'content' => 'In a lorem. Integer imperdiet venenatis justo. Maecenas mauris. Quisque ultrices, sapien non facilisis sagittis, nibh dui tempor ante, at bibendum neque metus sed ante. Maecenas turpis. Ut a lorem facilisis est pharetra mattis. Vivamus sed odio quis turpis rutrum vulputate. Morbi sollicitudin ullamcorper eros.'
				),
			array(
				'datetime' => '12/08/2004 10:25:00',
				'title' => 'August 2004: News item #3',
				'content' => 'Nam magna eros, imperdiet a, elementum gravida, adipiscing at, arcu. Morbi at augue eget arcu vulputate auctor. Praesent viverra, lacus eu posuere auctor, lorem nunc volutpat arcu, vel facilisis sem enim eget urna. Integer mi urna, lobortis vitae, fermentum sit amet, blandit nec, lorem.'
				),
			array(
				'datetime' => '30/08/2004 15:56:12',
				'title' => 'August 2004: News item #4',
				'content' => 'Nulla aliquam metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean gravida, metus et sodales elementum, ipsum velit vulputate mauris, vel molestie felis magna non diam. Aliquam non est tempus leo posuere cursus.'
				)
			),
		9 => array(
			array(
				'datetime' => '01/09/2004 10:25:00',
				'title' => 'September 2004: News item #1',
				'content' => 'Aenean velit lorem, commodo et, varius at, molestie vel, leo. Aenean eleifend, quam at vehicula volutpat, arcu mauris pulvinar turpis, sit amet suscipit mauris odio ut risus. Mauris porttitor, justo eget gravida convallis, augue risus sollicitudin lacus, quis dapibus lorem leo at turpis.'
				),
			array(
				'datetime' => '15/09/2004 15:56:12',
				'title' => 'September 2004: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/09/2004 10:25:00',
				'title' => 'September 2004: News item #3',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '28/09/2004 15:56:12',
				'title' => 'September 2004: News item #4',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		10 => array(
			array(
				'datetime' => '01/10/2004 10:25:00',
				'title' => 'October 2004: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '15/10/2004 15:56:12',
				'title' => 'October 2004: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				)
			),
		11 => array(
			array(
				'datetime' => '01/11/2004 10:25:00',
				'title' => 'November 2004: News item #1',
				'content' => 'Aenean velit lorem, commodo et, varius at, molestie vel, leo. Aenean eleifend, quam at vehicula volutpat, arcu mauris pulvinar turpis, sit amet suscipit mauris odio ut risus. Mauris porttitor, justo eget gravida convallis, augue risus sollicitudin lacus, quis dapibus lorem leo at turpis.'
				),
			array(
				'datetime' => '15/11/2004 15:56:12',
				'title' => 'November 2004: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/11/2004 10:25:00',
				'title' => 'November 2004: News item #3',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '28/11/2004 15:56:12',
				'title' => 'November 2004: News item #4',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		12 => array(
			array(
				'datetime' => '15/12/2004 15:56:12',
				'title' => 'December 2004: News item #1',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/12/2004 10:25:00',
				'title' => 'December 2004: News item #2',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '31/12/2004 15:56:12',
				'title' => 'December 2004: News item #3',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			)
		),
	2005 => array(
		1 => array(
			array(
				'datetime' => '15/01/2005 15:56:12',
				'title' => 'January 2005: News item #1',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/01/2005 10:25:00',
				'title' => 'January 2005: News item #2',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '31/01/2005 15:56:12',
				'title' => 'January 2005: News item #3',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		2 => array(
			array(
				'datetime' => '01/02/2005 10:25:00',
				'title' => 'February 2005: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '15/02/2005 15:56:12',
				'title' => 'February 2005: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				)
			),
		3 => array(
			array(
				'datetime' => '01/03/2005 10:25:00',
				'title' => 'March 2005: News item #1',
				'content' => 'Aenean velit lorem, commodo et, varius at, molestie vel, leo. Aenean eleifend, quam at vehicula volutpat, arcu mauris pulvinar turpis, sit amet suscipit mauris odio ut risus. Mauris porttitor, justo eget gravida convallis, augue risus sollicitudin lacus, quis dapibus lorem leo at turpis.'
				),
			array(
				'datetime' => '15/03/2005 15:56:12',
				'title' => 'March 2005: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/03/2005 10:25:00',
				'title' => 'March 2005: News item #3',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '28/03/2005 15:56:12',
				'title' => 'March 2005: News item #4',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		4 => array(
			array(
				'datetime' => '15/04/2005 15:56:12',
				'title' => 'April 2005: News item #1',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/04/2005 10:25:00',
				'title' => 'April 2005: News item #2',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '30/04/2005 15:56:12',
				'title' => 'April 2005: News item #3',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		5 => array(
			array(
				'datetime' => '01/05/2005 10:25:00',
				'title' => 'May 2005: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '15/05/2005 15:56:12',
				'title' => 'May 2005: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				)
			),
		6 => array(
			array(
				'datetime' => '28/06/2005 15:56:12',
				'title' => 'June 2005: News item #1',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		7 => array(
			array(
				'datetime' => '28/07/2005 15:56:12',
				'title' => 'July 2006: News item #1',
				'content' => 'FUt gravida molestie urna. Suspendisse felis pede, blandit vitae, elementum id, adipiscing et, orci. Ut vel ligula. Vivamus velit tellus, sollicitudin at, commodo vitae, pulvinar non, turpis. Morbi est libero, sagittis sit amet, tristique eget, lobortis nec, lectus.'
				)
			),
		8 => array(
			array(
				'datetime' => '01/08/2005 10:25:00',
				'title' => 'August 2005: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '15/08/2005 15:56:12',
				'title' => 'August 2005: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				)
			),
		9 => array(
			array(
				'datetime' => '01/09/2005 10:25:00',
				'title' => 'September 2005: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec non dolor nec erat iaculis hendrerit. Nulla facilisi. Pellentesque sapien.'
				),
			array(
				'datetime' => '4/09/2005 15:56:12',
				'title' => 'September 2005: News item #2',
				'content' => 'In a lorem. Integer imperdiet venenatis justo. Maecenas mauris. Quisque ultrices, sapien non facilisis sagittis, nibh dui tempor ante, at bibendum neque metus sed ante. Maecenas turpis. Ut a lorem facilisis est pharetra mattis. Vivamus sed odio quis turpis rutrum vulputate. Morbi sollicitudin ullamcorper eros.'
				),
			array(
				'datetime' => '12/09/2005 10:25:00',
				'title' => 'September 2005: News item #3',
				'content' => 'Nam magna eros, imperdiet a, elementum gravida, adipiscing at, arcu. Morbi at augue eget arcu vulputate auctor. Praesent viverra, lacus eu posuere auctor, lorem nunc volutpat arcu, vel facilisis sem enim eget urna. Integer mi urna, lobortis vitae, fermentum sit amet, blandit nec, lorem.'
				),
			array(
				'datetime' => '30/09/2005 15:56:12',
				'title' => 'September 2005: News item #4',
				'content' => 'Nulla aliquam metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean gravida, metus et sodales elementum, ipsum velit vulputate mauris, vel molestie felis magna non diam. Aliquam non est tempus leo posuere cursus.'
				)
			),
		10 => array(
			array(
				'datetime' => '01/10/2005 10:25:00',
				'title' => 'October 2005: News item #1',
				'content' => 'Aenean velit lorem, commodo et, varius at, molestie vel, leo. Aenean eleifend, quam at vehicula volutpat, arcu mauris pulvinar turpis, sit amet suscipit mauris odio ut risus. Mauris porttitor, justo eget gravida convallis, augue risus sollicitudin lacus, quis dapibus lorem leo at turpis.'
				),
			array(
				'datetime' => '15/10/2005 15:56:12',
				'title' => 'October 2005: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/10/2005 10:25:00',
				'title' => 'October 2005: News item #3',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '28/10/2005 15:56:12',
				'title' => 'October 2005: News item #4',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			),
		11 => array(
			array(
				'datetime' => '01/11/2005 10:25:00',
				'title' => 'November 2005: News item #1',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '15/11/2005 15:56:12',
				'title' => 'November 2005: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				)
			),
		12 => array(
			array(
				'datetime' => '01/12/2005 10:25:00',
				'title' => 'December 2005: News item #1',
				'content' => 'Aenean velit lorem, commodo et, varius at, molestie vel, leo. Aenean eleifend, quam at vehicula volutpat, arcu mauris pulvinar turpis, sit amet suscipit mauris odio ut risus. Mauris porttitor, justo eget gravida convallis, augue risus sollicitudin lacus, quis dapibus lorem leo at turpis.'
				),
			array(
				'datetime' => '15/12/2005 15:56:12',
				'title' => 'December 2005: News item #2',
				'content' => 'Praesent vitae orci sed nunc lacinia tempus. Donec faucibus nulla sed purus. Phasellus metus. Praesent auctor. Maecenas consectetuer. In non odio a risus scelerisque ultricies. Sed ornare semper felis. Aenean fermentum lacus lobortis libero viverra adipiscing.'
				),
			array(
				'datetime' => '22/12/2005 10:25:00',
				'title' => 'December 2005: News item #3',
				'content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis turpis. Suspendisse tellus enim, lobortis quis, blandit eu, varius sit amet, massa.'
				),
			array(
				'datetime' => '28/12/2005 15:56:12',
				'title' => 'December 2005: News item #4',
				'content' => 'Fusce ut ligula. Pellentesque suscipit euismod velit. Mauris vel mauris. Pellentesque eget turpis vitae nibh dapibus molestie.'
				)
			)
		)
	);


$entries = $blogArray[$_REQUEST['year']][$_REQUEST['month']];

echo '<?xml version="1.0" encoding="iso-8859-1"?>';
?>
<blog>
<?php
	foreach ($entries as $entry)
	{
		echo '<entry>';
		echo '<datetime>' . $entry['datetime'] . '</datetime>';
		echo '<title>' . $entry['title'] . '</title>';
		echo '<content>' . $entry['content'] . '</content>';
		echo '</entry>';
	}
?>
</blog>