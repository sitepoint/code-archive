<?php
session_start();
if (isset($_SESSION['flashanttestlogin']) && $_SESSION['flashanttestlogin'])
{
	header('content-type: application/x-shockwave-flash');
	header('content-length: ' . filesize('secure.swf'));
	@readfile('secure.swf');
}
?>