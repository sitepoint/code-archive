<?php
session_start();
if ($_REQUEST['username'] == 'test' && $_REQUEST['pass'] == 'test')
{
	echo 'validate=success';
	$_SESSION['flashanttestlogin'] = TRUE;
}
else
{
	echo 'validate=failed';
	$_SESSION['flashanttestlogin'] = FALSE;
}
?>